-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Gegenereerd op: 29 apr 2020 om 11:14
-- Serverversie: 10.1.44-MariaDB-0ubuntu0.18.04.1
-- PHP-versie: 7.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_admin`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails`
--

CREATE TABLE `emails` (
  `email_id` int(11) NOT NULL,
  `subject` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `from_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_to_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_to_` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT '0',
  `send_by` int(11) DEFAULT NULL,
  `send_on` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` tinyint(11) NOT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `emails`
--

INSERT INTO `emails` (`email_id`, `subject`, `body`, `from_name`, `from_email`, `reply_to_name`, `reply_to_`, `send`, `send_by`, `send_on`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-05-06 12:44:58', 0, 0, NULL),
(2, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-05-07 16:47:59', 0, 0, NULL),
(3, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:17:29', 0, 0, NULL),
(4, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:17:33', 0, 0, NULL),
(5, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:19:32', 0, 0, NULL),
(6, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:24:40', 0, 0, NULL),
(7, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:24:59', 0, 0, NULL),
(8, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:26:05', 0, 0, NULL),
(9, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 14:26:45', 0, 0, NULL),
(10, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:44:58', 0, 0, NULL),
(11, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:46:05', 0, 0, NULL),
(12, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:47:06', 0, 0, NULL),
(13, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:47:10', 0, 0, NULL),
(14, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:47:56', 0, 0, NULL),
(15, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:47:56', 0, 0, NULL),
(16, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 18:49:53', 0, 0, NULL),
(17, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:00:25', 0, 0, NULL),
(18, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:01:05', 0, 0, NULL),
(19, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:05:14', 0, 0, NULL),
(20, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:05:37', 0, 0, NULL),
(21, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:06:03', 0, 0, NULL),
(22, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:06:12', 0, 0, NULL),
(23, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:06:19', 0, 0, NULL),
(24, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:07:09', 0, 0, NULL),
(25, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:07:17', 0, 0, NULL),
(26, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:07:24', 0, 0, NULL),
(27, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:07:32', 0, 0, NULL),
(28, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:07:43', 0, 0, NULL),
(29, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:08:03', 0, 0, NULL),
(30, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:09:43', 0, 0, NULL),
(31, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:10:18', 0, 0, NULL),
(32, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:10:26', 0, 0, NULL),
(33, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:10:33', 0, 0, NULL),
(34, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:10:48', 0, 0, NULL),
(35, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:03', 0, 0, NULL),
(36, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:10', 0, 0, NULL),
(37, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:21', 0, 0, NULL),
(38, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:28', 0, 0, NULL),
(39, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:32', 0, 0, NULL),
(40, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:11:43', 0, 0, NULL),
(41, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:12:11', 0, 0, NULL),
(42, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:12:25', 0, 0, NULL),
(43, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:12:31', 0, 0, NULL),
(44, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:12:45', 0, 0, NULL),
(45, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:12:51', 0, 0, NULL),
(46, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:13:16', 0, 0, NULL),
(47, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:13:22', 0, 0, NULL),
(48, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:13:47', 0, 0, NULL),
(49, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:14:19', 0, 0, NULL),
(50, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:14:24', 0, 0, NULL),
(51, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:15:22', 0, 0, NULL),
(52, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:15:30', 0, 0, NULL),
(53, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:15:46', 0, 0, NULL),
(54, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:15:52', 0, 0, NULL),
(55, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:15:57', 0, 0, NULL),
(56, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:16:18', 0, 0, NULL),
(57, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:16:39', 0, 0, NULL),
(58, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:16:46', 0, 0, NULL),
(59, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:17:06', 0, 0, NULL),
(60, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:17:17', 0, 0, NULL),
(61, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:17:18', 0, 0, NULL),
(62, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:17:24', 0, 0, NULL),
(63, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:17:31', 0, 0, NULL),
(64, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:18:46', 0, 0, NULL),
(65, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:19:13', 0, 0, NULL),
(66, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:20:29', 0, 0, NULL),
(67, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:20:42', 0, 0, NULL),
(68, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:21:02', 0, 0, NULL),
(69, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:21:26', 0, 0, NULL),
(70, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:21:49', 0, 0, NULL),
(71, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:22:14', 0, 0, NULL),
(72, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:23:02', 0, 0, NULL),
(73, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:24:04', 0, 0, NULL),
(74, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:24:53', 0, 0, NULL),
(75, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:25:14', 0, 0, NULL),
(76, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:25:32', 0, 0, NULL),
(77, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:25:45', 0, 0, NULL),
(78, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:26:32', 0, 0, NULL),
(79, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:26:40', 0, 0, NULL),
(80, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:27:15', 0, 0, NULL),
(81, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:27:40', 0, 0, NULL),
(82, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:28:07', 0, 0, NULL),
(83, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:28:28', 0, 0, NULL),
(84, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:28:48', 0, 0, NULL),
(85, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 19:30:12', 0, 0, NULL),
(86, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:20:12', 0, 0, NULL),
(87, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:20:14', 0, 0, NULL),
(88, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:21:15', 0, 0, NULL),
(89, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:21:44', 0, 0, NULL),
(90, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:22:15', 0, 0, NULL),
(91, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:23:36', 0, 0, NULL),
(92, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:25:04', 0, 0, NULL),
(93, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:27:12', 0, 0, NULL),
(94, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:29:53', 0, 0, NULL),
(95, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:30:12', 0, 0, NULL),
(96, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:30:31', 0, 0, NULL),
(97, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:31:01', 0, 0, NULL),
(98, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:31:13', 0, 0, NULL),
(99, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:31:24', 0, 0, NULL),
(100, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:32:14', 0, 0, NULL),
(101, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:32:27', 0, 0, NULL),
(102, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:32:36', 0, 0, NULL),
(103, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:32:53', 0, 0, NULL),
(104, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:33:08', 0, 0, NULL),
(105, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:36:03', 0, 0, NULL),
(106, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:39:22', 0, 0, NULL),
(107, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:39:51', 0, 0, NULL),
(108, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:39:54', 0, 0, NULL),
(109, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:39:57', 0, 0, NULL),
(110, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:40:01', 0, 0, NULL),
(111, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:40:06', 0, 0, NULL),
(112, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:41:26', 0, 0, NULL),
(113, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:41:36', 0, 0, NULL),
(114, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:41:38', 0, 0, NULL),
(115, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:42:29', 0, 0, NULL),
(116, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:42:38', 0, 0, NULL),
(117, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:44:40', 0, 0, NULL),
(118, 'test', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2019-12-10 22:46:02', 0, 0, NULL),
(119, 'Wachtwoord herstel Devis Online', '<!doctype html><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><style type=\"text/css\">\n							#outlook a { padding: 0; }\n						 	.ReadMsgBody { width: 100%; }\n							.ExternalClass { width: 100%; }\n							.ExternalClass * { line-height:100%; }\n       \n							body{background-color: #F2F2F2; margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; text-align: center; font-family:Verdana, Arial, sans-serif; font-size: 12px }\n							.header{background-color: #002E65; width: 685px; color:#fff; text-align: left; font-size: 20px; padding-top:15px;  padding-bottom:15px; display: block; padding-left: 25px}\n							.footer{background-color: #002E65; width: 685px; height: 25px; color:#fff; text-align: center; font-size: 11px;}\n							.footer a, footer a:visited{ color:#fff !important;}\n							.text-container{ display: block;  background-color: #FFFFFF; width: 700px; text-align: left; border-width: 0px; border-collapse: collapse}\n							.text-container td.titel{padding:25px 25px 0 25px; font-size: 15px}\n							.text-container td.text{padding: 25px; line-height: 24px}\n						 </style></head><body><table class=\"text-container\"><tr><td class=\"header\">Devis Online</td></tr><tr><td class=\"titel\">Nieuw wachtwoord aanvragen</td></tr><tr><td class=\"text\">U heeft verzocht om uw wachtwoord voor <b>Devis Online</b> opnieuw in te stellen. Klik op onderstaande link om uw wachtwoord opnieuw in te stellen. De link is 7 dagen geldig.\n						<br /><br />\n						<a href=\"https://www.devisonline.nl/usermanagement/resetuser?wid=wid3&wg_hash=12hash34&user=277f2ccaca2a79d3061acbbf1cbd0594\">\n						Wachtwoord opnieuw instellen</a>\n						<br /><br />\n						Heeft u niet verzocht om uw wachtwoord te herstellen? Neem dan contact met ons op, mogelijk probeert iemand uw account te misbruiken.\n						Met vriendelijke groet,<br />Abering HR Services</td></tr><tr><td class=\"footer\">Devils Online</td></tr></table></body></html>', 'Abering Uitzenden', 'info@aberinghr.nl', NULL, NULL, 1, 0, '2020-01-16 14:27:11', NULL, '2020-01-16 14:27:10', 0, 0, NULL),
(120, 'Wachtwoord herstel Devis Online', '<!doctype html><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><style type=\"text/css\">\n							#outlook a { padding: 0; }\n						 	.ReadMsgBody { width: 100%; }\n							.ExternalClass { width: 100%; }\n							.ExternalClass * { line-height:100%; }\n       \n							body{background-color: #F2F2F2; margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; text-align: center; font-family:Verdana, Arial, sans-serif; font-size: 12px }\n							.header{background-color: #002E65; width: 685px; color:#fff; text-align: left; font-size: 20px; padding-top:15px;  padding-bottom:15px; display: block; padding-left: 25px}\n							.footer{background-color: #002E65; width: 685px; height: 25px; color:#fff; text-align: center; font-size: 11px;}\n							.footer a, footer a:visited{ color:#fff !important;}\n							.text-container{ display: block;  background-color: #FFFFFF; width: 700px; text-align: left; border-width: 0px; border-collapse: collapse}\n							.text-container td.titel{padding:25px 25px 0 25px; font-size: 15px}\n							.text-container td.text{padding: 25px; line-height: 24px}\n						 </style></head><body><table class=\"text-container\"><tr><td class=\"header\">Devis Online</td></tr><tr><td class=\"titel\">Nieuw wachtwoord aanvragen</td></tr><tr><td class=\"text\">U heeft verzocht om uw wachtwoord voor <b>Devis Online</b> opnieuw in te stellen. Klik op onderstaande link om uw wachtwoord opnieuw in te stellen. De link is 7 dagen geldig.\n						<br /><br />\n						<a href=\"https://www.devisonline.nl/usermanagement/resetuser?wid=wid3&wg_hash=12hash34&user=c3bf0798ff701111148ac7fdd156627b\">\n						Wachtwoord opnieuw instellen</a>\n						<br /><br />\n						Heeft u niet verzocht om uw wachtwoord te herstellen? Neem dan contact met ons op, mogelijk probeert iemand uw account te misbruiken.\n						Met vriendelijke groet,<br />Abering HR Services</td></tr><tr><td class=\"footer\">Devils Online</td></tr></table></body></html>', 'Abering Uitzenden', 'info@aberinghr.nl', NULL, NULL, 1, 0, '2020-01-16 14:33:28', NULL, '2020-01-16 14:33:27', 0, 0, NULL),
(121, 'Wachtwoord herstel Devis Online', '<!doctype html><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><style type=\"text/css\">\n							#outlook a { padding: 0; }\n						 	.ReadMsgBody { width: 100%; }\n							.ExternalClass { width: 100%; }\n							.ExternalClass * { line-height:100%; }\n       \n							body{background-color: #F2F2F2; margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; text-align: center; font-family:Verdana, Arial, sans-serif; font-size: 12px }\n							.header{background-color: #002E65; width: 685px; color:#fff; text-align: left; font-size: 20px; padding-top:15px;  padding-bottom:15px; display: block; padding-left: 25px}\n							.footer{background-color: #002E65; width: 685px; height: 25px; color:#fff; text-align: center; font-size: 11px;}\n							.footer a, footer a:visited{ color:#fff !important;}\n							.text-container{ display: block;  background-color: #FFFFFF; width: 700px; text-align: left; border-width: 0px; border-collapse: collapse}\n							.text-container td.titel{padding:25px 25px 0 25px; font-size: 15px}\n							.text-container td.text{padding: 25px; line-height: 24px}\n						 </style></head><body><table class=\"text-container\"><tr><td class=\"header\">Devis Online</td></tr><tr><td class=\"titel\">Nieuw wachtwoord aanvragen</td></tr><tr><td class=\"text\">U heeft verzocht om uw wachtwoord voor <b>Devis Online</b> opnieuw in te stellen. Klik op onderstaande link om uw wachtwoord opnieuw in te stellen. De link is 7 dagen geldig.\n						<br /><br />\n						<a href=\"https://www.devisonline.nl/usermanagement/resetuser?wid=wid3&wg_hash=12hash34&user=bdb4423ffc985689918c02488e54b1de\">\n						Wachtwoord opnieuw instellen</a>\n						<br /><br />\n						Heeft u niet verzocht om uw wachtwoord te herstellen? Neem dan contact met ons op, mogelijk probeert iemand uw account te misbruiken.\n						Met vriendelijke groet,<br />Abering HR Services</td></tr><tr><td class=\"footer\">Devils Online</td></tr></table></body></html>', 'Abering Uitzenden', 'info@aberinghr.nl', NULL, NULL, 1, 0, '2020-01-16 14:34:06', NULL, '2020-01-16 14:34:04', 0, 0, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_attachments`
--

CREATE TABLE `emails_attachments` (
  `id` int(11) NOT NULL,
  `email_id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_table` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `temp_file_dir` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `temp_file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_log`
--

CREATE TABLE `emails_log` (
  `id` int(12) NOT NULL,
  `email_id` int(11) NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_recipients`
--

CREATE TABLE `emails_recipients` (
  `email_id` int(11) DEFAULT NULL,
  `type` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'to',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `meta` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `emails_recipients`
--

INSERT INTO `emails_recipients` (`email_id`, `type`, `name`, `email`, `uitzender_id`, `inlener_id`, `werknemer_id`, `meta`) VALUES
(119, 'to', 'Sander Meijering', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(120, 'to', 'Sander Meijering', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(121, 'to', 'Sander Meijering', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `list_burgelijkestaat`
--

CREATE TABLE `list_burgelijkestaat` (
  `id` int(11) UNSIGNED NOT NULL,
  `sort_order` int(2) NOT NULL,
  `label` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `waarde_easylon` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `list_burgelijkestaat`
--

INSERT INTO `list_burgelijkestaat` (`id`, `sort_order`, `label`, `waarde_easylon`) VALUES
(1, 1, 'Ongehuwd', 1),
(2, 2, 'Gehuwd', 2),
(3, 3, 'Gehuwd geweest', 3),
(4, 4, 'Geregistreerd partnerschap', 4),
(5, 5, 'Zonder contract samenwonend', 5),
(6, 6, 'Met contract samenwonend', 6),
(7, 7, 'Weduwe/Weduwnaar', 7);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `list_landen`
--

CREATE TABLE `list_landen` (
  `id` int(11) NOT NULL,
  `code` varchar(4) NOT NULL,
  `landnaam` varchar(200) NOT NULL,
  `sort_order` smallint(3) NOT NULL DEFAULT '999'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `list_landen`
--

INSERT INTO `list_landen` (`id`, `code`, `landnaam`, `sort_order`) VALUES
(1, 'AF', 'Afghanistan', 999),
(2, 'AL', 'Albanië', 999),
(3, 'AQ', 'Antarctica', 999),
(4, 'DZ', 'Algerije', 999),
(5, 'AS', 'Samoa (Amerikaans)', 999),
(6, 'AD', 'Andorra', 999),
(7, 'AO', 'Angola', 999),
(8, 'AG', 'Antigua en Barbuda', 999),
(9, 'AZ', 'Azerbeidzjan', 999),
(10, 'AR', 'Argentinië', 999),
(11, 'AU', 'Australië', 999),
(12, 'AT', 'Oostenrijk', 20),
(13, 'BS', 'Bahamas', 999),
(14, 'BH', 'Bahrein', 999),
(15, 'BD', 'Bangladesh', 999),
(16, 'AM', 'Armenië', 999),
(17, 'BB', 'Barbados', 999),
(18, 'BE', 'België', 2),
(19, 'BM', 'Bermuda', 999),
(20, 'BT', 'Bhutan', 999),
(21, 'BO', 'Bolivia', 999),
(22, 'BA', 'Bosnië-Herzegovina', 999),
(23, 'BW', 'Botswana', 999),
(24, 'BV', 'Bouvet eiland', 999),
(25, 'BR', 'Brazilië', 999),
(26, 'BZ', 'Belize', 999),
(27, 'IO', 'Brits gebied in de Indische oceaan', 999),
(28, 'SB', 'Solomonseilanden', 999),
(29, 'VG', 'Maagdeneilanden (Britse)', 999),
(30, 'BN', 'Brunei', 999),
(31, 'BG', 'Bulgarije', 3),
(32, 'MM', 'Myanmar', 999),
(33, 'BI', 'Burundi', 999),
(34, 'BY', 'Wit-Rusland (Belarus)', 999),
(35, 'KH', 'Cambodja', 999),
(36, 'CM', 'Kameroen', 999),
(37, 'CA', 'Canada', 999),
(38, 'CV', 'Kaapverdië', 999),
(39, 'KY', 'Cayman eilanden', 999),
(40, 'CF', 'Centraal Afrikaanse Republiek', 999),
(41, 'LK', 'Sri Lanka', 999),
(42, 'TD', 'Tsjaad', 999),
(43, 'CL', 'Chili', 999),
(44, 'CN', 'China', 999),
(45, 'TW', 'Taiwan', 999),
(46, 'CX', 'Christmas eiland', 999),
(47, 'CC', 'Cocos (Keeling) eilanden', 999),
(48, 'CO', 'Colombia', 999),
(49, 'KM', 'Comoren', 999),
(50, 'YT', 'Mayotte', 999),
(51, 'CG', 'Congo-Brazzaville', 999),
(52, 'CD', 'Congo (ex-Zaire)', 999),
(53, 'CK', 'Cookeilanden', 999),
(54, 'CR', 'Costa Rica', 999),
(55, 'HR', 'Kroatië', 14),
(56, 'CU', 'Cuba', 999),
(57, 'CY', 'Cyprus', 4),
(58, 'CZ', 'Tsjechië', 999),
(59, 'BJ', 'Benin', 999),
(60, 'DK', 'Denemarken', 5),
(61, 'DM', 'Dominica', 999),
(62, 'DO', 'Dominicaanse Republiek', 999),
(63, 'EC', 'Ecuador', 999),
(64, 'SV', 'El Salvador', 999),
(65, 'GQ', 'Equatoriaal-Guinee', 999),
(66, 'ET', 'Ethiopië', 999),
(67, 'ER', 'Eritrea', 999),
(68, 'EE', 'Estland', 7),
(69, 'FO', 'Faeroër', 999),
(70, 'FK', 'Falkland eilanden', 999),
(71, 'GS', 'Zuid-Georgië en Zuidelijke Sandwich eilanden', 999),
(72, 'FJ', 'Fiji', 999),
(73, 'FI', 'Finland', 8),
(74, 'AX', 'Alands-eilanden', 999),
(75, 'FR', 'Frankrijk', 9),
(76, 'GF', 'Frans Guyana', 999),
(77, 'PF', 'Frans Polynesië', 999),
(78, 'TF', 'Zuidelijke Franse gebieden', 999),
(79, 'DJ', 'Djibouti', 999),
(80, 'GA', 'Gabon', 999),
(81, 'GE', 'Georgië', 999),
(82, 'GM', 'Gambia', 999),
(83, 'PS', 'Palestijns Bezette Gebieden', 999),
(84, 'DE', 'Duitsland', 6),
(85, 'GH', 'Ghana', 999),
(86, 'GI', 'Gibraltar', 999),
(87, 'KI', 'Kiribati', 999),
(88, 'GR', 'Griekenland', 10),
(89, 'GL', 'Groenland', 999),
(90, 'GD', 'Grenada', 999),
(91, 'GP', 'Guadeloupe', 999),
(92, 'GU', 'Guam', 999),
(93, 'GT', 'Guatemala', 999),
(94, 'GN', 'Guinee', 999),
(95, 'GY', 'Guyana', 999),
(96, 'HT', 'Haiti', 999),
(97, 'HM', 'Heard en McDonald eilanden', 999),
(98, 'VA', 'Vaticaanstad', 999),
(99, 'HN', 'Honduras', 999),
(100, 'HK', 'Hongkong', 999),
(101, 'HU', 'Hongarije', 11),
(102, 'IS', 'IJsland', 999),
(103, 'IN', 'India', 999),
(104, 'ID', 'Indonesië', 999),
(105, 'IR', 'Iran', 999),
(106, 'IQ', 'Irak', 999),
(107, 'IE', 'Ierland', 12),
(108, 'IL', 'Isravl', 999),
(109, 'IT', 'Italië', 13),
(110, 'CI', 'Ivoorkust ', 999),
(111, 'JM', 'Jamaica', 999),
(112, 'JP', 'Japan', 999),
(113, 'KZ', 'Kazachstan', 999),
(114, 'JO', 'Jordanië', 999),
(115, 'KE', 'Kenia', 999),
(116, 'KP', 'Noord-Korea', 999),
(117, 'KR', 'Zuid-Korea', 999),
(118, 'KW', 'Koeweit', 999),
(119, 'KG', 'Kirgizië', 999),
(120, 'LA', 'Laos', 999),
(121, 'LB', 'Libanon', 999),
(122, 'LS', 'Lesotho', 999),
(123, 'LV', 'Letland', 15),
(124, 'LR', 'Liberia', 999),
(125, 'LY', 'Libië', 999),
(126, 'LI', 'Liechtenstein', 999),
(127, 'LT', 'Litouwen', 999),
(128, 'LU', 'Luxemburg', 16),
(129, 'MO', 'Macao', 999),
(130, 'MG', 'Madagaskar', 999),
(131, 'MW', 'Malawi', 999),
(132, 'MY', 'Maleisië', 999),
(133, 'MV', 'Maldiven', 999),
(134, 'ML', 'Mali', 999),
(135, 'MT', 'Malta', 17),
(136, 'MQ', 'Martinique', 999),
(137, 'MR', 'Mauritanië', 999),
(138, 'MU', 'Mauritius', 999),
(139, 'MX', 'Mexico', 999),
(140, 'MC', 'Monaco', 999),
(141, 'MN', 'Mongolië', 999),
(142, 'MD', 'Moldavië', 999),
(143, 'ME', 'Montenegro', 999),
(144, 'MS', 'Montserrat', 999),
(145, 'MA', 'Marokko', 18),
(146, 'MZ', 'Mozambique', 999),
(147, 'OM', 'Oman', 999),
(148, 'NA', 'Namibië', 999),
(149, 'NR', 'Nauru', 999),
(150, 'NP', 'Nepal', 999),
(151, 'NL', 'Nederland', 1),
(152, 'NL', 'Nederlandse Antillen', 19),
(153, 'CW', 'Curaçao', 999),
(154, 'AW', 'Aruba', 999),
(155, 'SX', 'Sint Maarten (Nederlandse deel)', 999),
(156, 'BQ', 'Bonaire, Sint Eustatius en Saba', 999),
(157, 'NC', 'Nieuw-Caledonië', 999),
(158, 'VU', 'Vanuatu', 999),
(159, 'NZ', 'Nieuw-Zeeland', 999),
(160, 'NI', 'Nicaragua', 999),
(161, 'NE', 'Niger', 999),
(162, 'NG', 'Nigeria', 999),
(163, 'NU', 'Niue', 999),
(164, 'NF', 'Norfolk eilanden', 999),
(165, 'NO', 'Noorwegen', 999),
(166, 'MP', 'Marianen eilanden (Noordelijke)', 999),
(167, 'UM', 'V.S. (ver uit de kust gelegen kleinere eilanden)', 999),
(168, 'FM', 'Micronesia (Federale Staten van)', 999),
(169, 'MH', 'Marshall eilanden', 999),
(170, 'PW', 'Palau', 999),
(171, 'PK', 'Pakistan', 999),
(172, 'PA', 'Panama', 999),
(173, 'PG', 'Papoea Nieuw-Guinea', 999),
(174, 'PY', 'Paraguay', 999),
(175, 'PE', 'Peru', 999),
(176, 'PH', 'Filipijnen', 999),
(177, 'PN', 'Pitcairneilanden', 999),
(178, 'PL', 'Polen', 21),
(179, 'PT', 'Portugal', 22),
(180, 'GW', 'Guinee Bissau', 999),
(181, 'TL', 'Timor-Leste (Oost Timor)', 999),
(182, 'PR', 'Puerto Rico', 999),
(183, 'QA', 'Qatar', 999),
(184, '', 'Réunion', 999),
(185, 'RO', 'Roemenië', 23),
(186, 'RU', 'Rusland', 999),
(187, 'RW', 'Rwanda', 999),
(188, '', 'St. Bartholomeus', 999),
(189, '', 'St. Helena, Ascension en Tristan da Cunha', 999),
(190, '', 'St. Kitts en Nevis', 999),
(191, 'AI', 'Anguilla', 999),
(192, '', 'St. Lucia', 999),
(193, '', 'St. Maarten (Franse deel)', 999),
(194, '', 'St. Pierre en Miquelon', 999),
(195, '', 'St. Vincent en de Grenadines', 999),
(196, '', 'San Marino', 999),
(197, '', 'Sao Tomé en Principe', 999),
(198, '', 'Saoedi-Arabië', 999),
(199, 'SN', 'Senegal', 999),
(200, 'RS', 'Servië', 999),
(201, 'SC', 'Seychellen', 999),
(202, 'SL', 'Sierra Leone', 999),
(203, 'SG', 'Singapore', 999),
(204, 'SK', 'Slowakije', 999),
(205, 'VN', 'Vietnam', 999),
(206, 'SI', 'Slovenië', 24),
(207, 'SO', 'Somalië', 999),
(208, 'ZA', 'Zuid-Afrika', 999),
(209, 'ZW', 'Zimbabwe', 999),
(210, 'ES', 'Spanje', 25),
(211, 'SS', 'Zuid-Soedan', 999),
(212, '', 'Sahara (Westelijke)', 999),
(213, 'SD', 'Soedan', 999),
(214, 'SR', 'Suriname', 26),
(215, '', 'Spitsbergen & Jan Mayen eilanden', 999),
(216, '', 'Swaziland', 999),
(217, 'SE', 'Zweden', 29),
(218, 'CH', 'Zwitserland', 999),
(219, 'SY', 'Syrië', 999),
(220, 'TJ', 'Tadzjikistan', 999),
(221, 'TH', 'Thailand', 999),
(222, 'TG', 'Togo', 999),
(223, 'TK', 'Tokelau-eilanden', 999),
(224, 'TG', 'Tonga', 999),
(225, 'TT', 'Trinidad en Tobago', 999),
(226, 'AE', 'Verenigde Arabische Emiraten', 999),
(227, 'TN', 'Tunesië', 999),
(228, 'TR', 'Turkije', 27),
(229, 'TM', 'Turkmenistan', 999),
(230, '', 'Turks- en Caicoseilanden', 999),
(231, '', 'Tuvalu', 999),
(232, 'UG', 'Oeganda', 999),
(233, 'UA', 'Oekraine', 999),
(234, '', 'Macedonië', 999),
(235, 'EG', 'Egypte', 999),
(236, 'GB', 'Verenigd Koninkrijk', 28),
(237, '', 'Guernsey', 999),
(238, '', 'Jersey', 999),
(239, '', 'Man eiland', 999),
(240, '', 'Tanzania', 999),
(241, 'US', 'Verenigde Staten van Amerika', 999),
(242, '', 'Maagdeneilanden (Amerikaanse)', 999),
(243, '', 'Burkina Faso', 999),
(244, 'UY', 'Uruguay', 999),
(245, 'UZ', 'Oezbekistan', 999),
(246, 'VE', 'Venezuela', 999),
(247, '', 'Wallis & Futuna eilanden', 999),
(248, '', 'Samoa', 999),
(249, '', 'Jemen', 999),
(250, '', 'Servië en Montenegro', 999),
(251, 'ZM', 'Zambia', 999),
(252, '', 'Kosovo', 999);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `list_nationaliteiten`
--

CREATE TABLE `list_nationaliteiten` (
  `code` int(4) UNSIGNED ZEROFILL NOT NULL,
  `sort_order` int(4) NOT NULL,
  `omschrijving` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `list_nationaliteiten`
--

INSERT INTO `list_nationaliteiten` (`code`, `sort_order`, `omschrijving`) VALUES
(0000, 2, '[Onbekend]'),
(0001, 1, 'Nederlandse'),
(0027, 999, 'Slowaakse'),
(0028, 999, 'Tsjechische'),
(0029, 999, 'Burger van Bosni'),
(0030, 999, 'Burger van Georgi'),
(0031, 999, 'Burger van Toerkmenistan'),
(0032, 999, 'Burger van Tadzjikistan'),
(0033, 999, 'Burger van Oezbekistan'),
(0034, 999, 'Burger van Oekraine'),
(0035, 999, 'Burger van Kyrgyzstan'),
(0036, 999, 'Burger van Moldavi'),
(0037, 999, 'Burger van Kazachstan'),
(0038, 999, 'Burger van Belarus (Wit-Rusland)'),
(0039, 999, 'Burger van Azerbajdsjan'),
(0040, 999, 'Burger van Armeni'),
(0041, 999, 'Burger van Rusland'),
(0042, 999, 'Burger van Sloveni'),
(0043, 999, 'Burger van Kroati'),
(0044, 999, 'Letse'),
(0045, 999, 'Estnische'),
(0046, 999, 'Litouwse'),
(0047, 999, 'Burger van de Marshalleilanden'),
(0048, 999, 'Myanmarese'),
(0049, 999, 'Namibische'),
(0050, 999, 'Albanese'),
(0051, 999, 'Andorrese'),
(0052, 999, 'Belgische'),
(0053, 999, 'Bulgaarse'),
(0054, 999, 'Deense'),
(0055, 999, 'Duitse'),
(0056, 999, 'Finse'),
(0057, 999, 'Franse'),
(0058, 999, 'Jemenitische'),
(0059, 999, 'Griekse'),
(0060, 999, 'Brits burger'),
(0061, 999, 'Hongaarse'),
(0062, 999, 'Ierse'),
(0063, 999, 'IJslandse'),
(0064, 999, 'Italiaanse'),
(0066, 999, 'Liechtensteinse'),
(0067, 999, 'Luxemburgse'),
(0068, 999, 'Maltese'),
(0069, 999, 'Monegaskische'),
(0070, 999, 'Noorse'),
(0071, 999, 'Oostenrijkse'),
(0072, 999, 'Poolse'),
(0073, 999, 'Portugese'),
(0074, 999, 'Roemeense'),
(0075, 999, 'Burger Sovjetunie'),
(0076, 999, 'Sanmarinese'),
(0077, 999, 'Spaanse'),
(0078, 999, 'Tsjechoslowaakse'),
(0079, 999, 'Vaticaanse'),
(0080, 999, 'Zweedse'),
(0081, 999, 'Zwitserse'),
(0082, 999, 'Oostduitse'),
(0083, 999, 'Brits onderdaan'),
(0084, 999, 'Eritrese'),
(0085, 999, 'Brits overzees burger'),
(0086, 999, 'Macedonische'),
(0087, 999, 'Burger van Kosovo'),
(0100, 999, 'Algerijnse'),
(0101, 999, 'Angolese'),
(0104, 999, 'Burundische'),
(0105, 999, 'Botswaanse'),
(0106, 999, 'Burger van Burkina Faso'),
(0108, 999, 'Centrafrikaanse'),
(0109, 999, 'Comorese'),
(0110, 999, 'Kongolese'),
(0111, 999, 'Beninse'),
(0112, 999, 'Egyptische'),
(0113, 999, 'Equatoriaalguinese'),
(0114, 999, 'Etiopische'),
(0115, 999, 'Djiboutiaanse'),
(0116, 999, 'Gabonese'),
(0117, 999, 'Gambiaanse'),
(0118, 999, 'Ghanese'),
(0119, 999, 'Guinese'),
(0120, 999, 'Ivoriaanse'),
(0121, 999, 'Kaapverdische'),
(0122, 999, 'Kameroense'),
(0123, 999, 'Kenyaanse'),
(0124, 999, 'Za'),
(0125, 999, 'Lesothaanse'),
(0126, 999, 'Liberiaanse'),
(0127, 999, 'Libische'),
(0128, 999, 'Malagassische'),
(0129, 999, 'Malawische'),
(0130, 999, 'Malinese'),
(0131, 999, 'Marokkaanse'),
(0132, 999, 'Burger van Mauritani'),
(0133, 999, 'Burger van Mauritius'),
(0134, 999, 'Mozambiquaanse'),
(0135, 999, 'Swazische'),
(0136, 999, 'Burger van Niger'),
(0137, 999, 'Burger van Nigeria'),
(0138, 999, 'Ugandese'),
(0139, 999, 'Guineebissause'),
(0140, 999, 'Zuidafrikaanse'),
(0142, 999, 'Zimbabwaanse'),
(0143, 999, 'Rwandese'),
(0144, 999, 'Burger van S'),
(0145, 999, 'Senegalese'),
(0147, 999, 'Sierraleoonse'),
(0148, 999, 'Soedanese'),
(0149, 999, 'Somalische'),
(0151, 999, 'Tanzaniaanse'),
(0152, 999, 'Togolese'),
(0154, 999, 'Tsjadische'),
(0155, 999, 'Tunesische'),
(0156, 999, 'Zambiaanse'),
(0200, 999, 'Bahamaanse'),
(0202, 999, 'Belizaanse'),
(0204, 999, 'Canadese'),
(0205, 999, 'Costaricaanse'),
(0206, 999, 'Cubaanse'),
(0207, 999, 'Burger van Dominicaanse Republiek'),
(0208, 999, 'Salvadoraanse'),
(0211, 999, 'Guatemalteekse'),
(0212, 999, 'Ha'),
(0213, 999, 'Hondurese'),
(0214, 999, 'Jamaicaanse'),
(0216, 999, 'Mexicaanse'),
(0218, 999, 'Nicaraguaanse'),
(0219, 999, 'Panamese'),
(0222, 999, 'Burger van Trinidad en Tobago'),
(0223, 999, 'Amerikaans burger'),
(0250, 999, 'Argentijnse'),
(0251, 999, 'Barbadaanse'),
(0252, 999, 'Boliviaanse'),
(0253, 999, 'Braziliaanse'),
(0254, 999, 'Chileense'),
(0255, 999, 'Colombiaanse'),
(0256, 999, 'Ecuadoraanse'),
(0259, 999, 'Guyaanse'),
(0261, 999, 'Paraguayaanse'),
(0262, 999, 'Peruaanse'),
(0263, 999, 'Surinaamse'),
(0264, 999, 'Uruguayaanse'),
(0265, 999, 'Venezolaanse'),
(0267, 999, 'Grenadaanse'),
(0268, 999, 'Burger van Saint Kitts-Nevis'),
(0300, 999, 'Afgaanse'),
(0301, 999, 'Bahreinse'),
(0302, 999, 'Bhutaanse'),
(0303, 999, 'Burmaanse'),
(0304, 999, 'Bruneise'),
(0305, 999, 'Kambodjaanse'),
(0306, 999, 'Srilankaanse'),
(0307, 999, 'Chinese'),
(0308, 999, 'Cyprische'),
(0309, 999, 'Filipijnse'),
(0310, 999, 'Taiwanese'),
(0312, 999, 'Burger van India'),
(0313, 999, 'Indonesische'),
(0314, 999, 'Iraakse'),
(0315, 999, 'Iraanse'),
(0316, 999, 'Isra'),
(0317, 999, 'Japanse'),
(0318, 999, 'Noordjemenitische'),
(0319, 999, 'Jordaanse'),
(0320, 999, 'Koeweitse'),
(0321, 999, 'Laotiaanse'),
(0322, 999, 'Libanese'),
(0324, 999, 'Maldivische'),
(0325, 999, 'Maleisische'),
(0326, 999, 'Mongolische'),
(0327, 999, 'Omanitische'),
(0328, 999, 'Nepalese'),
(0329, 999, 'Noordkoreaanse'),
(0331, 999, 'Pakistaanse'),
(0333, 999, 'Katarese'),
(0334, 999, 'Saoediarabische'),
(0335, 999, 'Singaporaanse'),
(0336, 999, 'Syrische'),
(0337, 999, 'Thaise'),
(0338, 999, 'Burger van de Ver. Arabische Emiraten'),
(0339, 999, 'Turkse'),
(0340, 999, 'Zuidjemenitische'),
(0341, 999, 'Zuidkoreaanse'),
(0342, 999, 'Vi'),
(0345, 999, 'Burger van Bangladesh'),
(0400, 999, 'Australische'),
(0401, 999, 'Burger van Papua-Nieuwguinea'),
(0402, 999, 'Nieuwzeelandse'),
(0404, 999, 'Westsamoaanse'),
(0421, 999, 'Burger van Antigua en Barbuda'),
(0424, 999, 'Vanuatuse'),
(0425, 999, 'Fijische'),
(0429, 999, 'Burger van Britse afhankelijke gebieden'),
(0430, 999, 'Tongaanse'),
(0431, 999, 'Nauruaanse'),
(0437, 999, 'Amerikaans onderdaan'),
(0442, 999, 'Solomoneilandse'),
(0444, 999, 'Seychelse'),
(0445, 999, 'Kiribatische'),
(0446, 999, 'Tuvaluaanse'),
(0447, 999, 'Sintluciaanse'),
(0448, 999, 'Burger van Dominica'),
(0449, 999, 'Burger van Sint Vincent en de Grenadinen'),
(0450, 999, 'British National (overseas)'),
(0451, 999, 'Za'),
(0452, 999, 'Burger van Timor Leste'),
(0454, 999, 'Servische'),
(0455, 999, 'Burger van Montenegro'),
(0499, 999, '[Statenloos]'),
(0500, 999, '[Vastgesteld niet-Nederlander]');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `list_soort_id`
--

CREATE TABLE `list_soort_id` (
  `id` int(11) UNSIGNED NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `label` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `waarde_easylon` varchar(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `list_soort_id`
--

INSERT INTO `list_soort_id` (`id`, `sort_order`, `label`, `waarde_easylon`) VALUES
(1, 1, 'Nederlands paspoort', 'NP'),
(2, 6, 'Gemeentelijke identiteitskaart', 'GI'),
(3, 5, 'Toeristenkaart', 'TK'),
(4, 3, 'Niet Nederlands paspoort', 'NN'),
(5, 7, 'Vreemdelingenpaspoort', 'DO'),
(6, 8, 'Vluchtelingenpaspoort', 'VL'),
(7, 2, 'Nederlandse identiteitskaart', 'EI'),
(9, 4, 'Overige identiteitsbewijzen', 'OI'),
(10, 9, 'Verblijfsdocument A', 'VA'),
(11, 10, 'Verblijfsdocument B', 'VB'),
(12, 11, 'Verblijfsdocument C', 'VC'),
(13, 12, 'Verblijfsdocument D', 'VD'),
(14, 13, 'Verblijfsdocument E', 'VE'),
(15, 14, 'Verblijfsdocument 1', 'V1'),
(16, 15, 'Verblijfsdocument 2', 'V3'),
(17, 16, 'Verblijfsdocument 3', 'V3');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(12) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `reason` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `browser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `device_hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `user_id`, `username`, `reason`, `ip`, `browser`, `device_hash`, `timestamp`) VALUES
(1, 2, 'hsmeijering@home.nl', 'wrong password', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '4f58def07b8502b13e2d19da36e4c854', '2020-01-15 12:26:51'),
(2, 2, 'hsmeijering@home.nl', 'wrong password', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '4f58def07b8502b13e2d19da36e4c854', '2020-01-15 12:26:59'),
(3, NULL, '', 'username not found', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', 'afa0c0afd98f3e3841a500de5d3f7ade', '2020-01-22 11:51:33'),
(4, NULL, '', 'username not found', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 'a0376e99977b2033075e238397804cd8', '2020-01-30 07:40:07'),
(5, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-03 09:28:45'),
(6, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-03 09:28:47'),
(7, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-03 11:08:15'),
(8, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-03 11:08:16'),
(9, NULL, '', 'username not found', '94.208.61.82', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '02022c2dc7fcdace638646f3fdf35c63', '2020-02-03 23:08:40'),
(10, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 10:43:44'),
(11, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 10:45:15'),
(12, NULL, 'moonier@abering.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:24:16'),
(13, NULL, 'moonier@abering.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:25:08'),
(14, NULL, 'moonier@abering.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:26:40'),
(15, NULL, '', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:26:42'),
(16, NULL, 'moonier@abering.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:26:54'),
(17, NULL, 'moonier@aberinghr.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:28:06'),
(18, NULL, 'moonier@aberinghr.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:28:51'),
(19, NULL, 'moonier@aberinghr.nl', 'username not found', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 11:29:11'),
(20, 49, 'moonier@aberinghr.nl', 'wrong password', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '25157e7b7053f9edc785d68fe0bdc8c9', '2020-02-04 13:57:48'),
(21, 61, 'smjbart@gmail.com', 'wrong password', '109.37.130.213', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-G935F/G935FXXS7ESK7) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.1 Chrome/71.0.3578.99 Mobile Safari/537.36', '7a06d165bb12e5427b44b05625edf028', '2020-02-04 17:02:03'),
(22, NULL, 'demo', 'wrong password', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 'c3627a4ef4d073767ef82515fdd60418', '2020-02-05 10:11:06'),
(23, NULL, 'test', 'username not found', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 'c3627a4ef4d073767ef82515fdd60418', '2020-02-05 19:24:20'),
(24, 62, 'info@mdmasbest.com', 'wrong password', '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 'd094b939d29fdad1b633bbef11880a5b', '2020-02-06 09:50:41'),
(25, NULL, '', 'username not found', '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 'd094b939d29fdad1b633bbef11880a5b', '2020-02-06 09:50:43'),
(26, NULL, '', 'username not found', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', 'dfe1d63af4256d1ce1e0391778595d55', '2020-02-07 12:48:41'),
(27, 52, 'moonier@4you-pd.nl', 'wrong password', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', 'a3b48c3e00ebb6fdca6779c113225e24', '2020-02-10 12:58:45'),
(28, NULL, '', 'username not found', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', '6eb9de49b9fa8b77eb413993f3065a20', '2020-03-05 09:38:21'),
(29, NULL, 'www.hoppsingdergute@aol.c', 'username not found', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', '6eb9de49b9fa8b77eb413993f3065a20', '2020-03-05 09:41:09'),
(30, NULL, 'www.hoppsingdergute@aol.c', 'username not found', '89.15.236.241', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', '5e094153b2de2f010dde9bfb8dff3d1a', '2020-03-06 10:13:08'),
(31, 77, 'hoppsingdergute@gmail.com', 'wrong password', '2.247.241.89', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', '4005b035e44a2b18636209adf4491e1f', '2020-03-06 10:29:38'),
(32, NULL, 'www.hoppsingdergute@aol.c', 'username not found', '2.247.241.89', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', '4005b035e44a2b18636209adf4491e1f', '2020-03-06 10:30:21'),
(33, 77, 'hoppsingdergute@gmail.com', 'wrong password', '77.11.25.143', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', '7dbb1685f9f33a458fb186b1d31838c7', '2020-03-09 07:43:08'),
(34, 77, 'hoppsingdergute@gmail.com', 'wrong password', '77.11.25.143', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', '7dbb1685f9f33a458fb186b1d31838c7', '2020-03-09 07:43:29'),
(35, NULL, 'AHMSchaap1958@kpnmail.nl', 'username not found', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', '7912d23e4fe37b212d6810c3fa0f24e7', '2020-03-11 11:04:57'),
(36, 72, 'info@bsworksupport.nl', 'wrong password', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', '7912d23e4fe37b212d6810c3fa0f24e7', '2020-03-11 11:06:21'),
(37, NULL, 'www.hoppsingdergute@aol.c', 'username not found', '89.15.238.241', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', '0f321272c9675f618e56ad7acb1940b0', '2020-03-11 15:06:13'),
(38, 82, 'Kadape2000@msn.com', 'wrong password', '86.83.206.22', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36', '480568f6a6bb4a4313f8c96103dac7bd', '2020-03-12 16:26:05'),
(39, NULL, '', 'username not found', '2.247.240.121', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', '24bb145fb4c476e88a5864c80f46b861', '2020-03-18 10:26:31'),
(40, NULL, 'Patrick Flos', 'username contaminated', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 'a1b7393d39fb2c492a5d5d3d3704d74a', '2020-03-19 12:09:03'),
(41, NULL, 'Patrick Flos', 'username contaminated', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 'a1b7393d39fb2c492a5d5d3d3704d74a', '2020-03-19 12:09:24'),
(42, NULL, 'Patrick Flos', 'username contaminated', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 'a1b7393d39fb2c492a5d5d3d3704d74a', '2020-03-19 12:09:44'),
(43, NULL, 'facturen@milieutechniekre', 'username not found', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 'a1b7393d39fb2c492a5d5d3d3704d74a', '2020-03-19 12:10:32'),
(44, NULL, 'Patrick Flos', 'username contaminated', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 'a1b7393d39fb2c492a5d5d3d3704d74a', '2020-03-19 12:13:39'),
(45, NULL, 'semvanewijk', 'username not found', '86.89.65.66', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_1 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C153 Safari/604.1', '9c6f540efde62155c448cbbc459ca0cd', '2020-04-01 07:36:27'),
(46, 89, 'basvanewijk@hotmail.nl', 'wrong password', '86.89.65.66', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Safari/605.1.15', 'ee231b9a4ac94ebaae8ae5957b89461e', '2020-04-01 07:49:05'),
(47, 89, 'basvanewijk@hotmail.nl', 'wrong password', '188.207.110.153', 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1', '85a3ac4ecd994741b1c2c02a0b202b15', '2020-04-05 06:31:07'),
(48, NULL, '', 'username not found', '188.207.110.153', 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1', '85a3ac4ecd994741b1c2c02a0b202b15', '2020-04-05 06:31:31'),
(49, NULL, '', 'username not found', '109.36.139.19', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36', '5135b8a0fe749a5c98e904ed23c30222', '2020-04-16 05:27:49');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `login_blacklist_ip`
--

CREATE TABLE `login_blacklist_ip` (
  `id` int(12) NOT NULL,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `block_untill` datetime NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_backup` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `naam` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `new_key` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_key_expires` datetime DEFAULT NULL,
  `reset_key` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_key_expires` datetime DEFAULT NULL,
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` tinyint(11) DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `password_backup`, `naam`, `email`, `email_confirmed`, `new_key`, `new_key_expires`, `reset_key`, `reset_key_expires`, `created_by`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(2, 'hsmeijering@home.nl', '$2y$10$TuINhRCMeyrgaiN159SMkufd7sD7LY5/HginzzCsKaRjfNbEggVju', NULL, 'Sander Meijering', 'hsmeijering@home.nl', 1, NULL, NULL, 'bdb4423ffc985689918c02488e54b1de', '2020-01-23 00:00:00', NULL, '2019-03-29 09:12:34', 0, NULL, NULL),
(3, 'demo', '$2y$10$TuINhRCMeyrgaiN159SMkufd7sD7LY5/HginzzCsKaRjfNbEggVju', NULL, 'Demo Account', 'hsmeijering@home.nl', 1, NULL, NULL, 'bdb4423ffc985689918c02488e54b1de', '2020-01-23 00:00:00', NULL, '2019-03-29 09:12:34', 0, NULL, NULL),
(47, 'roel@aberinghr.nl', '$2y$10$bbjw1FMTAKK8KXIl0lo2HOGik7T05W4T.Fm7LznfvB4JVNj8yViAq', NULL, 'Roel Arts', 'roel@aberinghr.nl', 1, NULL, NULL, NULL, NULL, 2, '2019-12-17 15:14:22', 1, NULL, NULL),
(48, 'johan@aberinghr.nl', '$2y$10$N5Hy2s4irVm3jDuCVtKmbuhdp/3Ucr.yyYk92291IdlxOwqIr688G', NULL, 'Johan van Abeelen', 'johan@aberinghr.nl', 1, NULL, NULL, NULL, NULL, 2, '2019-12-17 15:14:44', 0, NULL, NULL),
(49, 'moonier@aberinghr.nl', '$2y$10$2npYdWsW5L4XjaOujcMqMeoGLNXLYxh3EguLDQhwpTFTWel8JKbXK', '$2y$10$2b7.IbFDpbrx7U0cusw8nu3jqumwXuvYj/OQfiExj5F48thJhWdE6', 'Moonier', 'moonier@aberinghr.nl', 1, NULL, NULL, NULL, NULL, 2, '2019-12-17 15:15:00', 0, NULL, NULL),
(52, 'moonier@4you-pd.nl', '$2y$10$AsxgHNUQ/9rI7I/abAoG4u1SMxnckMq/z0esId17xU3leDKFNVR2S', NULL, 'Moonier  Zarouali  4You', 'moonier@4you-pd.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-01-06 10:48:14', 0, NULL, NULL),
(53, 'arno@tmauitzendendetachering.nl', '$2y$10$hKwFvliboQG.V3pC9q0y/.DVwHroVOBuHwhEeye2NNTk8s2/Yysfi', NULL, 'Arno van de Water', 'arno@tmauitzendendetachering.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-01-08 09:56:16', 0, NULL, NULL),
(54, 'anna@taaskjobs.nl', '$2y$10$0y01mWvBdR/Q9VT3WSAa4O.ZrvDHAOtzcEuksEh7jB5hL3tZwvF.C', NULL, 'Anna  Jarosz', 'anna@taaskjobs.nl', 1, NULL, NULL, NULL, NULL, 48, '2020-01-08 11:55:06', 0, NULL, NULL),
(55, 'info@henh.eu', '$2y$10$drEQR16mVwS06BNuXjAwK.Slx1xczEtXx2FNirwHJDoDgoCW/CCeK', NULL, 'Jürgen  Hoffmann', 'info@henh.eu', 1, NULL, NULL, NULL, NULL, 48, '2020-01-08 14:11:47', 0, NULL, NULL),
(56, 'uitzender@bemiddeling.nl', '$2y$10$cF2zlExVfH1r/mpujvTw8eQYBw51Gt9Vl4lsyI1k9m7XWO6/0lNX2', NULL, 'Sander  Meijering', 'uitzender@bemiddeling', 1, NULL, NULL, NULL, NULL, 2, '2020-01-09 10:34:03', 0, NULL, NULL),
(57, 'inlener@bemiddeling.nl', '$2y$10$ZHzWaoa3x2NfOspTgmE9jOZZLUB72E5zZdgm60UhSFtyXsKj8klFa', NULL, 'Sander  Meijering', 'inlener@bemiddeling', 1, 'f743905842b4b098b601669d2c10aee5', '2020-01-14 00:00:00', NULL, NULL, 2, '2020-01-09 10:38:05', 0, NULL, NULL),
(58, 'info@royalds.nl', '$2y$10$OnWYxqc5L4wMQdA30BuAQeuRnPUAp7WYIFJvZU8z/AWUYVUETfWou', NULL, 'Melissa  Beltman', 'info@royalds.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-01-13 16:00:48', 0, NULL, NULL),
(59, 'info@aberinghr.nl', '$2y$10$u0tJ.RfUAMvgms/KBSvNQ.STgHk3edY2McrariqYc/yNF9EjbCh4u', NULL, 'Pieter van den Broek', 'info@aberinghr.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-01-15 11:07:43', 0, NULL, NULL),
(60, 'testinlener', '$2y$10$ByQvI/hEJBPV22ZipGtuTuUfzyakm/oAaN21A.IX7da102MIWxBVG', NULL, 'Jennie de Groot', 'hsmeijering@home.nl', 0, 'e53178f75fab6ce5fc4e011e341796cc', '2020-01-20 00:00:00', NULL, NULL, 2, '2020-01-15 11:19:04', 0, NULL, NULL),
(61, 'smjbart@gmail.com', '$2y$10$1Of4EZyHLVxEg5E3.fIl/uLTWiIxSG0j.UkdS97UovnjKPBOMil9u', NULL, 'Stephen  Bart', 'smjbart@gmail.com', 1, NULL, NULL, NULL, NULL, 48, '2020-01-24 09:59:55', 0, NULL, NULL),
(62, 'info@mdmasbest.com', '$2y$10$6qKAsVyvwW7O6KC2UlxiseU8QCnHyumP0vN/eigSTe8USAXc8jL3u', '$2y$10$rtdB3RklXPUGNTczoe1n5.ec.h8TUgHhPOYaoCqmb5yQLixrALtfe', 'Raimond de Jong', 'info@mdmasbest.com', 1, NULL, NULL, NULL, NULL, 2, '2020-02-04 13:03:01', 0, NULL, NULL),
(63, 'info@mbafbouw.nl', '$2y$10$P7N1kzkyTUWGp1Zn2jTxk.23Sl5cf8/FoKIQPYJhipJHhDEnw0ylO', NULL, 'Joeri  Elfering', 'info@mbafbouw.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-02-05 20:07:00', 1, NULL, NULL),
(65, 'johann@aberinghr.nl', NULL, NULL, 'Johan van Abeelen', 'johann@aberinghr.nl', 0, '614ca53ab0c13fcf9253022142d85d68', '2020-02-15 00:00:00', NULL, NULL, 2, '2020-02-10 16:03:59', 0, NULL, NULL),
(66, 'johanvanabeelen@aberinghr.nl', NULL, NULL, 'Johan van Abeelen', 'johanvanabeelen@aberinghr.nl', 0, '27d1ad101e328d9fecd6a79253125093', '2020-02-16 00:00:00', NULL, NULL, 2, '2020-02-11 05:47:38', 0, NULL, NULL),
(67, 'desloper@aberinghr.nl', NULL, NULL, 'Pieter de Sloper', 'desloper@aberinghr.nl', 0, '5dee5d421292a7fc1ea7bb379ecfbf17', '2020-02-16 00:00:00', NULL, NULL, 2, '2020-02-11 05:47:52', 0, NULL, NULL),
(68, 'schoonmaak@aberinghr.nl', NULL, NULL, 'Wilma  Schoner', 'schoonmaak@aberinghr.nl', 0, 'bfa04bb581428195412661bbb35aee1e', '2020-02-16 00:00:00', NULL, NULL, 2, '2020-02-11 05:48:03', 0, NULL, NULL),
(70, 'j.v.hamond@horyon.nl', '$2y$10$Q/AWoKijTa0lC31IbdyvWO8Y4pGm/tfII2oeUbdnKvJRQVFOKiS4W', NULL, 'Jan van Hamond', 'j.v.hamond@horyon.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-02-19 07:41:38', 0, NULL, NULL),
(71, 'administratie@aberinghr.nl', NULL, NULL, 'Johan van Abeelen', 'administratie@aberinghr.nl', 0, 'b1079091bd1603289e7eeb66dd12eb16', '2020-02-24 00:00:00', NULL, NULL, 48, '2020-02-19 11:48:14', 0, NULL, NULL),
(72, 'info@bsworksupport.nl', '$2y$10$it3MR8eGJCVAyzN9PfO2luuo62GRI/kgN9tfdCP/cvmWKiZpu.RrC', NULL, 'Bert  Schaap', 'info@bsworksupport.nl', 1, NULL, NULL, NULL, NULL, 48, '2020-02-20 09:07:48', 0, NULL, NULL),
(73, 'geneuglijk.mbl@outlook.com', '$2y$10$yMBGj3W1KBpDmWWZBPtppOmcvndQOjKVhficJ4bk/FEi.dalTEAo6', NULL, 'Marijke  Geneuglijk', 'geneuglijk.mbl@outlook.com', 1, NULL, NULL, NULL, NULL, 48, '2020-02-20 09:52:49', 0, NULL, NULL),
(74, 'info@mbafbouw.nl', NULL, NULL, 'Joeri  Elfering', 'info@mbafbouw.nl', 0, '06e7a731a5963eafb20d7b72f988e83e', '2020-02-25 00:00:00', NULL, NULL, 2, '2020-02-20 15:18:48', 0, NULL, NULL),
(75, 'mburhenne@mbafbouw.n', NULL, NULL, 'M. Burhenne', 'mburhenne@mbafbouw.n', 0, '103d0de7dfd343a3dd12775bb05a01d3', '2020-02-25 00:00:00', NULL, NULL, 2, '2020-02-20 15:19:06', 0, NULL, NULL),
(76, 'mburhenne@mbafbouw.nl', '$2y$10$fTuOLX6nVfMXC187srrCI.1PIcgcUhJEyvpgOdltbOp33arqRJ1kG', NULL, 'M. Burhenne', 'mburhenne@mbafbouw.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-02-20 15:19:40', 0, NULL, NULL),
(77, 'hoppsingdergute@gmail.com', '$2y$10$tQ3KNLUK9hjC79.uDtMtPuCMJmjIbWGORwd77r1pOt4nPc5ssVW/q', NULL, 'Rainer Hopp', 'hoppsingdergute@gmail.com', 1, NULL, NULL, NULL, NULL, 2, '2020-03-04 16:23:11', 0, NULL, NULL),
(78, 'hoppsingdergute@aol.com', '$2y$10$Izm5gcpNomEYOEd7qM8/ZeMROMRLYCGx7aB7k169B76ryBK66C.l6', NULL, 'Thomas Michael Hopp', 'hoppsingdergute@aol.com', 1, NULL, NULL, NULL, NULL, 2, '2020-03-04 16:24:14', 0, NULL, NULL),
(79, 'h.koksal024@gmail.com', NULL, NULL, 'Hakan Koksal', 'h.koksal024@gmail.com', 1, '3a4b67a633d4e04596d68c41526b0a63', '2020-03-09 00:00:00', NULL, NULL, 2, '2020-03-04 16:24:27', 0, NULL, NULL),
(80, 'chabbo_7@hotmail.com', '$2y$10$783GujM6Qn0ZEV83urmuAOqWuRYPhFw2Wa66IropjW2RYCdT36WLi', NULL, 'Perry Peeters', 'chabbo_7@hotmail.com', 1, NULL, NULL, NULL, NULL, 2, '2020-03-04 16:24:35', 0, NULL, NULL),
(81, 'simonvanderweerden@ziggo.nl', '$2y$10$DuSP54bmaBWrh.xuq0dAKOFOX8jDfI1E0hZgTU1jbp3q6bPZatRL.', NULL, 'simon van der Weerden', 'simonvanderweerden@ziggo.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-03-04 16:24:40', 0, NULL, NULL),
(82, 'kadape2000@msn.com', '$2y$10$5sGk2F2hq8193cgLHbeAFemkrUQBvAdf1ZsvOQUCPm0tV.01vqc8e', NULL, 'Perry Wijnen', 'kadape2000@msn.com', 1, NULL, NULL, NULL, NULL, 2, '2020-03-04 16:24:48', 0, NULL, NULL),
(83, 'franzentheo1@gmail.com', NULL, NULL, 'Theodorus Henricus Maria Franzen', 'franzentheo1@gmail.com', 0, 'd6d01420f775d4b5d4c9db9ef58a21ce', '2020-03-14 00:00:00', NULL, NULL, 2, '2020-03-09 12:07:00', 0, NULL, NULL),
(84, 'info@rienweijersdakwerken.nl', NULL, NULL, 'Bas Weijers', 'info@rienweijersdakwerken.nl', 0, '21a876df7390a79652424841b05264b5', '2020-03-15 00:00:00', NULL, NULL, 48, '2020-03-10 11:44:32', 0, NULL, NULL),
(86, 'patrick@milieutechniekreuver.nl', '$2y$10$J4a2FRQ5HrtpKoN4kcxgduYvoAe.2AAwrDeR/2o4i2rWFv3kqP1ci', '$2y$10$2gItPKm0VlJgAqhbgOmNuOmiVXcjqCd.73hjAZJnJ.3YvmokKQtMy', 'Patrick Flos', 'patrick@milieutechniekreuver.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-03-18 14:17:06', 0, NULL, NULL),
(87, 'lauwepauwer1@hotmail.com', NULL, NULL, 'Rob Geneuglijk', 'lauwepauwer1@hotmail.com', 0, 'e1dabc0213390ff2febf70529f9c9f7b', '2020-04-05 00:00:00', NULL, NULL, 2, '2020-03-31 09:10:24', 0, NULL, NULL),
(88, 'info@vlotwegtransport.nl', '$2y$10$naWwn36ntoLDLDgheZcLheg.02KbdOkcrqiTFqQxRzEnGwkmAGEBi', NULL, 'Theo Bakker', 'info@vlotwegtransport.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-03-31 13:17:16', 0, NULL, NULL),
(89, 'basvanewijk@hotmail.nl', '$2y$10$y2WLpfyFQmT/L7xTySl5E.BHjE.r0tFxV7YlfG5aaSjtJeXWmEmH.', NULL, 'Sebastiaan Stefanus Hendrikus van Ewijk', 'basvanewijk@hotmail.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-03-31 13:29:01', 0, NULL, NULL),
(90, 'semvanewijk@live.nl', '$2y$10$HjxeJhVGch.fTk2mtmG.MeilLRf//CBChUoeU872zPeVmPYQH6pii', NULL, 'Sem Henricus Bastiaan van Ewijk', 'semvanewijk@live.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-03-31 13:29:12', 0, NULL, NULL),
(91, 'administratie@gemini-teak.nl', '$2y$10$U7lsoevUAnRWJEIdNSvpqehHul4hcBfr36RefDSp1Jl2OWWx3jdLm', NULL, 'Bianca Reus', 'administratie@gemini-teak.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-04-01 08:43:29', 0, NULL, NULL),
(92, 'moessie72@gmail.com', '$2y$10$kmnQ5fiou4GULAbZCG4so.x6LVVKj4j0ltpAeuCREzbKWcre7zTkW', NULL, 'Mustapha Ouellaf', 'moessie72@gmail.com', 1, NULL, NULL, NULL, NULL, 2, '2020-04-02 12:55:13', 0, NULL, NULL),
(93, 'gheorghecioflinc@yahoo.com', NULL, NULL, 'Gheorghe Cioflinc', 'gheorghecioflinc@yahoo.com', 1, 'f3657a803bc9177e1464a738ac659b33', '2020-04-08 00:00:00', NULL, NULL, 2, '2020-04-03 07:09:27', 0, NULL, NULL),
(94, 'cucoreanuviorel@gmail.com', '$2y$10$K7Hjb/XmbHn82qvqm1Ahgu60DouI0WPzVC8bGjKjEHaaGtDIKtd2W', NULL, 'Viorel-Ionut Cucoreanu', 'cucoreanuviorel@gmail.com', 1, NULL, NULL, NULL, NULL, 2, '2020-04-03 07:09:33', 0, NULL, NULL),
(95, 'pinkyduifje@gmail.com', '$2y$10$O0FnXCuWSilATyNNiw7xbOn1kd.zp6jAzRQtrfc1M5VzBBbPg1B/u', NULL, 'Leon Baggermans', 'pinkyduifje@gmail.com', 1, NULL, NULL, NULL, NULL, 2, '2020-04-08 12:08:13', 0, NULL, NULL),
(96, 'info@hoekstrayachting.com', NULL, NULL, 'Gerdo Hoekstra', 'info@hoekstrayachting.com', 1, '6de998523a8b9ec3feceda193a6c13fa', '2020-04-19 00:00:00', NULL, NULL, 48, '2020-04-14 17:05:11', 0, NULL, NULL),
(97, 'alfredo-pruteanu2000@yahoo.com', NULL, NULL, 'Alfredo Pruteanu', 'alfredo-pruteanu2000@yahoo.com', 0, 'b802160e2070ea250c311b7f078707ac', '2020-04-19 00:00:00', NULL, NULL, 48, '2020-04-14 17:16:47', 0, NULL, NULL),
(98, 'info@v-geffen.nl', '$2y$10$tO7SjOjGEA8.Ll23s3iUBuPPm1G/uZ4mPiMA66EnEh8SdWX4aoyKO', NULL, 'Rob van Geffen', 'info@v-geffen.nl', 1, NULL, NULL, NULL, NULL, 2, '2020-04-16 11:41:30', 0, NULL, NULL),
(99, 'gerry.van.rumst@beerens.com', NULL, NULL, 'Gerry van Rumst', 'gerry.van.rumst@beerens.com', 1, 'fb1b12fd684744ca0fb7697579831642', '2020-04-26 00:00:00', NULL, NULL, 48, '2020-04-21 09:08:12', 0, NULL, NULL),
(100, 'administratie@beerens.com', NULL, NULL, 'Gerry van Rumst', 'administratie@beerens.com', 0, '48c98f3671f08060e67c3a4bbdb13258', '2020-04-26 00:00:00', NULL, NULL, 48, '2020-04-21 10:39:48', 0, NULL, NULL),
(101, 'neapetrik@gmail.com', NULL, NULL, 'Petrica Neagu', 'neapetrik@gmail.com', 0, '4fef56fba94221abd2a2b16b0a75056c', '2020-04-26 00:00:00', NULL, NULL, 2, '2020-04-21 10:53:05', 0, NULL, NULL),
(102, 'nicupintilie11@yahoo.com', NULL, NULL, 'Neculai Pintilie', 'nicupintilie11@yahoo.com', 0, '7bfc772a64c7f03347b34a21b2776766', '2020-04-26 00:00:00', NULL, NULL, 2, '2020-04-21 10:53:11', 0, NULL, NULL),
(103, 'liviupal9@gmail.com', '$2y$10$yIPIVxU8eMLWQH6xOwnQhO0kFVbmByV9D0Q14t4V1V3QwbJxOvlke', NULL, 'Liviu Petrescu', 'liviupal9@gmail.com', 1, NULL, NULL, NULL, NULL, 48, '2020-04-28 09:40:18', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users_accounts`
--

CREATE TABLE `users_accounts` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `werkgever_id` int(11) DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `user_type` enum('admin','werkgever','uitzender','inlener','werknemer','zzper') COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` tinyint(11) DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users_accounts`
--

INSERT INTO `users_accounts` (`id`, `user_id`, `werkgever_id`, `uitzender_id`, `inlener_id`, `werknemer_id`, `user_type`, `admin`, `created_by`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 2, 1, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-07 13:23:13', 0, NULL, NULL),
(2, 47, 1, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-07 13:23:13', 0, NULL, NULL),
(3, 48, 1, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-07 13:23:45', 0, NULL, NULL),
(4, 49, 1, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-07 13:23:45', 0, NULL, NULL),
(6, 52, 1, 100, NULL, NULL, 'uitzender', 1, 2, '2020-01-07 13:24:16', 0, NULL, NULL),
(7, 2, 2, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-07 13:23:13', 0, NULL, NULL),
(8, 2, 3, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-07 13:23:13', 0, NULL, NULL),
(9, 48, 2, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-07 13:23:45', 0, NULL, NULL),
(10, 53, 1, 101, NULL, NULL, 'uitzender', 1, NULL, '2020-01-08 09:56:16', 0, NULL, NULL),
(11, 54, 1, 102, NULL, NULL, 'uitzender', 1, NULL, '2020-01-08 11:55:06', 0, NULL, NULL),
(12, 49, 2, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-08 13:14:39', 0, NULL, NULL),
(13, 55, 2, 103, NULL, NULL, 'uitzender', 1, NULL, '2020-01-08 14:11:47', 0, NULL, NULL),
(14, 2, 4, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-09 10:23:56', 0, NULL, NULL),
(15, 56, 4, 104, NULL, NULL, 'uitzender', 1, NULL, '2020-01-09 10:34:03', 0, NULL, NULL),
(16, 57, 4, NULL, 3001, NULL, 'inlener', 1, NULL, '2020-01-09 10:38:05', 0, NULL, NULL),
(17, 58, 1, 103, NULL, NULL, 'uitzender', 1, NULL, '2020-01-13 16:00:48', 0, NULL, NULL),
(18, 59, 3, 100, NULL, NULL, 'uitzender', 1, NULL, '2020-01-15 11:07:43', 0, NULL, NULL),
(19, 60, 3, NULL, 3000, NULL, 'inlener', 1, NULL, '2020-01-15 11:19:04', 0, NULL, NULL),
(20, 61, 1, 104, NULL, NULL, 'uitzender', 1, NULL, '2020-01-24 09:59:55', 0, NULL, NULL),
(23, 59, 4, 107, NULL, NULL, 'uitzender', 1, NULL, '2020-01-30 11:29:58', 0, NULL, NULL),
(24, 61, 2, 104, NULL, NULL, 'uitzender', 1, NULL, '2020-01-30 11:34:08', 0, NULL, NULL),
(25, 62, 1, NULL, 3005, NULL, 'inlener', 1, NULL, '2020-02-04 13:03:01', 0, NULL, NULL),
(26, 48, 3, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-07 13:23:13', 0, NULL, NULL),
(27, 48, 4, NULL, NULL, NULL, 'werkgever', 1, 2, '2020-01-09 10:23:56', 0, NULL, NULL),
(28, 63, 1, NULL, 3006, NULL, 'inlener', 1, NULL, '2020-02-05 20:07:00', 0, NULL, NULL),
(30, 65, 3, 101, NULL, NULL, 'uitzender', 1, NULL, '2020-02-10 16:03:59', 0, NULL, NULL),
(31, 66, 3, NULL, 3001, NULL, 'inlener', 1, NULL, '2020-02-11 05:47:38', 0, NULL, NULL),
(32, 67, 3, NULL, 3003, NULL, 'inlener', 1, NULL, '2020-02-11 05:47:52', 0, NULL, NULL),
(33, 68, 3, NULL, 3004, NULL, 'inlener', 1, NULL, '2020-02-11 05:48:03', 0, NULL, NULL),
(34, 52, 2, 105, NULL, NULL, 'uitzender', 1, 2, '2020-02-12 12:43:59', 0, NULL, NULL),
(35, 67, 4, NULL, 3002, NULL, 'inlener', 1, NULL, '2020-02-12 14:25:12', 0, NULL, NULL),
(36, 62, 2, NULL, 3007, NULL, 'inlener', 1, NULL, '2020-02-12 14:27:21', 0, NULL, NULL),
(38, 70, 1, NULL, 3011, NULL, 'inlener', 1, NULL, '2020-02-19 07:41:38', 0, NULL, NULL),
(39, 71, 1, 105, NULL, NULL, 'uitzender', 1, NULL, '2020-02-19 11:48:14', 0, NULL, NULL),
(40, 70, 2, NULL, 3008, NULL, 'inlener', 1, NULL, '2020-02-20 07:52:32', 0, NULL, NULL),
(41, 72, 1, 106, NULL, NULL, 'uitzender', 1, NULL, '2020-02-20 09:07:48', 0, NULL, NULL),
(42, 73, 1, NULL, 3017, NULL, 'inlener', 1, NULL, '2020-02-20 09:52:49', 0, NULL, NULL),
(43, 60, 4, NULL, 3001, NULL, 'inlener', 1, NULL, '2020-01-15 11:19:04', 0, NULL, NULL),
(44, 74, 1, NULL, 3006, NULL, 'inlener', 1, NULL, '2020-02-20 15:18:48', 0, NULL, NULL),
(45, 75, 1, NULL, 3006, NULL, 'inlener', 1, NULL, '2020-02-20 15:19:06', 0, NULL, NULL),
(46, 76, 1, NULL, 3006, NULL, 'inlener', 1, NULL, '2020-02-20 15:19:40', 0, NULL, NULL),
(47, 77, 1, NULL, NULL, 20001, 'werknemer', 0, NULL, '2020-03-04 16:23:11', 0, NULL, NULL),
(48, 78, 1, NULL, NULL, 20002, 'werknemer', 0, NULL, '2020-03-04 16:24:14', 0, NULL, NULL),
(49, 79, 1, NULL, NULL, 20005, 'werknemer', 0, NULL, '2020-03-04 16:24:27', 0, NULL, NULL),
(50, 80, 1, NULL, NULL, 20004, 'werknemer', 0, NULL, '2020-03-04 16:24:35', 0, NULL, NULL),
(51, 81, 1, NULL, NULL, 20003, 'werknemer', 0, NULL, '2020-03-04 16:24:40', 0, NULL, NULL),
(52, 82, 1, NULL, NULL, 20006, 'werknemer', 0, NULL, '2020-03-04 16:24:48', 0, NULL, NULL),
(53, 83, 1, NULL, NULL, 20008, 'werknemer', 0, NULL, '2020-03-09 12:07:00', 0, NULL, NULL),
(54, 49, 3, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-07 12:23:13', 0, NULL, NULL),
(55, 49, 4, NULL, NULL, NULL, 'werkgever', 0, 2, '2020-01-09 09:23:56', 0, NULL, NULL),
(56, 84, 1, NULL, 3018, NULL, 'inlener', 1, NULL, '2020-03-10 11:44:32', 0, NULL, NULL),
(58, 86, 1, NULL, 3019, NULL, 'inlener', 1, NULL, '2020-03-18 14:17:06', 0, NULL, NULL),
(59, 87, 1, NULL, NULL, 20009, 'werknemer', 0, NULL, '2020-03-31 09:10:24', 0, NULL, NULL),
(60, 88, 1, NULL, 3020, NULL, 'inlener', 1, NULL, '2020-03-31 13:17:16', 0, NULL, NULL),
(61, 89, 1, NULL, NULL, 20010, 'werknemer', 0, NULL, '2020-03-31 13:29:01', 0, NULL, NULL),
(62, 90, 1, NULL, NULL, 20011, 'werknemer', 0, NULL, '2020-03-31 13:29:12', 0, NULL, NULL),
(63, 91, 1, NULL, 3021, NULL, 'inlener', 1, NULL, '2020-04-01 08:43:29', 0, NULL, NULL),
(64, 92, 1, NULL, NULL, 20014, 'werknemer', 0, NULL, '2020-04-02 12:55:13', 0, NULL, NULL),
(65, 93, 1, NULL, NULL, 20012, 'werknemer', 0, NULL, '2020-04-03 07:09:27', 0, NULL, NULL),
(66, 94, 1, NULL, NULL, 20013, 'werknemer', 0, NULL, '2020-04-03 07:09:33', 0, NULL, NULL),
(67, 95, 1, NULL, NULL, 20015, 'werknemer', 0, NULL, '2020-04-08 12:08:13', 0, NULL, NULL),
(68, 96, 1, NULL, 3022, NULL, 'inlener', 1, NULL, '2020-04-14 17:05:11', 0, NULL, NULL),
(69, 97, 1, NULL, NULL, 20016, 'werknemer', 0, NULL, '2020-04-14 17:16:47', 0, NULL, NULL),
(70, 98, 1, NULL, NULL, NULL, 'werkgever', 0, NULL, '2020-04-16 11:41:30', 0, NULL, NULL),
(71, 99, 1, NULL, 3023, NULL, 'inlener', 1, NULL, '2020-04-21 09:08:12', 0, NULL, NULL),
(72, 100, 1, NULL, 3023, NULL, 'inlener', 1, NULL, '2020-04-21 10:39:48', 0, NULL, NULL),
(73, 101, 1, NULL, NULL, 20018, 'werknemer', 0, NULL, '2020-04-21 10:53:05', 0, NULL, NULL),
(74, 102, 1, NULL, NULL, 20017, 'werknemer', 0, NULL, '2020-04-21 10:53:11', 0, NULL, NULL),
(75, 103, 1, NULL, NULL, 20019, 'werknemer', 0, NULL, '2020-04-28 09:40:18', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users_sessions`
--

CREATE TABLE `users_sessions` (
  `id` int(12) NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `sid` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `browser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `session_logout` datetime DEFAULT NULL,
  `session_logout_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `session_last_action` datetime NOT NULL,
  `session_start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users_sessions`
--

INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(1, 2, '4cc7c257fe81023153aa4e22dc5b783c4f16be27', 'd06107cc4ee446ad9318e3b624119e1dc42117ea6fe35d9e34b10e4fd5fad7bc', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 17:25:25', '2020-01-07 13:24:35'),
(2, 2, '9662d783adbe5a3c452a4f443b29cf41333dd548', '49222b2209d4354f257b5e1f277d25f9c005b79532f8602909d0c55dc7bf5dea', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 14:44:15', '2020-01-07 13:42:44'),
(3, 2, '1fdbdbea50c2f684117f208764985fbf5a4eb4f2', '20fa50af5d59505cc968dac327b7f574eda774209baf8ada1f66029d0db3667e', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 14:45:03', '2020-01-07 13:44:57'),
(4, 48, '68e138874406c2bc9a6a3949acd61fdf0ff6b508', '08e70d9d3fe56ec4fc32e2e98d5a5479111766b307fc3228bd1508ef96c07e7b', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 16:49:43', '2020-01-07 15:49:34'),
(5, 48, '4a56df1b7d4218aebd241f304f7c73832d79b233', '37b409a781a2692509c29862789e5db07c432aa8c41b40907b8db267b3d1c64b', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 17:01:04', '2020-01-07 15:59:44'),
(6, 2, 'fe55e91a4e1484fa1d4f714d9079239b03deb68c', 'dd82098ef9c8370ba16739e8e702cb09f56030527d568d689c1144604159a304', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-07 17:57:41', '2020-01-07 16:29:37'),
(7, 2, 'ebf7c667495815ceca9da58bd72846ca6423b57f', 'ddb5cdcd6a5649ff501d13ed1bc36a03e32ea47404c7a7ef9df732138420e661', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', '2020-01-07 22:38:08', 'user action', '2020-01-07 22:38:05', '2020-01-07 21:33:31'),
(8, 2, '66075848cc1c2b8c4b674d7f2891d4ff5118b8fe', '8e8991401ee7bed6af3caa3d93b11de8fe21135f92d3c3ae46144950929e4782', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 10:29:36', '2020-01-08 09:29:01'),
(9, 2, '57a9502f88f22dd6ee1fae0a8e66329d3dc00e38', '5ad7430a0d89989c530204261b01a24b934995e82f65aaf0c56cad6086504654', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', '2020-01-08 11:12:20', 'user action', '2020-01-08 11:11:28', '2020-01-08 09:49:26'),
(10, 2, '83b6d66c17229a1495ab6c834fc4839bb0dda094', '6b9787cd4da0b9f9ab536f79d874850c86ee838b9f6331d8584fea3517ab7196', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:40:22', '2020-01-08 10:12:22'),
(11, 48, '0516cfc0735ce1878a3d78cf967270a21f5e819d', 'f907d97866324b7cce0c21d44d52e8a175da56b6c28cc74fd47be1f4cb4ae51d', '84.243.227.86', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:26:47', '2020-01-08 11:00:45'),
(12, 53, '2fac20e47e39f5db9074e93bc814b21f334a597d', '1d87046efa9144338a363bbe897636936f8ec4fe85be08f286e83f53598f82be', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 12:10:52', '2020-01-08 11:10:52'),
(13, 53, 'b271785be266eb94653b22b620865aed9c8589e1', 'c8edcb8db2039015a1746862ce5a837a8cd5c73bcf014cc3b8f5e185abc4ef7d', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:35:20', '2020-01-08 11:11:28'),
(14, 54, 'b50cebf21286fb8c969843a822a3eec294af096d', 'd2b4d750416ddb3cbfc3cef75b6810003aa9d92e7af6a5fa3ae0a4e67d0aaf60', '84.243.227.86', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-08 13:21:10', '2020-01-08 11:56:34'),
(15, 54, '3a0c33e655f512578c97a5e07a284179bb0c1d3a', '7a0ed058b29896c9c8020a2f14e8d3009606214714d2cf777340d5aea540d782', '84.243.227.86', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', '2020-01-08 14:07:36', 'invalid secret', '2020-01-08 13:22:23', '2020-01-08 12:22:22'),
(16, 53, 'd37b255ee3132c96eaa3d425493948dd2672c3fd', '4100956e5e2deb375afaf3968e81980c715f3337e2449c1bf8635487dd45dcb3', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:42:09', '2020-01-08 12:35:26'),
(17, 53, '81932b6d2738f5d5b0c178434dc76c9a2fa5ba8c', '4d79b5e521c1a423bd9fc8b6bd7b0061911d52b051d1dd1773a98979fdbb4fa9', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:51:57', '2020-01-08 12:42:12'),
(18, 2, '9bd3033c834e62f2254650155b43e4a35e99741f', 'c5246f589a9ed77680eb1096bfde746a9f06c9bc5d8080e1fce24f12c8316da2', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 14:34:11', '2020-01-08 12:48:23'),
(19, 53, '4a4a6d0f84a1c2dd3827d9e549fe1f3c20903196', 'ac72b9facf62c927d189c60138964df971161f6162659a63980ba7e176bd832e', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 13:55:30', '2020-01-08 12:52:13'),
(20, 53, 'e132bcae5600555b50bc733228346cec9ccd0d46', 'f67b845855957750f742039985b640e46d0caa36784df519a4cdb3e41f5dc18e', '217.105.180.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 14:00:05', '2020-01-08 13:00:05'),
(21, 54, '4f7c05fb6e069e5ac85d8f118c065f22cc9664f9', '68606d442fe86a9155b6cea259f2d900dde9591a6f6a9818154e6ac7a5260246', '84.241.206.16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 14:10:15', '2020-01-08 13:08:33'),
(22, 48, 'ee78cc1adbe79350ed58b200593e90b3e8528cdb', '473a19f2e4a2e19398e2b1c8a2ea7fcc201c117ba776ef3e8f366711c6a4a39e', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 15:29:01', '2020-01-08 13:45:39'),
(23, 2, 'd63916e65213a07a3000c4ef416a5d93b8e85a51', 'ff8bcdb6232cbb43e2dec7a52650d675b1c0486443aefe901af9d0547622b61b', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 14:54:59', '2020-01-08 13:51:05'),
(24, 2, '7d2d4b64fb47110dcf04c1d84afd9e43b6a44ae3', '6200a8cc1cb259c3c50586714db5846c909a1f7c12d852713362576987e015b7', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 15:15:02', '2020-01-08 14:14:40'),
(25, 2, '640391f08406fad5c9d784d0f12520147505d068', 'ae89cc1927f874c670bc2a8a42cf057c5cab20812403a3feb996f75a2b3ba8ab', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 16:24:15', '2020-01-08 14:28:59'),
(26, 55, '09547a04d13a7b6d43e29ff09641327da7af6dba', '263f934d8dadf77717cc53b314fd3882b328d3fd6ef3665281833321105085d5', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:10:02', '2020-01-08 15:09:41'),
(27, 55, '69a7468fa15c336b34e94b97390d9abd69d6b693', '1ae98e1e736c6e0e9642f9830392c77fb7dce172be743f560aea9ebf3a1bdd10', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:10:06', '2020-01-08 15:10:06'),
(28, 55, '8ce014463e4566499f5d817e8022706a4211629b', 'd1dd3e54dfcb46de5801cb70b6be387654730ab5e6f5f22c784aa0d04d851dd8', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:10:15', '2020-01-08 15:10:15'),
(29, 55, 'e5daf6fd56fb321136d53f6be18317959decf59c', '3064962b77d4de51b9ab93c443640fa9a556d762ea8edf7e58a247263a37c12e', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:10:32', '2020-01-08 15:10:32'),
(30, 55, '7eb265b4543c7a6b7c9fd3716edc356f32b39035', '7e14a170ed6c0cca16db0d42dcd4cec98b464e021564270a62c9546253742798', '213.127.109.23', 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.0 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-01-08 16:16:39', '2020-01-08 15:11:18'),
(31, 55, '6abfe6396d7db8f81a12284329a5ce9af264a1d8', '2833a6a258972dc68c40c6cf3d2c997a7f180104314f1a1669c920ef606a222c', '213.127.109.23', 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.0 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-01-08 16:54:42', '2020-01-08 15:16:53'),
(32, 55, 'f2f371d6051cb970d140eda3e6cfa4cd8d9f9ec4', '39eba851af4c98fa78941954bf08105d50d83f6619ad8c31fde7a6fb1640c655', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:18:52', '2020-01-08 15:18:52'),
(33, 55, 'dadc69841e082ad7e507d45ecdc7855e7cce700e', 'd8d2e5afec90f914635911b305804255b47cee667c6fbcc5bde2c926c27ce004', '213.127.109.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-01-08 16:19:15', '2020-01-08 15:19:15'),
(34, 2, 'eb7f72afbe6eb1fa33eed9da18576aa728b8474c', '960decf90107f127a00fc2aa3d547ad560a773dff53c772e7f7a968c5b53df93', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 17:58:16', '2020-01-08 16:55:28'),
(35, 2, 'de92f7e954956b8554f290cda43be62f8188c848', 'd678afc643ba4c643e70d8d2b926dd618a50f62a3e4bbf05d5d4e36e8c790d69', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 18:16:57', '2020-01-08 17:16:55'),
(36, 2, 'e0d14db5a33c4a2f69d6a6c20ce6ef7206d663a8', '78c27b6eecda6d9aac82fbf7175b116ffc7e2f693a40da8a68de8a13bc86ff7e', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-08 21:10:10', '2020-01-08 19:45:53'),
(37, 48, '8972a25c6dc0a537ff22c617e4e97d0f95225bdc', '40a2aac5fa5771352b6a776f19f1fa6900311b940a9d290bccc77832c9362441', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-09 16:33:16', '2020-01-09 10:02:48'),
(38, 2, 'cc6d4893e4935495c4f61af6483186ed324a6252', 'a94d64be87912d41af2b0a5a24abf5efeb5636154036ce958b6ba738e97fbb68', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 11:34:23', '2020-01-09 10:24:09'),
(39, 56, 'e2fd2201eb92aa5904ff08582ece1e4fce26c23f', '2b8cc92232bca20d87e5f37c33ff1902f93bf90b8364da08dffa5229358ea13c', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', '2020-01-09 11:36:17', 'user action', '2020-01-09 11:36:10', '2020-01-09 10:35:17'),
(40, 2, '906ce17c7351d7568e12c1fd5bee75239a1a338e', '679e4910bf07a4f3f7b8729a57613944409f77680751c1d82f1f1d0c7cba3e78', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', '2020-01-09 11:36:33', 'user action', '2020-01-09 11:36:30', '2020-01-09 10:36:19'),
(41, 56, '214eae49c65bd6ddaad7090eb241fa9f517dfe36', '2cb6fa6fab32b8b694d12b0757634c6c81b2adf8cb0edb9df248a2a5ebf0d2d1', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 11:38:19', '2020-01-09 10:36:42'),
(42, 2, '4ca9c8173ed2ce22f28005b90ce157d3fa8929fc', '563f440f2000a2d407654d60a8600837dd8b7368330ee43aa4f99ca6bf351b53', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 11:38:06', '2020-01-09 10:37:30'),
(43, 57, '272aa7d722ce457f58e165514bcac56baf059ae9', '3359fdf463b16d5eca1adb9d4437e9253aa6231f2c047e9f0d748b5253e02b89', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 11:39:53', '2020-01-09 10:38:42'),
(44, 55, 'c2f39a662e2bb6bb208561e5dd9550b9bf2dea42', 'a3740a1eec9fa209f66900e78c4daa268a7f0d4c87741f534e9f129c223f0567', '77.168.28.99', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763', NULL, NULL, '2020-01-09 13:32:37', '2020-01-09 10:47:59'),
(45, 2, '38dc4d3bf0df12395930137efa7e4213a6b1e8fa', '2240e777a484eb6263ff18df2a955d0745e428a97d07906597768cbf5e54b674', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 14:32:29', '2020-01-09 12:26:05'),
(46, 2, '4e8854ad682c35e9f4cb1aa318ff4c2839848dc4', 'b4ada008f778a7a7a784eb5e9e9d6e04d123620d21883ec2f5f5f9d8d5f64660', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 14:48:00', '2020-01-09 13:33:40'),
(47, 2, 'c9f7d3c506211d80ef4fb33f7d42d908cf768d9e', '99cad514b05eb86706f7c2f8d9e71a8d6a0a312f02c341b4134f297a46f872a0', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 15:31:41', '2020-01-09 14:16:32'),
(48, 52, 'dfc6d599cb057b08e3073ddc539d31651e0ea2a6', '31276df35ff25eeaa7912076d4c9151bc8f403be1fe32beca7a070e969630d24', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 16:38:43', '2020-01-09 14:23:34'),
(49, 2, '4f120223e1ad6331bbd5b0b41093572f303e04f0', '4c50e87cdf1fc56c0eb5171166103dcd2d871c2f94963c4751e5cbcc13d39c08', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 16:18:27', '2020-01-09 14:44:35'),
(50, 2, '6af87fdc704ae88bc56e1b215c437b1c6f465a56', '0ed46a3510c87b54e6c2daf67c3d1d0b319aa93fd40d83120fa16675364c57e0', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-09 17:03:16', '2020-01-09 15:59:47'),
(51, 2, '666d5d61272f7497cbfe1a123f963e9d44e25356', 'e53d21395c7419937f72274405790f8347c29c569aa17a0d7bf154641bee5a24', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', NULL, NULL, '2020-01-10 00:14:19', '2020-01-09 23:13:23'),
(52, 48, 'af6ebf4cbd9df441a7bf585e2eec3f9bcf8922b3', 'be43d7a577bf9eb4a98162d2b1efc1889bae01ee404e3b654a86989814bf0bff', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-10 10:06:07', '2020-01-10 09:05:57'),
(53, 52, '6de2b30ec9e0f7226432f0e5df90eb42692fc9dc', 'b8d48ab78b7688c0f918a9bee0200044cbc1d6dd2ecc969f0d5ef720cb2a259d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-10 11:32:33', 'user action', '2020-01-10 10:13:10', '2020-01-10 09:12:43'),
(54, 47, '0a2c754bb21f8b805260f6ba79eaa286994ec93b', '81271d430b162309ef4a1cb6920fff33cf1609d35e257697778ca4f8e0c689dd', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-10 11:12:08', 'user action', '2020-01-10 11:11:40', '2020-01-10 10:11:15'),
(55, 47, '4d9acd4f1b83d995ce9681c908737e84c3386428', 'f90a261c8a503eb4533e0139ac4577ffac7d5e5cc6b7815511e3a95fec36708a', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-10 11:14:19', 'user action', '2020-01-10 11:12:17', '2020-01-10 10:12:17'),
(56, 2, 'bcc383aa7b0f3233e6da499550b304949d814861', '428b8a0e39a46ef88e303fd73e34ab9f3f7d3f4e92171607e7e735d5dd1ad63b', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-10 11:35:58', '2020-01-10 10:32:48'),
(57, 52, 'bec0a6590e3f3cdba9afe8de8cafc3a248b70efe', 'b4583c33a702c4cd096974bb513dbedc8f4ca7d6c75fb771564188c827c0ef5b', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-10 12:15:15', '2020-01-10 10:39:19'),
(58, 48, '8aa76f5641125a82ee109df9c5c03214cf33535f', 'aa278f5b3931f8746ff9d49f1e34d0f3997e7e7428a30fb5f661b270f9c545ce', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-10 12:58:09', '2020-01-10 11:46:05'),
(59, 2, 'e8b33d668703fad05d58d72dc42eb8a131997717', 'e456c9ec1af669b0c0d056724d2c0eea6d20c0be61dc3241aaa3e6ef866ada8f', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-10 14:09:06', '2020-01-10 13:07:45'),
(60, 54, '737abe0826b4f5ce2f086590cfcd88da1031a251', '3bae68ef2942fca7dc9bce081024e243250dd30d893b80a05fbce32d72d3b578', '143.179.78.117', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', '2020-01-13 11:03:47', 'invalid secret', '2020-01-13 11:01:52', '2020-01-13 10:00:23'),
(61, 54, 'a7824180eac17097cc3355cc56be4ea4bffe7503', '600732ea8555a23a3405b3e7108cdfd84ba3df7c0042298c6e0668603c782d5d', '84.241.203.52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-13 12:48:31', '2020-01-13 10:03:53'),
(62, 53, '531e2f08abaaf5938547648798472546fa2f2edd', 'e28bb04efc525d59687f1553c58a32cc183f11d0e674f2c0b49ae3f6b43fdabd', '84.26.112.157', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-13 11:22:56', '2020-01-13 10:13:47'),
(63, 54, '0588ecdf6522eb2afe7a72e298a8e2436e6267f2', '2ee2c6145ce73107901607a065c00bc6502b845f9b483714a23e045896acb61c', '84.241.203.52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-13 13:43:46', '2020-01-13 11:48:40'),
(64, 2, 'd8ccf7621b809325ad9f97cafafee056654e9c5c', 'a9add10f1daa2f108b8205c16aa1e7c6fef3c4196249959a475fe048902f8288', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-13 14:58:38', '2020-01-13 13:53:32'),
(65, 2, '691cb86c50fbca5f9d26746221e094ca165248e7', '467abdb032ec994d454681a445c1cb7434a4aee265fafd53632a72cde9077b05', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-13 16:35:13', '2020-01-13 14:18:05'),
(66, 2, '8a7c3d670bb8bcdfe4fa837fdf101aa9bcc8acc8', 'a811b53d3d33386afc228e45ec5135bf726914becc92e9b8144775b6c2fb19bb', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-13 17:03:26', '2020-01-13 15:52:18'),
(67, 54, '00b734c8e22a1b7525e021d3642827a6d9d6e924', '5d04909996609289768d9c84518a5ec8506f2fdb60fafb2611e474da593aaedb', '31.201.239.179', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-13 17:28:51', '2020-01-13 16:28:31'),
(68, 54, 'b6fd65a328335d855334f6ec4af78cc851cb23e9', '3da7e80c1c6140d10191cebb035d9885931a5d6c5c452eb2e26457457e0c6de8', '31.201.239.179', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-14 07:08:13', '2020-01-14 06:08:10'),
(69, 54, 'df14fd842886f10215371895514108093a6da23d', '2990c6fe16af51ef60ce1c5eee4358fee007423e124470a1f5c045e960f3219f', '31.201.239.179', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', '2020-01-14 09:53:51', 'invalid secret', '2020-01-14 09:09:31', '2020-01-14 08:09:23'),
(70, 54, 'b579e80250693320a7aec0cee2c76940a6d9670d', 'f8ab50290d5861df7593c0f05cf883876df5cd2f5cd0a24dee19df13ff7bccaf', '143.179.78.117', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', '2020-01-14 12:24:17', 'invalid secret', '2020-01-14 10:29:06', '2020-01-14 08:53:54'),
(71, 47, 'e8e520a010a8b6257bf2377f5e392856f1a2f8fb', '22ff4c2582df5acbc4dbd6cbf0b97b458eb48f3c0d4964dc1b661dd487888093', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-14 11:08:16', 'user action', '2020-01-14 11:08:12', '2020-01-14 10:07:23'),
(72, 47, '27f1d783dbaab9cd8ac193b742ed0c3c9c8e9f62', '4b12f0d0cbfe45253d40185f7ccbd7decd82d83a7b0480b0db1123ec089e0d4c', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-14 11:10:00', 'user action', '2020-01-14 11:09:57', '2020-01-14 10:09:11'),
(73, 54, '2e921cbf5e71ba8c6ec1c1cbb4774243e55537fd', 'ee49ccfa607a0e9155976cece841c92cb1a59de06bb355ee472c30ee921ce5da', '84.241.205.45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-14 12:24:22', '2020-01-14 11:24:19'),
(74, 2, '0e31f78b1d2030ca600ad23e79aa2baafdcc7ee7', '770033730713001818bd320c3970602b2ad40c538f43bdd3310de27cdb01a165', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-14 12:52:39', '2020-01-14 11:51:48'),
(75, 58, '4e6e8e065d3137a5e4028eae57267b98eed958ba', '5f2e46a9f394d283de37971eff27521a1548dcfba2c0086a99c0aeab8a384c85', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-14 14:52:03', 'user action', '2020-01-14 14:50:49', '2020-01-14 12:58:27'),
(76, 2, 'bd9304ea855a5234e6de78b1966a79527347cd05', 'd0cef60d069c7323c8e8e6d5c0ca75a4c19ccb85057d04b8683a1a4ba194eb56', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-14 14:38:27', '2020-01-14 13:07:56'),
(77, 2, '0797f26d502f4d6ca2edea68fda58460b56ed76a', '5257879671bffd10001bd23db55ee356a8f775d57228e1dda59869a866104068', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-14 16:14:47', '2020-01-14 13:48:44'),
(78, 52, '0e9ebe0b8fb923dee11cd45897774420a624618e', 'fbd4e98bbf080432aa307ddf2d04010a973f006770f8b7ce34427d1341f31f59', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-14 14:55:25', '2020-01-14 13:55:25'),
(79, 54, 'abb3310a3fa38582daad52d236ea3ec3102db938', 'a8663c3dc0d337d060120631105029495149ae1b0ab03225b5a0dd96ea8edda8', '31.201.239.179', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-14 16:28:34', '2020-01-14 15:28:34'),
(80, 2, '76f83541a1ede7077d7cf03441f57da7740bf75b', '7b0deb4060999079696426c2ee6a2d879ed2d99549c80a62821f04dec0bd2350', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 06:50:41', '2020-01-15 05:50:39'),
(81, 2, '5b413b7abcaa39fb23cb91f337cc0222efacb480', '1cc6cededdc7f2cbb101903849c549f4b5dc5e9b0ab463d40292d586260533a2', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 09:30:06', '2020-01-15 08:29:54'),
(82, 2, 'aa863f0f60591090dd0e6f0e0eab7f1da729d979', '489771c6f73df5569ff6ee424d98ee3436654a612a014a7cc21abf561b3a0914', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 09:52:46', '2020-01-15 08:40:03'),
(83, 47, '5c68c00c63dd9c5aaf9f53365077fbfe9efde4a1', '4b77ec80cd658db357c8166042210af2b041b17e2e6ac5948daee7083d207899', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 10:35:03', '2020-01-15 09:10:56'),
(84, 2, '328cc386836d93af772f3b08c378c8d7a4403c45', '20fe14c8a08ec0fe654e01e612d0db49f7c0b8c33f58707470ba019b520ee275', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 13:11:30', '2020-01-15 10:39:55'),
(85, 59, '454bd82139b4c7fbc2f4902b1abca7f7c277d635', '6e62ec182493052884391e07dc891f9c1cb444bb1d458f9e91f022e18d7220b8', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-15 13:11:45', '2020-01-15 11:08:32'),
(86, 2, '937aa2e696cb54c85fda9503006c6716340a62b7', '0f2b1458ca603e1a5246db4f2b581778260be0697f19b2ec10819aea24fb84b0', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-15 13:23:29', 'user action', '2020-01-15 13:13:05', '2020-01-15 12:12:40'),
(87, 47, '174b0ac04bc49f831c94beda9924e0f9dcb4855c', 'c36edc630ad29ea4fd95a564804ea627847cf8a1ec7e4b45a67374b779a1fcb7', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-15 13:15:48', 'user action', '2020-01-15 13:15:36', '2020-01-15 12:15:27'),
(88, 47, '21ebc4a33caa36a281cc02dcca6a2d0b6c17648d', 'a31c4d120932376264ae3af751065e75681307a652b9c09878870947bac039f4', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-15 15:11:40', 'user action', '2020-01-15 14:52:44', '2020-01-15 12:15:51'),
(89, 2, '9052ff55537bb997dc4df8fca9010757783b0910', '9a68f744501da0adc22ce9ddfb106a4bf6cf2f9ff64c6aa88bfdc742c64d8302', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-15 13:24:13', 'user action', '2020-01-15 13:24:07', '2020-01-15 12:23:30'),
(90, 2, '0b3e93a66e47b346b238dcadd2f43cfa0d1c6584', '5982eecefd0eea872e67cdea0f41da734a5b1e3169cebf52cf6da2bce128dac2', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '2020-01-16 14:29:40', 'user action', '2020-01-16 14:29:36', '2020-01-16 13:29:36'),
(91, 2, '499908112819b7232f4b861c46dca4b45c011282', '9a808a03533b02e8cc0e114c252a6b906ea9ae12d4a71416cba060da1aa258f4', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-16 14:34:25', '2020-01-16 13:34:17'),
(92, 2, '372fcdc715444edf1c6f8b000ed2f0514521b2be', '6c7dd7bc22d5259d7bb3c7814f9e005bf56937e189371cbeb2a883d8168e986a', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-16 23:31:24', '2020-01-16 22:28:03'),
(93, 2, '29ff9705f10b910bd92db98ae1aa09d308ddc5f3', '9d54d401384f02ba2429781fdc36bc113d2acd2c472ef642ec68c0f461b6afc4', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-16 23:47:49', '2020-01-16 22:43:31'),
(94, 2, 'd8259a9ac8a771ac2f890c3c07c1babe6ca60b1d', '12c592fcaeebffcf83c78e9ff55c557cdc0f87415d6e1610b0ec1fd93a3a0ae3', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-17 00:24:38', '2020-01-16 23:11:49'),
(95, 54, '31b83cfaf64f9ffffdb7b1262216a3858280d4c1', '436a6a4f0d0d48d030663863ca70c4697a28c91c49e989d1f3e9a0e5b0648f6e', '31.201.239.179', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363', NULL, NULL, '2020-01-17 09:42:01', '2020-01-17 08:42:01'),
(96, 47, '2c86c1b28300441f709966b6d7a0ac0c03570ae1', '904719b685fdbe2c0bac5d0f6a158f6b89eff1b8039f1e41c766cab8ce650696', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', NULL, NULL, '2020-01-17 11:28:25', '2020-01-17 10:28:09'),
(97, 47, 'b172a4eaf7a0b35f87f7d125fa2ac5550d62651a', 'c769170a7848d82dc25f8f643dfed4b552dcaa363e25b7cb9b16b0bf58be5d70', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 11:30:56', 'user action', '2020-01-17 11:30:27', '2020-01-17 10:28:51'),
(98, 47, '59b48083f58f8c643dea98a6b44c8702c807c87e', 'fe88117a70c8c9d487d7f80f3bcf62181edb708b60a7b4896f91db951e412f57', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 11:31:42', 'user action', '2020-01-17 11:31:25', '2020-01-17 10:31:25'),
(99, 47, '9c3cdac949895d7edd658b2062c22c93385dcef2', '9473d9dd27940e455f29091f2e4df52b00391704b67c682969792d15a4c7ded0', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 11:37:52', 'user action', '2020-01-17 11:37:44', '2020-01-17 10:37:07'),
(100, 47, 'a293e75343dc6cbe99392272521059e6ee64e610', '9dbacf015040f152623193c0c41990128ebfc4ce4869275a5ccd935dc4052655', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 12:55:50', 'user action', '2020-01-17 12:55:40', '2020-01-17 11:55:28'),
(101, 2, '5efcf7aa333bedc781c59d63feac89b0f72df5a9', '5faf8bddc710ee367b57313e2be8febbf9904cf22ef4cb9452bc0ac4cbe4bc6e', '82.74.122.107', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-17 14:14:03', '2020-01-17 12:15:35'),
(102, 47, 'ef2122ab981150ceead1ace96244baf2a6353959', '94bd85d6baacba21292efbd06064195f6b4b7d5a49ad2ae4b4f4afb320fc635a', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 14:20:00', 'user action', '2020-01-17 14:19:55', '2020-01-17 13:19:06'),
(103, 47, '42554fbd74bf2323865a2c31ed34565975402620', '51dc216895f8eee09e67d67cb6c7ba834a5fb7e68d874fc37055df486279a168', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-17 14:58:30', 'user action', '2020-01-17 14:58:22', '2020-01-17 13:58:22'),
(104, 47, 'fdf4c0721fa6ac0e377dd0d492f2f3a8f37a9f92', '9c40606b46be872ab505ecaac0f82ad5850dd2bc48bc53a791323f2c8c2d7e2f', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-20 13:54:28', 'user action', '2020-01-20 13:54:05', '2020-01-20 12:53:46'),
(105, 2, '3a0d5eec34c652b00536a432b3cd58322711c6dd', 'f88c53391769a46c9c8ce6e88e98349e94e1b058055924359301681e05f6a0dd', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-20 21:17:03', '2020-01-20 17:53:28'),
(106, 47, '548e7c548a606d1e96d3cee39b5873718b1c0658', 'd6d105c9a6d280e6ac9607a84a0aa0c21437aad7efb203a7651f8a8d563943b5', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.116 Safari/537.36', '2020-01-21 10:45:57', 'user action', '2020-01-21 10:45:40', '2020-01-21 09:45:40'),
(107, 48, 'b59fdb5375a11f32f9ebdb7f3a894d6ee11c4253', '1c14f50626c1b7dda42c6bc76a25c814cf4ed6caff766e09f52af78ac61381b8', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-21 10:52:20', '2020-01-21 09:50:49'),
(108, 2, 'a4b75fb65d780999392d59d9130264f1f3fdc9a7', 'b75ded76499649d81910c36a032f1954695c0b36c8ba5318b00ac811b1e5b453', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-21 23:24:48', '2020-01-21 22:24:31'),
(109, 2, 'd7253d9e9140298b3274e2fb8bc7697240c29224', '7b1f884aaad38c67ed8293692e4d11486cb738edb93af4c89994568350fe2b77', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-22 09:40:47', '2020-01-22 08:39:51'),
(110, 48, 'e929544a29a94df1fd2cfdfe6cce3386665d33f8', '7bc111ca1058b54982ac144bd8466394dae959fead110d7982e1eec1042a06be', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-22 11:54:21', '2020-01-22 10:53:09'),
(111, 47, '3add1f58b781a3701e59fda61fc4990e0a33fa72', '1ef902f9b6d2a88d2b1dd0c584a94e246b4224030c2b9165bafbed3abf7a1935', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-22 12:56:45', 'user action', '2020-01-22 12:56:34', '2020-01-22 11:56:10'),
(112, 2, '7dd4f63ccc7c21af0a14b50bd72c0c25175fac04', 'a2206697506aec93f68abf5cea332e5c266af9cfecab5dac2f718e24a1092d34', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', NULL, NULL, '2020-01-22 13:36:18', '2020-01-22 12:09:01'),
(113, 48, '5075be91aaf03901b101c09c7617498e738fe422', 'e8fceae807aaa8c270d6784d6e30a90f17fba9b197250b046bb3f704ae963193', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-22 13:29:02', '2020-01-22 12:26:39'),
(114, 48, '175967705e4a883a0453c522e5bd6706b049d7dc', '006dadda61ed1246e18d0a4092ebd7b8887b2549387d10d86d12000c7c8f4ed7', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-23 11:05:48', '2020-01-23 10:04:53'),
(115, 47, '7094b63bc99b8e9dab3147e8dd20ebeb067b6a6d', 'd63b59f5aa8a52b805cfb20252a7fb2a1e567cfd14f67ad737ba636c1933ad0a', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-23 12:09:38', 'user action', '2020-01-23 12:09:27', '2020-01-23 11:09:04'),
(116, 48, '01007074ad060522cedc7642326e4ae2c43e517f', 'babf2bcaa263b6f22281d3926904ad2ef6ab010dec93f871fe7242932ef030e3', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-24 11:00:47', '2020-01-24 09:59:21'),
(117, 2, '0aa491812e142d4326efffb4dae98bf7a5099bd9', 'dfe7873d0adfc6dee97ffdd8b219fc229a963514bafdb542c58036093c5d23ac', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:24:59', 'usermanagement', '2020-01-24 12:24:59', '2020-01-24 11:08:27'),
(118, 2, '539a8774516989ffd89cc770d708b44be7827e74', 'e0b8089a4b7488fc1066e42db16c1cb66e65cdc5448f02c52c26d246a65a5027', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:25:53', 'usermanagement', '2020-01-24 12:25:53', '2020-01-24 11:25:46'),
(119, 2, '8a79f14256b3780f7aa230fb73231b3f779b2edc', '57e6e4316efbec6a5afbf51fa45ec878ae0b3138f480c3399ce715523662328e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:26:31', 'usermanagement', '2020-01-24 12:26:31', '2020-01-24 11:26:29'),
(120, 2, 'cae099a8f14f0d1e22c5c02526d4a34ce5f18a0b', 'd50285f97f0faa0c6cb891829363175c6679726153f664c794934a03b80b6b86', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:34:38', 'usermanagement', '2020-01-24 12:34:38', '2020-01-24 11:27:49'),
(121, 2, '2fa20df7d26245eb810c6ec3d36bc1c4eb6865cf', '2bf17fdd8cc369a4946c5b68c5433c7f40273774171c115b8ed22d7b31710531', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:35:02', 'usermanagement', '2020-01-24 12:35:02', '2020-01-24 11:35:01'),
(122, 2, '1713b984eebb404ac8f6577db414e9b8a46c9582', 'fa27657b518129c87ebd1e0d52f9f6e449e6fdeff41598163246e10da0f31ed2', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:42:12', 'usermanagement', '2020-01-24 12:42:12', '2020-01-24 11:42:09'),
(123, 2, 'a720ab8a8f714901338d4b79d65cee6d6378237f', '12d165fbe8c7b747a1097d02a63a03e83e744a68c0a2d7f720ce4e5a550330f5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-24 12:44:16', 'usermanagement', '2020-01-24 12:44:16', '2020-01-24 11:43:03'),
(124, 61, '3a38294c7803db6deb38059a5ec0d42aeba6722d', 'e8090a7bd297115ad963d3fcb8c18943dd0b5b25b259d71738d416cc65b82e48', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-24 14:53:41', '2020-01-24 13:48:10'),
(125, 2, 'f5184a59a83a09f4343bd3f7ad7f2248b0138ee2', '011f6e66c96e1953b16293dd6edbf53c442cad842a8a95796b219d8fda0bfa80', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-24 15:07:30', '2020-01-24 14:06:43'),
(126, 47, '660f5c1d9a68266993eb25675a09f8a987d22661', '8dc5ea2b32009ec4d4a0e2d16065452b701af6ec51e2c5e274b4e7bdd3a80a6a', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-01-24 15:13:51', 'user action', '2020-01-24 15:13:39', '2020-01-24 14:12:57'),
(127, 47, '143dbdaf50581a7847e3e5a046bbcb7784ace823', 'b96f576d9e8f28adaf3088f2d704abe833a75e647db7697dfa6c1e72d7fd0114', '213.127.58.114', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-27 10:58:12', 'user action', '2020-01-27 10:58:02', '2020-01-27 09:58:02'),
(128, 2, '1881f35c2fa3ac7af39794dddbbb49a4d5b6871c', '7c5521446a9a6e61494c6353af0ddfb3d7cd8bc683ea3af0fbf3d2296c78facb', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-27 12:06:47', '2020-01-27 11:03:49'),
(129, 2, '885be60312d7bfa072b6171a3b15d1189e281088', 'd54788907a33e7ed74ef90ebecb4f8cef575465f48684d405e10381c4f042ad4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-28 09:20:03', '2020-01-28 08:19:48'),
(130, 48, 'a4f0cef0f88cdcc7d042e46337eacc43cff61247', 'c836a7e1526095167334b9fe4f6d531b389e400bf61d602282958aa76d39e48c', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-28 13:16:19', '2020-01-28 12:16:02'),
(131, 47, '3dddd244db9139295b3199ea322231d8f129ecaa', 'cbe16bc12f7b33e3225d89dfb421da8cb2c8a6464c50f1ad1eb43856b497af38', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-01-28 18:00:17', 'user action', '2020-01-28 18:00:06', '2020-01-28 16:59:57'),
(132, 48, 'fa01f47c284f69085b21919b54e897b87177e9fb', '2d5b0843a921db70a31abf29af762a74a24f78a2bd94ef0fb446b2ff961edb45', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-29 10:18:59', '2020-01-29 08:52:12'),
(133, 61, '9cf0fc22b846d12221ae5ca64dec2c91038ff643', '820e71b80fbe186e532e43ac486a02252689abb4ab7c1aca4f22409a774230a4', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-29 12:43:02', '2020-01-29 11:42:52'),
(134, 47, '73408ecdc47be8b7db3b1e5728ce508c395f0b88', 'b378012179adc9c0da18dcf1b89b4ac887c9b95369fb3fe19cde5f427dff830a', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-01-29 13:10:06', 'user action', '2020-01-29 13:10:01', '2020-01-29 12:09:49'),
(135, 48, '3ccabee72607426d4a17ecb7caafef662c57791f', 'cebbd03a6d47176ea3f1d93365c6775bbd34c2fc18efe46a7fdd59ec689dc43e', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 08:49:14', '2020-01-30 07:39:51'),
(136, 61, '5543ed26175ae7170c5f6ef24084cfd217b96f8d', 'c4dc43aa5eb111ab371a55a562b013eb9d3b68ab5e7c8984397f0eb2554e121a', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 08:40:34', '2020-01-30 07:40:25'),
(137, 2, '3eee39906cfdffd8fb0a444242aeafd93e06466a', 'a67021648b52aaf9c20f657ce6866067e570ffaaecc80b6e7128a3a1dfcf9087', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 09:46:25', '2020-01-30 08:46:15'),
(138, 61, '1c52d40c8d4b3ee807c6a6ab28a34cf11beff56e', 'df62f37d26274aef83b4cfb4834a4060094b01aa5643b52b7c3c5e8032f440cb', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-01-30 12:36:03', 'usermanagement', '2020-01-30 12:36:03', '2020-01-30 10:09:06'),
(139, 2, '75afc6867e782ff03e3d003351305249c9c72707', 'b3c001ee0674dba74dc9257959c800a9a8b7e2a525f855cd332e8448c7bbfa94', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 14:24:18', '2020-01-30 11:23:55'),
(140, 2, 'c97b4929be73617e4fca0a21a93f35de0ead89d0', 'e1cbbdf292f32ed4dc9a4e65ccb9335d8a9822ae3a52d41ce0de63c4d518b225', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 12:50:03', '2020-01-30 11:28:13'),
(141, 48, '47f3b21ff290e3ee2b9215c78b43112ad212a6bb', 'e489e7d77556aa90b4739d17df3a1bd1dc5ff713b42bf975a74437e2a5b835e8', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 12:40:42', '2020-01-30 11:33:38'),
(142, 61, '95b6fe67e908c82fcd1218f14ad9e9f98e717671', '4eca4111c1bd5a6ef94146bfe6ad5a4f2622e0f70e44d2d8ee9e4372af9e39bc', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 12:38:09', '2020-01-30 11:36:11'),
(143, 61, '7ada01b134dc4cf9808de9842e1e88b170b4e868', '95aabc5a07cdf4dff155d03a1a3db454515c205d801e685e077101bc50ae6cda', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 12:39:55', '2020-01-30 11:39:38'),
(144, 61, '8af0cf80744e79922bf80e8d63215bbe8de166c8', 'f36d0c3019a72e52f65bfa7b10ddef8f0c94e788243c253610b0ba108847dd5e', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 12:41:24', '2020-01-30 11:41:16'),
(145, 61, '5cf47e846e5ad854527d0d0608ab1f58a7f0ce09', '3c46de318124527144e35a34190fcf33622c81f1f137efb7a23b16cfc77128b8', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-01-30 13:34:47', '2020-01-30 11:42:56'),
(146, 47, '5d0acf73ba5f63747855e6bae1dbbc393faa7b9e', '74d58e7a630263ef1a95d8ce628e1be633169fad3a10f6c6a511d2c528d76370', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-01-30 13:06:40', 'user action', '2020-01-30 13:06:33', '2020-01-30 12:06:33'),
(147, 47, '98c6d0776429629a0467e93aa0bf59997ae3bd20', '28286e664d30a9b4007bd9e910f1646e6ace0b3997225525ae1e37016bcaa45a', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-01-31 18:26:34', 'user action', '2020-01-31 18:26:23', '2020-01-31 17:26:23'),
(148, 48, '3dbe40417b07be19901b4723561c549977f2a8af', '2c3d804d36f1d190a007870ba2426459143f804a5a836143a43ab9c5eade2259', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 13:18:42', '2020-02-03 08:52:24'),
(149, 52, '7e1263e3ac5cec9bd03b5a02661a21ec0a0f0bff', '7eef95be8233dea320804fc799281db1273a5a4bb22ee07f180e89a4e1294f04', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 12:07:40', '2020-02-03 09:29:03'),
(150, 2, '5877144cd19e55d16b53ab74b71e229ba4905945', 'b5621125829cc841c79c73884134f29782e8aeb646e9a311243cac28f68d2a1d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 11:38:37', '2020-02-03 10:37:29'),
(151, 52, '6015bd110f43ebfcd034d1a338905c270d1515e0', '0a01b7126911b8aba7e57f8b20c9910cd1d0e5f1b5eb57825ace5298f590dd18', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-03 12:12:01', 'user action', '2020-02-03 12:08:53', '2020-02-03 11:08:23'),
(152, 2, '1a8f3ee9e7f5ec934918e6864df63f7dac52a6cd', 'dcc30b735c8d0d7fab555ec27f4b2535bb7c517f4931faa297efc51d3e98cf28', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 12:15:44', '2020-02-03 11:12:26'),
(153, 52, '8af047eee59419680a996bf6d67f96466c300e9e', '7fa0dcc2cd212bcd7d0b9f7e358aabef8a85913dd3d20c8d7cbf20c2cbdadb1c', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-03 12:13:29', 'user action', '2020-02-03 12:12:42', '2020-02-03 11:12:42'),
(154, 52, '38da35cfb31c11ed343fa28a351649ee3724a924', '90d2290adada28fab4c7d84e831ce33b77bbef1a115611f54618dc52583aeddb', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-03 12:13:38', 'user action', '2020-02-03 12:13:35', '2020-02-03 11:13:35');
INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(155, 52, 'cfdcf826dd41f6bdcd99ba82c1b30cfebadcb9a6', 'ee1667eb31388152654337d7533a76f900fd89f31c01930b518d8d7753348abe', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-03 12:27:16', 'user action', '2020-02-03 12:20:42', '2020-02-03 11:13:54'),
(156, 52, 'a054e812fdcfb9b03776ec1e1f85982f4b18070d', '0f2f67c2a7d2a00ed1bfa7ab0223acceb049dcf38796a1b29286f4c3e277d798', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 12:38:21', '2020-02-03 11:27:23'),
(157, 2, '0daf950345ffa324c4f505317fd575821f0caa33', '467ed4e6bc3265b5455b2586255f41a348224db990584215ee75b677c100503b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 12:45:10', '2020-02-03 11:31:39'),
(158, 61, '0b259b3a010fe6fc7d5888d3aa73714e6d26e662', 'd5b1f774dbcd2347d3f83b54a77ae14f384eddd8ad5b0525b71d6b826eaed074', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 12:52:34', '2020-02-03 11:51:04'),
(159, 2, 'f8a6902595fa213de8c2b395fbde77cec139e229', '6e4f61d4941c77d31981f0b57434932f874a3997d3c707c5d73a044e003765d4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-03 15:12:52', '2020-02-03 14:12:20'),
(160, 2, '079f2990dd887406f3ba571f4c2ddd4e68095a26', 'ac69ba5b0219d1fd9a78b3d96d812ab27886f8746b10c2218fdee764190abab4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 09:13:56', '2020-02-04 08:12:21'),
(161, 2, '267538457fa9c7a851a965c648b808d83499dddf', '532b0136b1227bd21313a55711403521bd9eb605ffd71e89e8db953d455479f8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 09:22:06', '2020-02-04 08:15:06'),
(162, 48, 'b514906dd6392a698033d6f99b23abc5914b595e', '47ebab92b8d817bc22501d094b19f9f344085a9a739cc6a5693802cf18c10a57', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:10:04', '2020-02-04 09:07:24'),
(163, 2, '8cf56c5a1c70d5932905290dcce2f627369852cf', '3f8251261e8c5ef65ec1648fe915062ca7250f168828a7643de71d0ede91e96f', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 11:15:19', '2020-02-04 10:15:19'),
(164, 2, 'b76507dd5814bd5d571be83813beca90340e572b', '06ffc566f5bdd620d5dd66aaf13b2d110c99fa5e416a05765eeca58ca9e0691a', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 11:39:44', '2020-02-04 10:36:42'),
(165, 52, '11441e2d0e28e75993c108a0122ad35ffe358cca', 'a0a681fab70f76d88a09bd515b07e22fdad6239dcecbb4a209b54687fafffadd', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 11:44:55', '2020-02-04 10:43:52'),
(166, 52, '689111a91a3545acc71be76ae6ce835409000f1a', '105010e074ca12036e5b85a40b58523afdec3ea288a30217849b9254c092f98f', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 11:54:51', 'user action', '2020-02-04 11:45:30', '2020-02-04 10:45:21'),
(167, 2, '2ca53986f9957f4ea318a242e4a40e965cb80461', '351ebfe101c714c7ad3fb7216d377cd38070b4fcb42bfd1ce1bc9d5ca69782e4', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 11:57:14', '2020-02-04 10:55:11'),
(168, 52, 'd54d0bf99d54d2ddc9a25f4fc3e5e451d5eca471', '93cd7f5f1ca838b38233bddb14e620d32abe36b763c9ff3a3cd37d9bcf7cf166', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 12:23:35', 'usermanagement', '2020-02-04 12:23:35', '2020-02-04 10:59:44'),
(169, 2, 'f78d11a5a5bddef8912e901f5b300a6fe6fc0078', '5d63f6cfbe2138bfece6b0eb8a341f112c879f5db38741fa80a9a60d7dbe2af2', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 12:15:16', 'usermanagement', '2020-02-04 12:15:16', '2020-02-04 11:12:59'),
(170, 48, '5b1ddaf490152f57cda7fbc3af7ba126f6d52d7b', 'bd148043182dfc17fba35e4439c324f20cd7284f6289a1ddabf5f29b51ce8d4a', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 14:06:04', '2020-02-04 11:13:02'),
(171, 61, 'ff5f36b308b708e181c8ceab8c9252418e1b5828', 'b81a646ff41f67da174a1e7c9c14623a25a59b019f81d15ac9b87f5d787212fb', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:30:54', '2020-02-04 11:23:17'),
(172, 2, 'e6dda06accb5d56336599e96d4eafce6684984bc', 'e583d2fbfed3209845aae0d2bdd5fb7b45a84f7af456966d86e533c454addeb4', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:27:00', '2020-02-04 11:24:00'),
(173, 49, '89efceaf48022d89495e3f8970a2132789188980', '546d9864b80d76d10ccadb6eff965ac565305851298a783d471bf221f951e4bd', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 12:29:25', 'user action', '2020-02-04 12:28:25', '2020-02-04 11:28:25'),
(174, 49, '6b419b2f60ec4a5899fb86d1737d09f88a709cc5', '2a2c1bff8d7ebc72484b48ab4b7eb8e3b8d8b46837ea59d74e969d47537b06ce', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 12:32:59', 'user action', '2020-02-04 12:32:48', '2020-02-04 11:29:54'),
(175, 49, '5f847bc783779731a4b0a06d2930fda3b27f55dd', 'da3a2b4022f79b710d0e1f74bb84edcdfa32c625675852489134894a834a661e', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:34:36', '2020-02-04 11:33:12'),
(176, 58, 'a5195101ed323681b6b3b31d9ece5360d9d83ace', '44b4466558736e92d1e03eb9bae220dc2ae463350d219f778eec88fd5ee8a5de', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:49:41', '2020-02-04 11:34:56'),
(177, 2, '242d6600cd612e108bf13967f82e61f0e619e52f', 'f5901b3693d4d3a85e68daf181ae848c54b5492050b89e523d37e5d0c08f486d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 12:55:55', '2020-02-04 11:50:15'),
(178, 2, '139df50768d70b339658d42de53b9e1d05c73c26', 'eae8a6cf14c047c6ef285a8ab946e2468fe24f138140cfd9a1c987ef5caedb3c', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 13:13:17', 'user action', '2020-02-04 13:09:16', '2020-02-04 12:00:23'),
(179, 58, '042c070f68fb9c7248165f80a7cea58e154376fb', 'c3615dc1574379bb99d8930d5d5ea735aa5908e256558124c484200ef1216a6f', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 13:45:58', 'user action', '2020-02-04 13:45:54', '2020-02-04 12:12:26'),
(180, 2, 'b3cad80ee4b56095464b40e62e2e42e946e559ec', '34b136ab6436d58d4321bbdeaef57fc137e5370d577202cb4410577e4558f89d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 14:50:29', '2020-02-04 12:16:36'),
(181, 62, 'abfa86d5ee1c9dc03ce263513195c65ef146ec07', 'e4a7c1e874fbb69f3f7b823dc6f1a4a56bded627964a60df1e961a05c9eb2a2d', '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-04 14:52:51', '2020-02-04 13:13:23'),
(182, 52, '18e98ac9e341b7551246af7b2d688b7ee02c0f8f', 'edbcecf6feb712649a0a220d6893401b4a6459ef321920ad717da14f2cc0ade1', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 14:56:48', 'user action', '2020-02-04 14:56:39', '2020-02-04 13:39:35'),
(183, 52, 'd3070352cb038dc91a59c0f7ba8b33290efec999', '3186bc717438d4ace713b1990c3ae10a221459bb1266f2a7fcfdaadb006e4f34', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 14:57:43', 'user action', '2020-02-04 14:57:36', '2020-02-04 13:56:54'),
(184, 49, '351d314dc1793088a75b1a3a47793e81c2b43766', '5967f718f9ad0068f40b091560c786f15e28b683ea2a23fd5151b63586c85c35', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-04 15:01:31', 'user action', '2020-02-04 15:00:15', '2020-02-04 13:58:01'),
(185, 61, 'c0f85e6bf2ec5bb5767f5db753b9e1035b9cd153', '350899b7793426f9670998dbe9398f5a3fc24725c22724addc10fd5a9fba3f72', '109.37.130.213', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-G935F/G935FXXS7ESK7) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.1 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-02-04 18:08:48', '2020-02-04 17:08:12'),
(186, 2, 'c2cb146191f8fcce31ceb2ce4d0fcc8c82387320', 'eccc343999b9e2405b9704adab0fd15311108ca7f1e05f181d61070babebbdd3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 08:26:06', '2020-02-05 07:25:55'),
(187, 2, '5a94f6b51163058e84a1d32a992930cbd31beeb7', '7fae85c139b888ff11bbf861c166008bc3019c488fa7e8fd11f5fd73cab8fb45', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 13:58:45', '2020-02-05 10:12:47'),
(188, 48, '6adb125fa7947516b71fb285c92be0cb526d62aa', 'cb91b999b95186a5fcd8f0637e2e9d30f7cd6926a6db53f0261242ee36d52c9f', '84.241.201.183', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 11:19:03', '2020-02-05 10:18:27'),
(189, 2, 'fbd30af4165d072d9d3f176c22a695cad1e1753d', '792f3e3f2fe0b6dd9b8c5e6b03c0cbe65dfecffc4c6bbbfbb9fecc14fac4cb7e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 14:50:22', '2020-02-05 13:50:14'),
(190, 2, 'da2220afb40f3229a83d4a99427bece1d834aa7e', '9b24d1ea8302ae1a483ce5badaa00bc84bd1c0d72f8f1f177c1044c3f5db284a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 15:20:28', '2020-02-05 14:15:40'),
(191, 48, '3e81c7f6060d4fe13cee3d8ff7a53ae8bfd0daed', 'fbc020226a7311f03fd164252638e7f37d4d4b3083770fb38c6621405336681e', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 16:41:33', '2020-02-05 15:02:37'),
(192, 2, '06ae7f4051c72276ce1db017da105db9a1e23bfd', 'e143d0735919306524bd2aded27e62f9746101459facff038f9fa1c4c528a00a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 16:41:03', '2020-02-05 15:31:43'),
(193, 2, '73c945ccdb4510e47a1f5b0b98d1cacc11ebcd61', 'c568fde73797ca88d3820ff08ecf0ddd68075a1c73f667c1ba25ef51cf8bd006', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 21:29:53', '2020-02-05 20:06:38'),
(194, 2, 'dfe8a869a572f92a401f1b00fcbb0ca586bb456b', '824fd42404683cbe5f403cf33b31c34c4ca77a8aabcd4a9b960725c68a6c501d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-05 21:45:28', '2020-02-05 20:43:28'),
(195, 63, 'd4679a7d548f3101a227a24ab7999152c58e88d0', 'ecb2c45150817b3677ed2f36b1cc2396ee2a6b4e2eae302ea57170bb18389d2d', '213.127.17.198', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 08:26:39', '2020-02-06 07:26:39'),
(196, 48, 'af0725edbe9776974f3eb3e24e528adc961ed91c', 'c1ebce7157f31976b1f308c0a8657e40a14abcb83bda8389c3591bb5c91095be', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 10:23:59', '2020-02-06 08:33:38'),
(197, 2, '15bd47d1b330c6d711b45073172167c222c11c61', '074608d8e73faf09592ab79d8e55247923a658ae966c4b5415331c3a24793123', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 09:51:44', '2020-02-06 08:51:44'),
(198, 2, '5da7b3af39b42eba00df79467a9204eb72000a5d', '66bf488ad5b0b21fee73d30d5c4ffee4ee97f953c79ee93932bb54abc5b7db0b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 10:02:45', '2020-02-06 08:57:24'),
(199, 2, '497a0335353c26a9c565a1de422c3155f1d6411b', '22a74e02b11d453d1a6b9e52ce76d1143c37b8648f62554045abe202c1c482a4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 12:44:28', '2020-02-06 09:03:43'),
(200, 62, '15c272556b60dede17bd068ddc34995e006d562b', '5eaccd331712dd22970e2d11a42b15473b6702940ee5b13728048bc82cecbee1', '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 10:53:52', '2020-02-06 09:51:10'),
(201, 58, '3ea376078158afcab4db528ad5497101dd0b7da4', '5c2d5a683ab9029a6f338aeb9c83f2e0aaad801a686294150eea06d8bea812a2', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-06 12:32:28', 'user action', '2020-02-06 12:18:05', '2020-02-06 11:17:06'),
(202, 48, 'e58e9bc389cbbbfff5a1881d36c130a3c86e9a61', '2c65b5a3cf71f78c5f4272e4d6c430af8b166ae0fcf88ee41deb0ac9ed6348b7', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 12:42:13', '2020-02-06 11:19:43'),
(203, 2, 'f6662a877936e425cff6ffe80ba2e65915aa816f', '7e2dcbf00fafa3f839e487dcdb524b95d0678ce4bf30302d031e1f4b2c385a6c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 13:40:32', '2020-02-06 12:39:03'),
(204, 2, '23fbfd1395d5a82bfa80802ca788d8fc84893709', '23986babd6cc16bea84665d92d64c2747b1fc904ce536eff8789b0674a25ca14', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 14:17:28', '2020-02-06 13:17:28'),
(205, 2, '265f5ee4a47b9ffca79582209bc6d686f7089084', '47d7d5fdcb439d9a6795abd1e4d86d6a7ad40d629379a64a9009c2a666ea4cde', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 16:54:50', '2020-02-06 15:24:05'),
(206, 48, '45fc321638e7c0461d6d9d7668d96b247a64f0c6', 'efc75ac262c0a9b828b2cb5a21abbeaf3389519ac0b950aed544682a60c00d86', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-06 17:07:10', '2020-02-06 15:29:56'),
(207, 48, '3b3cd5314558197d9e126596b6e8943ab6cde64e', '23938499c20d5b318fc6b8853742aeecefc52a05f91f5683cc7828d24da68be7', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-07 12:37:19', '2020-02-07 08:38:05'),
(208, 2, '94071fda74ad938a56813d334e7de3997f2c7280', 'c29fd0e95471013bbfac2b236feaab9847439c722f43bba7e9aa81d63e3bae07', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-07 09:47:48', '2020-02-07 08:45:55'),
(209, 2, '4796d81cd41babd2d7e1ea32f79f441d78c1f2ee', '7bfe28a7a1d13453b0d1b7cdcf1505182e78d1c149ad203dc1b46871160e59b8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-07 10:50:55', '2020-02-07 09:14:15'),
(210, 2, '06d5668153d59a34be7d75ff86dae7ddb6e5b419', '72ea88c3ef5a163689eebe7fde2b2aa3b5c1638df2c47e1e134063534d09703d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-07 11:28:58', 'usermanagement', '2020-02-07 11:28:58', '2020-02-07 10:13:08'),
(211, 61, '98f610999af146319254908e6665a0f252ace95d', '78feba01a9f5afdd5a49787585b62b41ce0eaa7194f5b5659da575b2e5f19a93', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', NULL, NULL, '2020-02-07 11:36:46', '2020-02-07 10:36:20'),
(212, 61, '410094712412c71af3b21eecd4317cf3ac6b6927', 'b51adb2eda98c23f8324cd03dd0ef73ae6b0f070a5db0880f3be34b22a4350b1', '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', NULL, NULL, '2020-02-07 13:49:01', '2020-02-07 12:48:53'),
(213, 2, '0299c55c1b63b671b1772bdcaceeecae9a0dad79', 'f86c8c9447e939dedfee1dfab1340027570349431eb34cd29e3398abf6cf6243', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-07 13:52:09', '2020-02-07 12:51:54'),
(214, 47, '1406a6997acbf2d96cb341456a0a84398b73518a', 'b612aa89c2054c35943655036443d4f23c2859a666f962a00c21541448e4a721', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36', '2020-02-07 18:25:59', 'user action', '2020-02-07 18:25:45', '2020-02-07 17:25:45'),
(215, 2, '775985a5fc0078317f4fb9bd6b2a76db285fcdf6', 'd5260f67a797b8fcbc61580947406655d8e0c765f92000aee1f07b5d0f7781f8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 09:37:13', '2020-02-10 08:30:36'),
(216, 2, 'a378a9aca40de7b5e6442febb0fd35f01ba04486', '2b80232478986ee56ebdaac228363d5e73d2ea7363188f34dac3fa0d0f1d4471', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 09:42:06', '2020-02-10 08:37:18'),
(217, 48, '2383c8f08c35215f9af8d976bbcfeb5490d6c23e', 'a0a5047bb6e23db254082580109d7d92d0080c4f10097395d7e8b5de9c340034', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 11:41:05', '2020-02-10 08:47:26'),
(218, 2, '043deddb84132e0c73bf1de186a4705adae49e93', '72acc123383cf319dd2d1a07a8484f711e177069230a46aebd4622c9ec836865', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 10:13:25', '2020-02-10 09:04:44'),
(219, 48, '91a4e7db5aea03707744c2ae534af79ff92f2bee', '7519527a104c039854f7a41ce99ce2fdda9352e268666b4beec608eb35827ad3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 12:41:47', '2020-02-10 10:48:23'),
(220, 2, '0ae3dec4d55472d3d3929879cf0ab1e6eda70681', '7bf4d39d6fdcd42a2b5f87e61976ddae3531745b019626e606badc62bd7395e7', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 14:06:40', '2020-02-10 11:18:40'),
(221, 48, '43bff35531b0a18ed4393c3bb225da55f4ed92f8', 'd039aa5af005966fa18310b1686d24245792f75e7cecdb6a1f336a8072ba22d1', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-10 15:55:05', 'invalid secret', '2020-02-10 14:12:17', '2020-02-10 12:52:58'),
(222, 49, 'e07e7f838489c11362fed4ecbeb8e92680a997ea', '2e14265119af1a5e62621d870f1319b5ad1ef78ecf679069413ef697e139e8c0', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '2020-02-10 13:58:57', 'user action', '2020-02-10 13:58:46', '2020-02-10 12:58:46'),
(223, 49, '5fc4e7585b7fdc06505d6a747dd15372ad9a6215', '0968173d911514cc803a699e596ed8576ef5dbf1810c04253bc7b92a8ad39839', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '2020-02-10 14:18:54', 'user action', '2020-02-10 14:18:15', '2020-02-10 12:59:19'),
(224, 2, 'c783ce428d4aaa25725b7b37ef28ae8fb7e3e096', '900383f2ac9e32c269f8722162f168be92db5da675deabd31e3bd649a624f5e3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 14:24:32', '2020-02-10 13:20:04'),
(225, 48, '87467e43fdb5ed7d4b04fbe738a914786b71e54e', '5dae9e7680b6d7d579adf716bb6ad81108696855d64dbecfea09b49d6b1921cf', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 17:12:10', '2020-02-10 14:55:14'),
(226, 2, '958d31c8304eafbfbcd4261fd3b7fff6035ca821', 'd8ff624b7998d3ef6730d067785479df20ea34eab3afc56e3a164e3efededcec', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 17:12:55', '2020-02-10 15:57:51'),
(227, 2, '2b0c8735351b1ec9aef5d19505f547aa8ec18346', '7c24f310e33ee18a60c3bbcf36b2d54c221ae8a18e3ed732360e5a37d2529e3d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-10 23:15:40', '2020-02-10 22:10:41'),
(228, 2, 'f563202d63b315782371ae437720c3b71f275944', '034e4d960d0ca27111e0eb10ec5ba386b3b423cd196b4aebb63bf0d6734d6549', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 08:32:59', '2020-02-11 05:18:55'),
(229, 48, 'dd28cae3f00a611d809586d094df2b4ab1bf7a9b', '537854b78e394280613a0aae5f5adade11ad2600d299748f201227fbd38d7a54', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 08:47:53', '2020-02-11 06:58:25'),
(230, 2, '474bce20292dcd0c46044640e2bfe98cb20d3edd', 'e612465e1f978f738fc0e9f418013b7e444d4f7cd722eddbaf81676147a03749', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 12:10:35', '2020-02-11 09:54:52'),
(231, 48, 'eb7521cb973ebcfeb9fe535b51c647338f3279a9', 'c2a772fedb416113e39940c52218a491857790b3d0b87575778fa1023cc1ce07', '77.60.176.87', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 11:20:26', '2020-02-11 10:01:16'),
(232, 48, '22d595caea2c5530869334ca07cb622fc8e583d0', '86e028f6b607aabaa6b90287a0f9443f8c77d5bc280b6f6113d52c0041af75ed', '109.36.139.208', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 12:37:02', '2020-02-11 11:30:04'),
(233, 2, 'cc403cb3a5c5a49fbf8a3cf9ee578d036d3bea2e', '0027d92c76575a63a59d9ffffedb75f308746fe9c0aef194218cf06ea4b70c08', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 13:22:00', '2020-02-11 12:20:18'),
(234, 48, '964b9d7aff4800decd837ac874352e3213380956', '59b4b2bd85f286b3c7013c9391f87ca5a316d2bf764f0bc770188d6af04b5767', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 14:23:15', '2020-02-11 13:18:14'),
(235, 2, '2fcbc199d1a7af5e9e4b0738cad3d90b311b131c', '2f75b6cb88e8953ad791666ffb69e095cca70a0893ead179423a1dfd0f972956', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 16:15:42', '2020-02-11 15:15:22'),
(236, 2, 'a51db8fcf78159e52127e7f3f8c46aab33e5ccd1', '7d3ee01f99dae283c037dfb0907ef3a6164b7883b067c7bf470f9b46b26037ba', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-11 21:32:17', '2020-02-11 18:44:52'),
(237, 48, 'fe861bcebb505355546124f6eb4f4dc3cbd3191d', '0dcf5b628f1b3245661168940602bb5a889ccd02746b8c0a6277d31cf800edd0', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 09:03:14', '2020-02-12 08:02:49'),
(238, 49, '44c2cd6f4e04dbfdbb383378e816ff96859208bb', '296e2a018996732dc4daf6cc71a46dc75346ba7027ffe09f250d724fc9dcf264', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36', '2020-02-12 11:41:42', 'user action', '2020-02-12 11:41:39', '2020-02-12 10:13:54'),
(239, 48, '75f52859f5329d9f607e9eb546538ede2085c541', '98f6ae2bd83e0ff367d200f052770c3c54033e39e9473c4f7839b28fd2e3271b', '83.160.109.39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 12:05:21', '2020-02-12 10:24:37'),
(240, 2, '759cd339e27278a9a48414a5a8ea2b0942febf9f', '6714f62b7327c98aacd9e3d47a774e86703ce47743700469cfc8056eff81dc38', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 11:35:46', '2020-02-12 10:34:31'),
(241, 48, '2bf6c7c76c10a8aef012ddbe0e8fc0e5bbdc5fae', '9b567082d85810e41800a711ba899f8a530db6d496d5a4826b129e6a936ac15c', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 14:36:37', '2020-02-12 12:37:11'),
(242, 2, '5e4334c790b9fa692c0502136d740ab8ac632ac3', 'e6b9a700339f98efb38a9ed82edc96e85921ff9e6e32076ccd8e6b55c5604604', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 13:47:11', '2020-02-12 12:43:33'),
(243, 2, 'a4b734d1275aae902b444dc55cfffb109424666e', '74283be86f1534c08552777fa1109bf644e63581253ebc0ef39e2bee86673119', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 13:58:25', '2020-02-12 12:55:14'),
(244, 2, 'b6528fff6b00f9acd2584ea4013744d66bc17fb5', 'a402bbdfdf66b5eefbe8a07e7114aead4b1c62d386dbd21ba72b8593b41e262c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 14:35:51', '2020-02-12 13:32:38'),
(245, 2, 'b140768b423a81aeaef939365a5acd9d9b948272', 'a456be0aea3276838cb3ebfd7774d4d0bc81f40663fc959094a4e951500d42da', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 15:27:21', '2020-02-12 14:24:27'),
(246, 48, '3875db9cb03d4576e6807f8c91b78d73a9677b2e', 'ce40571b92bf0ad102defb29497c10583f77f056f860e24d8fdd719ca71f32ce', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 15:27:20', '2020-02-12 14:26:35'),
(247, 2, 'c5e74b5e2304f771e565e48572feb7caeee4572c', '6ef6da5292134ba5ac1c3da89e8ab388cd4b23526386e445e99319cca1373f3f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-12 20:34:01', '2020-02-12 19:33:00'),
(248, 2, '2c51db347dcd6f4ecc9a1724515bf3c18427084c', '83ff04b4500c35a06610fdf5d9271b1a1e2614acc4219d936378a62833fd477d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 06:12:21', '2020-02-13 05:12:18'),
(249, 2, '87d095ff84bce0917a98f3cdc5bf06851334105e', 'c1a87c506cdb60a5d21a22de723d8261d23e27be9d01cf8bc48aacc11fa37298', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-13 08:12:10', 'sign', '2020-02-13 08:12:10', '2020-02-13 06:03:43'),
(250, 2, '4c19b85a427b89669f1ce5f27069ca5cf07de571', 'c72f6504230b64f0d615cf1c547780b3d861ee44ec3f8d8fa2ec7f301c9bf2ff', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 08:12:18', '2020-02-13 07:11:32'),
(251, 2, 'ff61d5c05e5746004094b3843ff39737ff7a625f', 'ebf61e55b850b2955487cb713dc0221c3e44ab9cbc2dc37fd14e6ebaf18a9dba', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-13 08:12:42', 'sign', '2020-02-13 08:12:42', '2020-02-13 07:12:42'),
(252, 2, '1b72111d73152466e49ecb77d1b7a78eb66eaa90', '4e8b328d41d9fb8b46894012d80f14f8d8a5bc2a22fa7abfd4aa8b6d91788cbb', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 08:16:01', '2020-02-13 07:12:48'),
(253, 2, '98907ee4f7e82c4205e45aeffbbb699cc35ce2d2', '9775831f2bf24c6a6997cfb676844a90b48e331e2c1775ffca69ed2dcbc43d24', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-13 08:16:49', 'sign', '2020-02-13 08:16:49', '2020-02-13 07:16:49'),
(254, 2, '58f19997f9282edaf0ef66c7fd38642806336505', 'ed5e216abbcf87d3ff5be7ab3bad35ad8cd73e29b7e58f1256b3aea60e002df7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 08:16:55', '2020-02-13 07:16:55'),
(255, 48, '26c093c8ceca24b2e95b81c9f4f7eee70a374930', '2d56aee2ed87e482519d5a1e6f26b0b666ade080a5e0e9814e78128f2f500fcc', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 12:12:09', '2020-02-13 08:49:26'),
(256, 49, 'a6a7a5fc3afe2decfce9e9858c7d5a949b061741', '61ea9cd1e8991daf31ee3df855c3ba20840d02e71dc06d79125e1734e01abe10', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36', NULL, NULL, '2020-02-13 10:38:20', '2020-02-13 09:37:25'),
(257, 2, 'c31683e0b45740a1b7a38be49b3d69afa4b2361f', '1ecf21a4ae8926cb74da1686807a8c60c8c3e5125da8d8a59ca737d26b62f35a', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 12:06:58', '2020-02-13 09:37:35'),
(258, 2, '28b4bfe81777c8837564742e7e44bfe53f5e3e7a', 'c2da18544ee10178d39260f06efa1784c3f4e9194ad61426ffd9285083aa45c3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 12:22:14', '2020-02-13 11:08:56'),
(259, 2, '9af0a7afbc363ccffcdc28f802f79a16e61a9d5c', '0182615521e4039f6c36fbadd41f220698db09a60fbda96ba00b4247d5c3de2c', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 12:33:20', '2020-02-13 11:31:26'),
(260, 2, '0ee67b4c0113cbdb7c1c2b561f6c214c2bfee25c', '068d47abf9d74f857d7b11faadfc7e844aa37473d2b7a975bf44cfde9cdbfef4', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 13:50:51', '2020-02-13 12:31:58'),
(261, 2, 'f84dbe8e68cf597ba686444140654c706f101c8b', '1e1a7bc7b4d1ba28d6f0171ba7d505d8011f69042bc1276a434df562c98010ec', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-13 14:33:29', '2020-02-13 13:33:02'),
(262, 47, '2fca177d2eee609ef3deceb9a2db5be490bc7b51', 'edf18b6cdcab91c12722adfd93e904758874cc3cd35b731fe9433b53ef17cdd0', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Safari/537.36', '2020-02-16 12:57:18', 'user action', '2020-02-16 12:57:01', '2020-02-16 11:57:01'),
(263, 48, '23470d529335a6ecb12afb95ac52f793d1213efb', '99a6a1b1c947380862434e229e66a1065f257dcab230d4bdc914111b43a982d5', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-17 10:06:37', '2020-02-17 07:51:57'),
(264, 2, '7320b36054d9fa523d904244e5feee6d1ffc7739', '0da474207b82beadaa5302a449cd0ec1d1b31c25d0aa04dee5c1de3dbf9ebb49', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-17 10:32:41', '2020-02-17 09:32:34'),
(265, 48, 'f82b0c3cf967d6b7f5a61549462438183f0f1979', '12da0b4520b9c30dc13f13e4d136471539e3ad9058d850073c1364e4983233a0', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-17 11:24:08', '2020-02-17 10:07:37'),
(266, 48, '1c6337eeb9ee432b37ee67472b809b6863314dfa', '82ced8254e3fdfc14aa360996b9252f84630d116d06ba13d540ea6b140c4fa7f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-17 14:04:19', '2020-02-17 13:01:36'),
(267, 2, '93d8a648d2b5eab9fba61c4d5594ba60d60b3ede', '58fa2b07786e4ec88d2cc3ea92335d40a589d9c6ed32e2521727d1a839b6c7a5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 07:44:22', '2020-02-18 06:42:28'),
(268, 2, '902de97026a4f5ebbd8e7b32b1e8cc305a2be4d7', '8613de3cc35ba56a81956d0bf61d4560fc7e97e7bc8713885d82b11a63f0b9c4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 07:52:50', '2020-02-18 06:52:43'),
(269, 2, '21ccd812bbaf9aeaf6573ece468d00e5598065d3', '562344e68fd7b92d5a4e90e48fdd13e709ef2ebd4af280c81db2f9aca81fc91c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-18 10:21:00', 'user action', '2020-02-18 10:20:57', '2020-02-18 07:14:54'),
(270, 48, 'da5731cdc42e83e66643b17f19024965dc25f50b', 'a058a6aa0d6bd4eedb45f78f4c72533b6913ad319b7d21ba47105bdf81ba12f0', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:22:05', '2020-02-18 08:36:26'),
(271, 2, '77ac4ac49d4db3f5062432c96a0d06a665f8e2e8', 'd4fa47bab3a465a4029bce0f55457d05110b37cf08a7e70226a7310844d5c583', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:20:13', '2020-02-18 09:21:01'),
(272, 48, 'bc36b99d7598a47625a351f5a529abf627dcbe05', '30fb1d28ce628d0786a9a50c6b9022712ce2c8930f45faf722941df66ac461a8', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:22:21', '2020-02-18 10:22:16'),
(273, 48, '9b6a4fea7b348073ac8642c333f63200279cfbab', '89a87c648fddc3997fff0d1d7f18a6aa30777ea9b796647e4e42aaef8c1482c5', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:23:02', '2020-02-18 10:22:31'),
(274, 48, 'cbd98ecff601b6b18eb2a158997c3e19a464837d', '246602f4952682379c9ecbe0ff3c6cda723810c7c3a5a4affd15f6a11eeeaffb', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:50:38', '2020-02-18 10:29:11'),
(275, 2, '203ba36d655e6d9fdeabc8de1891e96ea1ff7ba9', '9aa3463aa4e4442922549a9fcddf7aadefbd4069ad5decbd713a2cd7274104d9', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 11:36:33', '2020-02-18 10:34:31'),
(276, 48, 'be2146a1867155bf80cea957683c3d97c0981319', '2a67aa8858dc5847bc7ea34d474dfa6b7f7491aaccd7885aad54022b9f355517', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 12:12:07', '2020-02-18 10:53:59'),
(277, 2, '4cb11e6c2b5167d5a82f02ec81edaeedf5318a60', '761f6e78e8df883b6321f916c25a61d1b123d01667bf760ba8134b5dbd42d91b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 12:03:23', '2020-02-18 11:01:28'),
(278, 2, '7bea61928c7aff949dbad14e033d5a920871de0d', 'fd182cbc4f98906728a55c7f77f1aa666766c8b89c8bef067a29d2aab3885563', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 12:05:42', '2020-02-18 11:04:42'),
(279, 48, 'a4355758685b02efe7a13f42fcb614bcae20eaba', '0461b81cc4aebe3de6d71e3351af5860e0364d2b7698773f3320686c74616641', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 12:14:52', '2020-02-18 11:12:16'),
(280, 2, 'e45d2c3102a08377d720fdb2d1e85efdea57a9d6', '3fa3bf036b93cad34a81f48f17207a539a381c26497f0254e862a2b95b14f293', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 13:12:25', '2020-02-18 11:15:54'),
(281, 2, 'b90b9d713165e59bde6c345cd5b8d17b5db26a55', '2f6c96ecea553c22c0a28ef57f7417616ba1e75b34a3e97fa94678801d8fbd16', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 13:30:12', '2020-02-18 12:18:28'),
(282, 2, '52d66d3df67ff5f66a879e1c111d22e40b09ad1e', '706d87d1d00c40b568bc6db6120cdff78556074e9689e1039eb4caff8a49574f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 17:24:45', '2020-02-18 16:15:26'),
(283, 2, 'cdc41019cff70c641b641cd686f1f0f0eb65c539', '8cb5685c19dc96830b5638017ce2a2f3bc441d925ab96ca87e486a25f4fa5ff4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 18:35:39', '2020-02-18 16:51:00'),
(284, 2, 'cfddb139477c4f13e134bc0bce3863b1d892e6d3', '11644950f1ec98ace0fa0db8c55b1f7c15889318beb21bade7c9a462fa208b8e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 18:48:54', '2020-02-18 17:48:01'),
(285, 2, '468284b62960359052491a16eee8ee3ddd7353d2', 'acafcac5cb7cd182a8567bfde9d4a24e72d3482fdb4b9d7cafd7361917d5a4d1', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 18:54:27', '2020-02-18 17:52:34'),
(286, 2, '8e859455d5252f428624d74fe2d2925c103efe50', '28b475139f0408fc8c08cef369498d444cf30c278210247e6927ee52ef6f8cae', '109.37.132.53', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36', '2020-02-18 20:02:44', 'sign', '2020-02-18 20:02:44', '2020-02-18 19:02:02'),
(287, 49, 'e6e978a9569098dcb7605d91bf4580b1bbfa054b', '7ab3f0577b5b6cb3c62728d8b2211dcad5b70c2557e119bef009cd87c496941a', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36', NULL, NULL, '2020-02-18 20:20:03', '2020-02-18 19:16:36'),
(288, 49, 'bba09411351fa8bf495e6f1de2dd566c398dcffa', '5d60d6d6efecc3898db8de4b0e5c74df5ca3e881b342ec526857fabcfe3a10d5', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', '2020-02-18 20:27:48', 'user action', '2020-02-18 20:27:11', '2020-02-18 19:21:14'),
(289, 49, 'a89014872c6d2a281e643c61d869f4d7990d08e6', '80a6c36963c2eeb3b30c109b49d550c330e0673504ba15e248589155d04385a4', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', '2020-02-18 21:40:14', 'user action', '2020-02-18 21:40:11', '2020-02-18 19:27:50'),
(290, 2, '1ccbd20301099ce338209776a8620f246a7d6d66', 'f9f607627dc32eac61313fbb4b32d49f5e431be344ff89fedd4c0b5c387953fe', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 21:54:57', '2020-02-18 20:26:08'),
(291, 2, '32412737915c6fcd855159f8504233e7027834de', 'cdbb13e9a62744810bf9633e106c090c334d04815b90502012c8ff9798531e6b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 21:57:27', '2020-02-18 20:56:40'),
(292, 2, 'e22e078cdbac6be51ccc20839b7a66a2212eb653', 'f1771b13c305d6320a388006cc1729234cc1f2c67d8eb9f42ecba140e86c613e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-18 23:14:16', '2020-02-18 22:08:43'),
(293, 48, '034326452905a23300a5f8dd519e14858d0038fd', 'b97ace327da4afbd49f42f38d92e6e34f5c6c643204c11c448486f728d7caca7', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 01:22:27', '2020-02-19 00:22:19'),
(294, 48, 'a25951c53a3d01b4c4b8f000e9d243b3cead6c22', '36e0fed36a2933901ca5b5b0580ae191e55be98a0a25531c6644d5e7469c29c8', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 01:26:32', '2020-02-19 00:22:46'),
(295, 48, '863713d99a440bc7bd47b62dbd574bf7301d2f34', '4435f0e3972c9f32efb71c84d6ede00d466a9b73bdebbbac0e1165644d8964e1', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 07:47:48', '2020-02-19 06:46:37'),
(296, 2, 'af0719d4e26c7a9d66d96053a45965c83e573bef', '7f98343b3952a5a8cf0d8d4f5144d9e2eefee4c7b60d5351237645edaf48936c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 08:39:33', '2020-02-19 07:33:15'),
(297, 2, 'dd8d42d9d3137ba25c4e5e3a21dd26a9b2b6ebc9', '6d568dac331effcef8425096abe0040f53068ff79b98997354e91e64ac06adca', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 09:04:22', '2020-02-19 07:40:23'),
(298, 2, 'e651bc2c27de2ce009175c9557896f8cc8780ad7', 'ae57e127824556c0925976752f10d78ee7f74a55f7783b86cfc117163b61aefa', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 09:19:22', '2020-02-19 08:16:25'),
(299, 48, '6bf29e939abf4052aaaa588f075ff262e8cc6bf4', '942b00623a49ee33dabaac9646c57ccf8441a9a9782dac02ffe5939162959b3f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 09:24:28', '2020-02-19 08:24:15'),
(300, 48, '2832891d2cdb8382e2a065be884e474f720504c6', '082fae4d46ec4607168044baba9d4fcedb7e804d67a6719f34da576e98518b5c', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 09:49:21', '2020-02-19 08:24:44'),
(301, 2, 'e2f2382cffcc542cace56e70931b06c5a0e9aa7f', 'ff20d1aceb380786601979b03004256dd16c38180adfcc1a1174b0ff7e0242b8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 10:14:28', '2020-02-19 08:36:02'),
(302, 2, '0598a8606d52206a9d2b907e032f247fdf938f6a', 'f51ce7ae9fc7af9647284f3e157cc243a6823fc817801d360cd55f6264d9edb6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 10:17:53', '2020-02-19 09:17:43'),
(303, 2, '078a31cab6baa1b9baa9024844f42a7627d55612', '29869b01338618a6fead686f16f0f861e78bac1df792cb8c8ad02eb5172ceb14', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 11:53:45', '2020-02-19 10:40:44'),
(304, 2, 'a76f0e2423799bc328adf35f0c0c8b4d1a819752', 'a9970935b4d3bd69782e3034a21d7d4c2d687f8a3fb3bc5a9a164137e9bcc7c6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 12:03:07', '2020-02-19 11:02:50'),
(305, 2, '7eceba3ba1a55c70b5d28adb24174c35f2412d1c', '1d6581e69685061efaea86b7229655ce3109537f8980cf65337b411a1196168b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 12:13:24', '2020-02-19 11:12:57'),
(306, 48, 'ec689eabd862c0413e09e399fea0be2f46c087e8', '00fc70da5dda673a429ac6fd4993b15848e06402f0ea3787b2f5716071247730', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 14:59:36', '2020-02-19 11:17:01'),
(307, 2, 'aeac45d26987abf34358b0efbb7c4914a7ae513b', 'a8751f01ee27acd2fef6a5012ef28b1c43a09f3f2ef4850a5309d7fbaf85eab3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-19 12:21:40', 'sign', '2020-02-19 12:21:40', '2020-02-19 11:20:30'),
(308, 2, '77869acfbaa520fd2fd2f8ea2cfcf3609c5f6c7c', '6f748abb476888d55e18b0e081b73d65bf08df605d89ef212fa84f883b0fd67a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-19 12:25:54', 'sign', '2020-02-19 12:25:54', '2020-02-19 11:25:54'),
(309, 2, 'c9a5cfda823a0d8714cee0183670d45434c02fdd', 'f588cb053ca342becde473ace2ea5a1bc89559cbd2ed3fd4f90360537982e261', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-19 12:25:56', 'sign', '2020-02-19 12:25:56', '2020-02-19 11:25:56'),
(310, 2, 'bc3cc51dfd49466ef5410dd9c6e1947c106a81af', '1fe2a4c637b61b479a215117d4682b2e4253e7af3823386510389abe0b1bc818', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 13:11:35', '2020-02-19 11:26:03');
INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(311, 2, 'a88c329b407b3d3356773ac5655a4218fbcd7613', 'f9326ccaa15efb5f2a5a516cb7903629d856334df03f5fe2cd9e1ad99738c1b3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 13:47:00', '2020-02-19 12:39:45'),
(312, 49, 'cf90ab6c9010729de02888d68734f64eb33b345a', '2eb34ff6f2a75f27ab6bfdb4a5b959390c7ae59aa7d986b0f26dcc1bba159676', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', '2020-02-19 15:08:13', 'user action', '2020-02-19 14:15:52', '2020-02-19 13:09:50'),
(313, 2, '332cc0a3c0321f8d139358872c8223a5a35c8b12', 'f733cc61afb1b6690f76ea94c2073ab5fc243737fd2291acb2fdaa10542fa8e1', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 15:08:51', '2020-02-19 13:13:16'),
(314, 70, 'b0fb552ed023dccc818ea57c3d7993e9c7b90ecd', '78638e4e35af50f5eddb4ed06cd07bc3d71019132d32cb15ea4102886425efc8', '212.83.227.41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 16:47:05', '2020-02-19 14:05:06'),
(315, 2, 'c0eb440241edf8d519028090c21100572807a325', 'ea18af0ec6c2c336521f8cd41b15ba48a2e2c127756bfd611eac8ec65e2060bf', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 16:45:55', '2020-02-19 15:44:50'),
(316, 2, '189d35d3e4026929122f99ea94a6e1163180574c', '690924f58fb56add867e439decd58f77e0a914e422f0a25ba362070ec6aab6a8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 17:25:19', '2020-02-19 16:25:10'),
(317, 2, '706c0e17ac1ad2640b5611cc55667aa24c747391', 'dc0026a6207066e72da27156bc4bfe98a72552691cfdaa32c72620fd6a337b7a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 20:47:20', '2020-02-19 19:11:46'),
(318, 49, '80ebe6b901e947768e401d26867b50abcf5fe706', '0b97b328dae106738b92495c22023ee70102b759c3d5335229a80ad0d8cf4c41', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', '2020-02-19 20:55:31', 'user action', '2020-02-19 20:55:28', '2020-02-19 19:15:11'),
(319, 2, '611bb4394953606f4085fadd0e5baccf4e88a56a', '5a62eda62c84b4b13481fef0fd875fa1e6e096da6abfe75198dd211dbbad7836', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 20:56:33', '2020-02-19 19:52:26'),
(320, 2, '0847db53f704015b88c003721d645e6ec443b0a7', '350014a2acffb995055415e16717eafee76e41c759bb3bcdba37c031cef538b6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-19 21:13:15', '2020-02-19 20:04:32'),
(321, 2, 'e95d64902cf4ef7ddea26ebcaac5740ca91bb0f2', '0abad2887fd2679483a2b05d72cff0f79edced2dcf32e6057d7a1139041581e4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 07:48:03', '2020-02-20 06:47:56'),
(322, 2, '7b1c148575b047c8f8eec7252393c363a990350d', 'fdfa9fb022c2f690a5f92e9821d0453f863f1e5f094e36285a76e90067af17c9', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 10:07:10', '2020-02-20 07:24:41'),
(323, 48, '71bb49ce3bf013b9ee2e5aef8c9708d8a812eaae', '57864ee9076d0f9b71e4fb4c7aa15ca6b2e8a5ca3fd0ce3d535fed8385b54ce3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 14:19:43', '2020-02-20 08:49:09'),
(324, 2, '41c7724680e63b290154cf92d6ad863e4795c8be', 'f44d4cfb00aba76eee3593b278367671b3a2f81ef7da2c0147c58dfb8edd67fa', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 10:16:43', '2020-02-20 09:16:35'),
(325, 72, '2509debba9c45e83605be4f17e5ef36091b4b6ee', '4edce1a6f9a3499ee24d9be58e0a7e0ae417d76b11e47e3cf603ba2a46b1d38a', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-02-20 10:29:24', '2020-02-20 09:29:24'),
(326, 49, 'c896c8485ee5fde8698904784d595c943c4fba24', 'a371eedcb09af1f3f186bfbda939e5feed3ea0174bc810fd021bcbe190fdfb9d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', NULL, NULL, '2020-02-20 13:07:05', '2020-02-20 09:30:31'),
(327, 2, '2dac79f3dba3a537943116d5fcac12706db9f81b', '6371ed784f17f5456c3ddd9274f575decdc199603ba8c2df6568301c934616b3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 11:03:27', '2020-02-20 09:34:50'),
(328, 73, 'e5e186a79018200ac8a1099d45b73476bf9fd51b', '74c81bfb4b26c88ff84f8673ffa88032d5d64b876892d36e3f8d710734c75c6d', '77.163.222.97', 'Mozilla/5.0 (Linux; Android 7.1.1; SM-T550) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Safari/537.36', NULL, NULL, '2020-02-20 13:25:31', '2020-02-20 10:00:06'),
(329, 2, '04584f8774543864a14644a4f43cee7a79777657', 'b8a69a824812726f978d29e187ce474bbb80eeddb0df222bb46856634e2e5863', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 11:43:36', '2020-02-20 10:37:24'),
(330, 2, 'b072caed7ea96cb1936d711c0ec1ae745ac971bb', '51972a9de835b097c45686432ec886e4ea690165ec43c1350a2427c5f3e03fa8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:08:29', '2020-02-20 12:05:23'),
(331, 60, 'd6bb077c9382e56e1ccb756881bd06ca27ed2ea3', '40064f5832e48e505530e1e6d5a1b608aeae8782110355d35ef5cae073cd54d9', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-20 13:17:15', 'user action', '2020-02-20 13:17:12', '2020-02-20 12:08:53'),
(332, 2, 'be564125e2aaedf9d3989ef1e49929204ac32084', '452db2c708514cf2d84a2f0509d2168efad0aae424994707ec6ec56f7c5e9568', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:22:08', '2020-02-20 12:11:51'),
(333, 62, 'b0b4ed1d73ad47c900c869642b94b7811e4f378a', '15ab46a0417728c228c3637339550434ad7a4e68206b321a5e92506fb51b2f1c', '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:25:06', '2020-02-20 12:23:53'),
(334, 2, '8d39fd081a903df8f5ccf55d3e5584ca4e794f01', 'fbba6d2c13be2be6e081019868764c309c491a31eda1d6b2b8f52ef4b796bddd', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:27:46', '2020-02-20 12:24:02'),
(335, 2, '237efb8e75e4b732d14d0c7214acf673051a874f', '835a7180a44469d4bf49fd928dd82b87c682cac071d960b22ddccaece8079ed9', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:32:36', '2020-02-20 12:29:18'),
(336, 2, '453357ded317fe3655ce7c9ad594b091eaf5223a', '066118f7ffa88fc371866a6a8ebca150d8fcede983cd4d261008a399df04b99e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:58:26', '2020-02-20 12:46:48'),
(337, 70, 'd635a28bb0b87f96ef0efd351c30a215a3e60a3a', '7df7bb15a5ca7942d1f843179fc59bf7754b2f1c3db5789a53f11d4f10fe4bbc', '212.83.227.41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 13:50:20', '2020-02-20 12:49:25'),
(338, 2, 'b90c667453abce0e5036cfb9238a6b311562dd21', '56c0474a866f5b10434dea75852e77851a585914292f30976c9d72eb1584016c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 16:39:12', '2020-02-20 13:22:31'),
(339, 2, 'f655ef7d63f834820c14f6ecf4cfec314f98dc04', 'ab1561f75184617e7a9db291f70d30e5c401d65df3442c1053a2c65e30580a7d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 15:23:21', '2020-02-20 13:27:28'),
(340, 48, 'bac8682ce6cbc5f626fa12ea26384a25d7594e30', 'ff80ff7a0bc6c412ef143d4f2b42ad5ecb4a8b0c8226f831e4b060ebbd887475', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 15:05:19', '2020-02-20 14:02:38'),
(341, 76, '825bcec3aedaba1bf5e5e0fa5de3bd91d7c650f1', 'dd850dcd1820d25a1154cdf1cb5af6e71da228017b1f9bee0b7d90fb49c897ea', '83.161.132.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-02-20 16:26:55', '2020-02-20 15:25:18'),
(342, 2, '5fa60309c00f9d4e5090a70894d5035e92b5ad45', 'c4be20480529a638c3201ae6a3c3cc6461648e038ff715b57c1bee4822a64e7f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-20 17:49:18', '2020-02-20 16:34:05'),
(343, 2, 'd30adca0ecab2f8716bc5885c6d365305a22da08', '9534ffa01eedd469bb73bf1d3b2617ab75500d731525a3613f71b689acc1a2cf', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-21 12:48:38', '2020-02-21 11:43:34'),
(344, 47, 'f7c7720946b65141ab522e2c6d2bb84059a30798', '4804781511db1367f1773c309f3856e2bbaee996741be6bc284c52420b62e61f', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.117 Safari/537.36', '2020-02-21 19:21:53', 'user action', '2020-02-21 19:21:37', '2020-02-21 18:21:21'),
(345, 48, '9591e3711abb3c126065d075a9a42f1bc90a66f5', '6974e58f6b36202bb155f8482bdcf762fa3fa689d61d22e9b00495e75b39b26b', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-25 11:08:02', '2020-02-25 08:44:22'),
(346, 58, 'bab4f6e89e8c053369f7f46fe171a7f20b9d33e9', '44c4443a843568cff05609bc037db116e60baaebe0be93d1318cacbed461eaf1', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-25 12:40:16', '2020-02-25 09:56:20'),
(347, 2, 'be49cfe6074663d23f16df3b3ad0781e33f038b5', 'e8d7b41f9c3cf42eff81dbf55bd60339728e16c9bf5b63470048d035c8f2ad5c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-25 15:18:02', '2020-02-25 13:49:26'),
(348, 58, '15bea242fa19be1275f93853cd3bc4ebdf260d12', 'e23974c13433315cca306ceb902020e1845901ef1083c6bbf45bbef9517a4bfe', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-25 15:09:20', '2020-02-25 13:56:48'),
(349, 48, '17dfa0d21a450dff19b97765e797116dea4f1ac0', 'fc4ec09a65b97e126551a00be9733257cba7888fc2b9e58e34eb3378dab893a1', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-25 15:20:06', '2020-02-25 14:14:38'),
(350, 49, '603e6204f7cb4aa02664b791916d037b669268bc', 'bf6217f8d9ba0f67589fe25a44f77d96c66c5099d0339e5f1e1b970645704d0f', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-02-25 19:48:24', 'user action', '2020-02-25 19:48:22', '2020-02-25 18:05:52'),
(351, 2, '32d17c5f4fec2082fd0b5754206daec2c28cf159', '2a76791b85afdece5f96044541f147eff87d2fabd90847f3d01b8c5c1d768feb', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-26 11:32:32', '2020-02-26 08:17:16'),
(352, 2, '12e76123c1dc3eb9e14fa105d7d45195accc7bcb', '66f00a8dc806951bdc112b6005047fff0a43b24dc4474b26646607427972b1a3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-26 10:24:08', '2020-02-26 09:23:54'),
(353, 58, 'e274da356c3294f97d6a5e500c4267a70eb8bbe1', 'fb0f9bc996acbe6ca12b19cc16935e28e46cec02e6595a4ac5dfda79eeffc314', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-26 10:54:10', 'user action', '2020-02-26 10:54:05', '2020-02-26 09:35:01'),
(354, 48, '3a8cf0525911cdce981d3a73f1f3b27654ef8739', 'e130a5275315504ec71980b34492d37eca000d728e1c5c24bc4ce56c1af95979', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-26 10:47:09', '2020-02-26 09:38:27'),
(355, 2, '56b8ad895121c4f733aeb2ffa436445f1161f11b', '679f2bcf0820abe71016f3436c515900739ee11ad088b3760cf1c5458967acb3', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '2020-02-26 12:49:04', 'user action', '2020-02-26 12:49:01', '2020-02-26 11:34:01'),
(356, 2, '92927145bd71b2bea2ec0baf5bfd999ea7d61eba', '8e98d17ae37d95b37dab7a60ca419860f91bc6ecd024a3c06c66483545151dd2', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-26 13:04:51', '2020-02-26 11:49:06'),
(357, 2, '737a6c17228e4d352d4b34d3bcab861b02490c90', '86574251cd33c720e0f6ab873b6aa1c5fc1143176a097e3dde938ed1556c96dc', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-26 20:01:49', '2020-02-26 19:01:43'),
(358, 48, '5342b3531b056596121f47b72f8978edabfb3db9', '37e17396664e687e4c767bc42d15dc17df5fccfa5b137a123aabef67be7692cf', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 12:44:41', '2020-02-27 08:54:13'),
(359, 49, '6acf38c0d44ec46b2c0d3b3f010b53be476fff6c', '8b43bbed29ca0c2b2baf5249c6f133cd939c219bbd9584b35401110203537047', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-02-27 10:47:27', 'user action', '2020-02-27 10:47:24', '2020-02-27 09:37:02'),
(360, 2, '4db133b220abd1a2bb093f09dad15345e4a36b54', '47b5814b5ed3d8d59cebcd114caa13f458027544773acd1d6c97e7e7aae99e1c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 10:47:47', '2020-02-27 09:46:37'),
(361, 49, '5878eb41074a525e5c29abe86fe3e9c27914d6a2', '851b2d0f04dabb43d84e2cece25bf74eb6f9a3f0a53a36cb8d427282f71d315e', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 12:43:58', '2020-02-27 09:47:35'),
(362, 2, 'cedd67c8821b22a559f6ac3968a3f20a0ca2d891', 'bf71a868b74cf02abf33adbf8f59e8c91cf5ddd1599bde9f02c2e924758be81e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 12:03:12', '2020-02-27 09:48:34'),
(363, 58, '2c73962759b00164691d577c41e53d8f7d214f39', '9b6a620d305e1eba67e92bbec87adf1f0a9e3374b9c373463ed79196a399ef39', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-02-27 13:48:35', 'user action', '2020-02-27 13:48:23', '2020-02-27 10:50:32'),
(364, 2, 'e4b051c1709f9058384eda4a0c50e9faebc32f78', '548dc0a0407c45434297c42b959daa8fae788dabb375359b90fd6eff9229e76a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 12:34:57', '2020-02-27 11:32:42'),
(365, 2, '8dc30bf4dd1dfcdaad3c956aa173346cc679e108', 'e8fad8dc588bc36eabb5f61a6edc83db092d41a6ee5f432870405d4e0b871708', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 13:23:37', '2020-02-27 11:35:09'),
(366, 2, '27a44cb1ab3418b972e4f544d2898a99cee0cbbd', '85a8b73847fbefa417c7a82af175c9856241c72f54a13f19a4f78eae5f8c3439', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 16:21:20', '2020-02-27 13:17:30'),
(367, 2, '7362b1cb8fb7f04f7b5a4f51707633fdc2703d79', '68f62a7094ae66a65e854c0a914cb4fbffaa3da686b557c1695691b91aabf223', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-27 15:05:27', '2020-02-27 14:05:04'),
(368, 2, '1f67d42250317b871f991f461f94894e4c8b3a46', '56aec0ac8addca716d5a47513fed805b1836209134af08f9baf033ee7dbb6ef5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', NULL, NULL, '2020-02-27 16:01:15', '2020-02-27 14:59:16'),
(369, 2, 'a8d00e808d658ec80888d143507dbb2ceaf273ed', 'abbbc3b0c79f7ca426d4d92dc3f8db09fe38bb299ea18688ff0ffc53f3a5aed7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-02-28 12:14:43', '2020-02-28 11:07:29'),
(370, 47, '0d7195e7e3614d7e77cc10f2de12e5f5a9b1129e', '26d1496ce7c2659ee3295914ad03f85ad1522799f9ee3f4beb53876116936ea7', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.119 Safari/537.36', '2020-02-29 08:44:34', 'user action', '2020-02-29 08:44:13', '2020-02-29 07:44:02'),
(371, 2, '92e4df8d2d2b07ceee813f755aeee2840db8180e', '2a75564dc20fd42b95f17267940e843f76c22fbc1c0095d20c1869523e7fba7c', '82.74.254.28', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.119 Mobile Safari/537.36', NULL, NULL, '2020-03-01 11:20:03', '2020-03-01 10:19:56'),
(372, 2, 'fad1940c988e5303091926d0c9aa9d1a37ad1f26', '8dd05eeefdae75d4e1dc47299be83b9a4f64a66d13b805aff0e4222a9275d571', '82.74.254.28', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.119 Mobile Safari/537.36', NULL, NULL, '2020-03-01 11:35:02', '2020-03-01 10:34:58'),
(373, 48, 'd478dc83eca363336121a29b3717b9be943e12b6', '94fe1ae55e6775480b154be3400a36560105988c25bd9d072a52b769931428ea', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-02 09:08:17', '2020-03-02 08:07:17'),
(374, 2, '2c71a4373fc2e4c47f7294fb976b65afa89ce9cb', '9e5b7b187cbea56838266d7978acb516e89e5c8f393282bc46c353c835d4c15b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-02 16:15:33', '2020-03-02 14:41:06'),
(375, 48, 'd8cf219a430db606b96e54e2bb0b1b117e72a18f', '19789b8d57b8dafc9313dcf1404a7c5b2e112061cc90a852e13dcd65e058b238', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-03 09:51:51', '2020-03-03 08:27:20'),
(376, 2, 'd122013ee6c6db3016aa68897039777ad166927a', '6fa3b26aa99dbedfac07f7d192d0295011266944a93c8d99458ca290ed23464c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-03 09:52:27', '2020-03-03 08:34:30'),
(377, 48, '9201d494b6f978ad1ff6ee7828116b1e56fc71c2', 'ad9ca0ffd9bcd573c8d3cd0e5350c8bff56768cc3434face8556379308b278b3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-03 09:56:07', '2020-03-03 08:56:07'),
(378, 49, '7cb746893c0126d4242f61780274894b053b20a0', 'e7bf8a52118a010f92c4b94a9d989b677d48d289497bd69688de3bfda7bb3871', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-03 13:18:23', 'user action', '2020-03-03 13:18:11', '2020-03-03 11:21:56'),
(379, 48, '856d48a74c1533b89be2163d1d05981f96ac3f3b', '226a807e9a724835b6941d84fee9231e8e80c37a7f5f716c0ed605a3daea3567', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-03 12:35:32', '2020-03-03 11:22:59'),
(380, 2, '6b79ef0ca10a7dae37359e45dcbfac3d106813ef', '428c5437a819f744e00671ee5c51d457eb4551d23c9938455ab2a58b12e6ff71', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-03 12:24:29', '2020-03-03 11:24:15'),
(381, 58, '0fd90f30af99890376743b8513b47af425d5e442', 'd21166ce2e43cf14daeb5adb1d03ea1784a5902d11221dfbd23702a5ffa427d8', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 09:47:32', 'user action', '2020-03-04 09:47:23', '2020-03-04 08:16:09'),
(382, 48, '3943d4296792fea1cb94b6c0500cf1a8ccf3facc', 'f80863faa6d02f9b309efd7d5531bbac5524405ce8524ec3906c9577ac1e9f5c', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:03:41', '2020-03-04 08:45:10'),
(383, 58, '7a72da0db36bfb7609c318d5f003d2a2ce445cc1', 'fe461b8a4c479be248acaf34adb98a431398718315787a93d30deca2150dd7e1', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 10:53:22', 'user action', '2020-03-04 10:49:11', '2020-03-04 09:08:06'),
(384, 2, '1ded1a7cba797ead64a46ef762f47bbb88112fff', '7f68cb236974e5b638f1d37c416e05c4e1f5320bd8e814d1dc15783a1fcb7b5f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 10:59:10', '2020-03-04 09:58:44'),
(385, 49, '14ea224619b3d7dfcaed55c19bc5bde02cdec45a', 'fee196dab14e67983a10be8b09fc0c3ce0eb770ed5d6311f1984c0d8f671a2ed', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 12:17:45', 'user action', '2020-03-04 12:17:40', '2020-03-04 10:07:23'),
(386, 2, '6539710f5b13005d2168de239fcc87a43a3e68cf', '34b4e35f2d4284b59d5deda3a8b90e51ff01609a1f5993af73cab501c1231fa4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:03:32', '2020-03-04 11:03:29'),
(387, 48, '33b3b30b4e362350cc639a4d2866ea35cdb9cedb', '59ea7704611cb989b1bbb0d2bf8d08f48e57486622b66539da61aff6ea156cb0', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:04:18', '2020-03-04 11:03:53'),
(388, 2, '6597e3c15edb53142014b70e7f9c4878d3c11164', 'c383f6f1265c1cd4dd872a64f4f0be42d5663e8d8180a3e50c196f99bf7fb579', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:17:22', '2020-03-04 11:17:08'),
(389, 2, '53d742ca0a34008eb6b76f449c936ee89b31e5c0', '86860f110eccf4b57b7840a0fec2b9b3ae2b1c40db2f9d034ab09b534595443b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:36:07', '2020-03-04 11:17:41'),
(390, 49, 'fd0882b431f3578127dfa64b68b58f3a2f6d119e', '1514f7dd45c26ce8d5dbe85f59adeb5747f2a496b84e96a5a81ee3c567ed538d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 14:14:12', '2020-03-04 11:17:47'),
(391, 2, 'f84b906288088a33a9778e1d2717f8a993421db8', 'fbfd6d782a048469c4f302bed1e0e1e214823a9122de54584405addeda51fe3c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 12:49:57', '2020-03-04 11:46:03'),
(392, 2, 'fb0abc8a702448dbd08d10078dfd0bc238428f4c', 'bd542397d53ba70fd957ab8eb81e296427cd7e3ebfdc44d35c4976888ecf0954', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 16:19:59', 'usermanagement', '2020-03-04 16:19:59', '2020-03-04 11:50:19'),
(393, 2, '43c509611aec0390b6d5af7cb2be692737b21f89', '9310853d14b75953414d3595188834cd412660c140ff03754d15ac2f233ba1eb', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 14:13:41', '2020-03-04 12:39:46'),
(394, 49, '886595f6defbd1928f70b57f1bcfe617edb222b9', '5df4194b36703fe3242f4a19aabc640fbd9fb30cb6ed5f3875d27b628be3c6a0', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 14:34:42', 'user action', '2020-03-04 14:34:29', '2020-03-04 13:31:52'),
(395, 49, 'df31aa5c5d92137e54208a1f270359356ba655b4', '92001873726a47304768210157430f0e2f505509f0cbf4660e8e36e1ced73c56', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 14:47:33', '2020-03-04 13:46:58'),
(396, 2, 'd32786bd3e0ee8003aa29c23eccf554a563500c3', 'f2a7afa9e0b62292b11585b89397e0073b4cc689631db5d471a1eeb8c0fe43a7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-04 17:23:49', 'usermanagement', '2020-03-04 17:23:49', '2020-03-04 16:22:54'),
(397, 2, '5721e964b9572889c7c3c57d7fcf6be3aa269a59', 'e10d3f871bc2b8a0a8e5aa8c489a211c310b90add28e3cb799ccf1de623d5a52', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 17:47:31', '2020-03-04 16:24:03'),
(398, 82, '194d406ac54e7fba1ec1c1c75ec67f58f1caf065', 'cc0b9bdd2cc0694b052ddfdfc5208e2795bf754ac1e23063a82fb519afe938ac', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-03-04 17:51:08', '2020-03-04 16:39:37'),
(399, 82, '8bec445a29495ed1b7368e5937bd4421ef72f73c', 'f7bf9e946ff30cf88b9942a9ae56879a8afc8af791127f66af673d7f02121919', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-03-04 18:01:04', '2020-03-04 16:52:05'),
(400, 81, '607da088ccda66c7b25841963995683bfa57a0d8', 'afa2687883b710e4cdd75ab12f0bfd0cc33b68840ec964599421e2636d82494e', '62.194.115.222', 'Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G920F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-04 18:25:48', '2020-03-04 17:24:55'),
(401, 81, '76ae154aabf0c495b2cf1e40f79093492287bff3', '4b7bb0a9976c2e2745016074c2f1e46df9989d4da2561deb3044d57d48b6c1ec', '62.194.115.222', 'Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G920F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-04 18:26:31', '2020-03-04 17:26:31'),
(402, 81, 'c2393082f6851506baddb283040274c7fe1fa8cd', 'f0eda7f42ee3366b2afacec7b9e0b081e314a4f29040a767351f0d3696b08f8e', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-04 18:38:31', '2020-03-04 17:38:31'),
(403, 72, '4c335b18858d946c4cc656c0be43b05cb78a2d88', 'e2b8a66672946477a46b57828c0c32b04111d940ebda27e8167d85932d99c289', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-05 10:33:07', '2020-03-05 08:27:29'),
(404, 48, 'bbdd04e2b225e6d6e7003728617949993802947b', 'ad020a0c6d40e1d54a49bf54b4d98b8f87d7b7763fc9bc2094cd94168d5b8401', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-05 12:36:21', '2020-03-05 08:35:15'),
(405, 78, '8a8b35962b049ac23ca7270ecda66eeeaa1a9110', '4aca018408f6ec59499bea5bd5b5234a16bfd08bb0db878e261fe67a10ca7d5a', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-03-05 10:38:15', '2020-03-05 09:38:15'),
(406, 78, '8f6bedf96cf6dbfc6d508befa0f14e0f2d22f36a', '2adb5a4959cbb9f53ffb82a7dc1c58fccc9a8bfdbcac5bbf2d361c2f02ca3c12', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-03-05 10:39:07', '2020-03-05 09:39:07'),
(407, 78, 'fe2548f59dc4b6770f94855514fe573ebbcad006', '6600b2c97cea1211efaa350b4d521ddd171497741b4d1426a8e7c77f84dfb1d3', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-03-05 10:39:42', '2020-03-05 09:39:42'),
(408, 82, 'af413dcd406f4344698e22d8e2fd0fbfd8eb878f', 'ca0acb233906782416dda6859233128167f022b1020a9f32e705ad0ce385d1f4', '143.179.29.157', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.119 Mobile Safari/537.36', NULL, NULL, '2020-03-05 10:40:20', '2020-03-05 09:40:04'),
(409, 78, '5603d377cf514300debfb6f82ca918335cb2badf', '676357ebfc3207f7f9dd16f5c5458b55202fc16d490c040593ca6306517d4ecf', '89.204.130.25', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.2 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-03-05 10:42:34', '2020-03-05 09:42:34'),
(410, 2, '5a610f8bd68d2155f9217b065cb0d3470ce21d60', '6ef114e56d802a921067c2681c9063037e2d0ddf39cdbe6dd7c8c99a830f7d7b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-05 12:36:28', '2020-03-05 11:36:26'),
(411, 58, '2c240af60f5baccff71bce0f8828af2a592afda5', '745530488e4870a4da4a537d4e8d2e88d093e1707acc99c675c974469cde1036', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-05 13:40:06', '2020-03-05 12:40:06'),
(412, 58, 'e7653be1a5b09a8231da61da0eb9077be6e0a9c0', '5b6135ef746a5ad987a740af29fbb918b6b5f1508ad66b73d1e10afc602cc46e', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-05 13:46:04', '2020-03-05 12:41:04'),
(413, 2, '606d3842cf03c5786347ea84fa56368c9d04e2ec', 'e766dfa6bcbe1d6b056d384579b903d958d0dd862bb80bf6379c56a376359fb4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', NULL, NULL, '2020-03-05 14:46:29', '2020-03-05 13:05:12'),
(414, 48, 'be70f9bdc66a256d8a2a0e1b519738134e8ddb76', '90c853853a2d36585c360b49003deb5f193d3a87c552dbfb0f5e16587b434eeb', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-05 15:05:13', '2020-03-05 14:02:50'),
(415, 2, 'cc9583e52310d730e35c8ff8f9df7178aca6adec', '7324f424da52e16decf27beeb7e12c52ab046b64a32d7400f5af077d0c667d7e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-05 16:03:23', 'usermanagement', '2020-03-05 16:03:23', '2020-03-05 14:04:35'),
(416, 78, 'a6500660c4b6d1b46df52fd9d4186bf5d7404379', 'feca8cec360ad3eb5fcc66e1b0ed135982961c00e6afc9716deb9583a6a92856', '80.113.211.214', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-05 15:37:05', '2020-03-05 14:24:23'),
(417, 78, '9e4eb70106d3f8dc32806557fb67de196a5e29f8', '37912964f2fb542369b0f258ac68c146aaf9d54597932917399a7d6c324552c8', '80.113.211.214', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-05 15:44:16', '2020-03-05 14:41:17'),
(418, 48, '8ceb6b7f4757cfe0decc02401352fea422f00657', '01bb1eb9059b31517f3cf984ee9f805be620e6d1aa5f38526f1527173c2d337c', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-05 15:50:26', '2020-03-05 14:47:06'),
(419, 58, '677e3fa045be2a16c173ce7d603edbdfe57f1ac2', '7177914e644684657991a47986d040903f7463dbe6249102682d766273ed3cce', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '2020-03-05 19:09:06', 'user action', '2020-03-05 19:07:40', '2020-03-05 18:05:35'),
(420, 82, 'fb7592a9d99d669c79fe5660f6be3e6e8d311a86', '6d98443ff1da131f438fe40f29591dbdfbfdabaa36f6296bbe81ff6bce81a95f', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-03-05 21:23:39', '2020-03-05 20:23:33'),
(421, 81, '2a3ad5eb3a7f19573a607f59fd1bfe7bcb4749ac', 'd5745e259491c1ebc858644e0801a7dc6a61b9f527aaaa0236e37e3bf236ebc7', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 05:56:01', '2020-03-06 04:55:52'),
(422, 81, 'c1893d43dccb2eb561199fdc63ced7d44b588b3b', 'ae4b540c43e55ff1174491d89ef02de1b2a55f15d5522fa09a1c47d2f1e77103', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 06:00:16', '2020-03-06 04:56:45'),
(423, 2, '9b3abd1b409768a282f00a408b7a3f77f5224a66', 'ed0122b378036387e0d534087260c5ef5fa4e6013b0c346421a1d8badd970ae5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 09:11:48', '2020-03-06 08:06:47'),
(424, 2, 'd8f2a2876773a69388e4fa8135a0e036a82b278d', 'b7c4d25d44511d9e82d1ee2dcebed9fbd37d8ea49964a04f54e64630f186fe9e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 10:18:42', '2020-03-06 08:19:41'),
(425, 48, '6300dfd2d63db705e8778c9e98079787f4a0aab9', '6af9902149b8104986d019dc5190ccb246e7d8b03b3dd470e289836a0d0f4aa3', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 10:21:58', '2020-03-06 08:44:43'),
(426, 2, 'b5744715c303c3d0cc5f79bcc4505ce76a21c2d7', '8869edc996652cec4b8f892aac7405605c322e5dd8471d3d24a1ef0b7e6e840b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 10:31:51', '2020-03-06 09:31:15'),
(427, 48, '77304683c058aae8428e317b67751993148ab085', 'a1eb67b3bb55649d6303f47655f1355526928dc8e6f0e5423f94242d8f5cb0cc', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 11:08:15', '2020-03-06 10:07:38'),
(428, 2, '3d8af3600ec6165d0d4d1ef43d75563bb8075c38', '22902e82580cf8ef00c3b0fddbb7a95fb54b1f9bcbd080fd663da4aa02f3649f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-06 11:38:51', '2020-03-06 10:36:10'),
(429, 47, 'f02c346469365366ce5401aa5e31dd2e2f31b8d2', 'dce45f166d69be623613fc913b4a293c625a24d508f9721b521890a18c83a2d5', '213.127.58.114', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.119 Safari/537.36', '2020-03-07 08:41:56', 'user action', '2020-03-07 08:41:44', '2020-03-07 07:41:26'),
(430, 81, 'e5e0fc378c7063705239c73a5ca9a9a30c72b003', '52906726908abe3702f0925d16b8c24bfda05cebe5a997b4d64de2f6adfd5c83', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-08 11:00:08', '2020-03-08 09:52:57'),
(431, 78, 'da5c482f829ea6f12bcdd01b5342235476b27f37', '5d02aa50ed065656a078be10de0baf4f5de1a9ec4f06227edca7ac4b7a4b05ce', '77.11.25.143', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', '2020-03-09 08:39:32', 'usermanagement', '2020-03-09 08:39:32', '2020-03-09 07:38:27'),
(432, 2, 'ac8a0067d98f2346e308dad720917aa8c06e5f19', 'c7a33e545c09226759e8165946950401f225de9a5dbdb7b3c9a86b95d51e03ca', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 10:17:08', '2020-03-09 09:17:04'),
(433, 58, 'a5e9ebe65d5fad762a5c128d50bc2e3fe412cc2a', 'aa9c51fa1897651f6a7d43af159dd861cb59cea7ad4f90b2489ad9c582e77887', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 13:30:52', '2020-03-09 10:52:13'),
(434, 2, 'c3723b58133ec6947705b8a95b73b59d5a9f69fa', '10a1d6f92d57d09913026c8277c1bad0d378c40c7d316f5409c85769c0a0d958', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 14:41:29', '2020-03-09 11:23:16'),
(435, 48, '6825c9e226c90308ca9f73ce60b4e1f6111263ce', 'd0cddbc6af5ed65fb5ee8eaf5b089f67041c9e8b1660c3b0cf8c95b44f3fe550', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 14:59:18', '2020-03-09 11:38:21'),
(436, 58, '996fed07f21c6ef1530a5b79ada65b08fe217fd8', 'ba5430645ccd535c9af1137833d7a28299c6eb54ffb0786d29dbf1ca638a6e6d', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 13:35:33', '2020-03-09 12:32:05'),
(437, 49, '44871132f4b38a337f31d907107c0a4a7184b200', '220b252e2e3a74a7bae1721fc07a2ff98e94b8e1e3d531820839643747dc090c', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-09 14:53:39', '2020-03-09 12:50:07'),
(438, 81, '29c3ed28bb15449fbeb77484fd28ceae8120ed2b', '954375bdc69097098e4b47fba711700913d38e50aba873ff61e51dcc24afeef8', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko', NULL, NULL, '2020-03-09 14:40:31', '2020-03-09 13:40:31'),
(439, 48, '00f19204d00251601c7d3d71aa4891ef1403a284', '23210fb2d3a5481211602ebd30a31b298910912fe0477ef106a6925ebff37c6f', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 13:35:19', '2020-03-10 08:40:20'),
(440, 2, 'c5552a83ecf1f3896082f3fa075c650eae187e43', 'fb87fddb4812c1a140c34ce3b71d56198bb742863b5e832c53b8502acb9b7d19', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 10:01:43', '2020-03-10 09:01:39'),
(441, 2, '1020757361d7a2f16dc896765748bbe139972dbd', '138598a03dfc24b11a2e52f1d77ceda6ef68267401489f9677c0534f7123bcaa', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 10:07:11', '2020-03-10 09:07:10'),
(442, 58, 'e57b481bc685f66f14e0464481a754986bcde87b', '5d54ca189ed84cff201893887f49dd17d7b9bc2a70c117792b406e448d2b8219', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 13:26:42', '2020-03-10 09:58:41'),
(443, 49, '770b998dea5bc7546cd6ee5abc4293700bf5b2ee', '173a5f9770d0d4d1a8fd6a1325cdff836008c5312b84803d6c29554f626bb37d', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 11:28:23', '2020-03-10 10:18:26'),
(444, 2, 'ea559b3cc27cb09c9e9a50790f8b60c149ed9cc5', 'b01c05ccdde881eb5c7d84cbc024175e7398eb634dcd7b225ec65b08e06aa6a7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 11:39:12', '2020-03-10 10:20:52'),
(445, 49, 'e6e265f3e66e45eb708443d0f94fb64c9968137e', '1de8bc25033b1867f875c5f7ce2c30154da265cfc8fbad2b9a6fbf5d29233308', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-10 14:44:35', '2020-03-10 10:38:24'),
(446, 2, '9962bd28ecb4dbb61affd17d809a4ee2e2593465', 'f5c04f95c263943df7fc37739a8e420daf9b750aafa4a9e3c1bd81ace6ddbbc1', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 08:46:22', '2020-03-11 07:35:23'),
(447, 2, 'a4fbb6ed9cf547be1327a55d801272fa30e43b2f', '856a67c0b04c76a76dc96f6a9e2bd63917236b15d28084ed980328b75e237487', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 10:58:01', '2020-03-11 09:48:08'),
(448, 72, '15920af027e8de545eda73e389998b62f67844ff', 'd9c1718e21d5871380207bb9eecfdb124268290741846f878cb060aaf733d4b0', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-11 12:58:09', '2020-03-11 11:07:35'),
(449, 2, '4bcfbe1ddaade968e140b086f48c36fb5a09419f', 'f9fa9e47c26a37e2411b19185af4950014ee82df681e9214e4cb3dae8d3acbee', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 13:04:01', '2020-03-11 11:59:55'),
(450, 2, '6f6a5734c149129a052a04a37ba3b801a25283a3', '0a603dfa94b77954eb94a676126b5ada1091f780c3e138d24180829d49142cf2', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 14:06:52', '2020-03-11 12:12:12'),
(451, 81, '4b91eb47387895afd7707166e2900996dae79561', 'eb5985432ee3cb17fec28451057fa344dd1ea633c2e50b25d9ebd476ada530ac', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 13:52:44', '2020-03-11 12:51:45'),
(452, 58, '348892dffdfd1e0bd5a48819f1c11cec862ae842', '49a314042299163f322fdb6733d983e58878db87a55f413c69e7189172af21bb', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-11 15:31:49', 'user action', '2020-03-11 15:27:15', '2020-03-11 14:26:55'),
(453, 2, 'fb8ffdd96e17418c7b1b7e3d5228487775ca00ed', '73251f477a52361900c35291219a0d40904bf2efb175dafeb32bca85ad022520', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-11 15:31:12', '2020-03-11 14:30:47'),
(454, 77, 'f39434e27cbcfa103a6d9481d6cd11588be08d47', 'ccd2d3cab3bc84988f9eb7f46496ae94ad8172013014f0bc97cc19148a1878e7', '89.15.238.241', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-11 16:03:11', '2020-03-11 15:03:11'),
(455, 77, 'a25be2cbb3c0b1cabb37831ce368e97e19e502f7', '85cdfd28e452ac47a58b192626ce097f59157239702eedb34b5da6acdfe0c39b', '89.15.238.241', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-11 16:03:37', '2020-03-11 15:03:37'),
(456, 77, '903b93e041e2ff3afd6ab09d42fa7decd29fb81d', 'b979b2690e777da59ae0a57083be520419d10f023b0143bf6c3bf830ee6a9a0b', '89.15.238.241', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-11 16:05:30', '2020-03-11 15:05:30'),
(457, 72, '78bd4d449f7533fe2391c3d7226c5a0373a13c56', '52cec4498f04721e2632f38cd784286d107ebd062bf9d022e89aa19ad51d62c2', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-12 09:29:34', '2020-03-12 08:29:24'),
(458, 48, '608772be0d6dfab7fef494b87219063bd1075f52', 'f445a5d8dab5472e99e0dc6e8491614945d96784f23421acdf08993a5860c717', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-12 09:51:37', '2020-03-12 08:49:13'),
(459, 72, '9fa7d5c34a013d4a856ace36bac0dd7f0a6c5593', '5f83b668e00becd6e31fc44584fced1d1e7b50457b7a2f6bfb46f2562bb2ed94', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-12 09:51:55', '2020-03-12 08:51:07'),
(460, 72, '5700b8402f84cc7e9c46fefb5cacfb979d8d06f0', '3239b1ac4fbc25c26372a1262fb26455164ce933507f139fb9d27ff47431e799', '213.125.113.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362', NULL, NULL, '2020-03-12 10:48:10', '2020-03-12 09:04:46'),
(461, 2, '8c262e556b201b08840081795115de4cf6b43b53', '80caf1973dee63b2b364c5e452d3dbd40d432f94b0283ebe8adad63bc4272d93', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-12 13:13:50', '2020-03-12 10:58:13'),
(462, 49, '9c58f3042c05b93d8ddb18353e0ee65140fa09fc', '8acb31132ed935b1e83e10f3cbb03bfa934d85ec1aa7f2648c629454156554d9', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-12 14:26:27', 'user action', '2020-03-12 14:25:44', '2020-03-12 11:18:13'),
(463, 2, '07171d143f399afb473bf8b95c0fe7fc9594fc7a', 'b9d41f46997d843a43c9974c271c2474c5f264f8d9ff5df7c2b035cdc131bd7b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-12 15:37:16', '2020-03-12 14:34:46'),
(464, 58, 'c534a8142c5596a00f66f39a852585d8faa8f26c', '82f438ef8fe9408b7167ecede89573465ed5f0f3bc4ce6239aacb4077fc332d7', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-12 16:51:33', '2020-03-12 15:20:16'),
(465, 82, '0ee51bbba685bbfd06948454842170cf58cf7326', '3f5e263be5dde18c5256639b7ca197118f2b4bcbf0711dbb65d368572f2a88c1', '86.83.206.22', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36', NULL, NULL, '2020-03-12 17:26:00', '2020-03-12 16:23:27');
INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(466, 82, 'f6bebec0ea1d6b399b0222e5dea91b73645f2699', 'fcfb8a7198ce58be6461f02b264ff40278a9a238d10d5d8cec1ff695133a3ab8', '86.83.206.22', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36', NULL, NULL, '2020-03-12 17:28:58', '2020-03-12 16:26:11'),
(467, 48, '4775f65bb06d3a4cc36e60f18f39342fd27895fe', '5e70f23a25c9b8d7ac7e16c14e9ca6f5e05b4572961ba664420692a1496dfe37', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-13 08:22:50', '2020-03-13 07:22:50'),
(468, 2, '0f7b6579a72fd65ccf057210a5d3c108c78d9202', '139d5ca90adc4fc00ee684505a327936f8be39cef06a7f6b1481a7824116e877', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-13 09:41:28', '2020-03-13 08:41:26'),
(469, 2, '2bd81b345c7e6347da70d8781b604816d9545731', '50070c9e0c83cebc7b13596347f74b8c435bf589e65db94ea683a353cfc2624f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-13 09:56:22', '2020-03-13 08:45:26'),
(470, 2, 'cf10ee626e59b0bfff435dc8c040408a3d07fa0f', 'f1fb0055a495dc08450f49e4545344f30c69e4338d1281ff9e79d806cf0ffbe5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-13 10:32:24', '2020-03-13 09:27:10'),
(471, 47, '1acf818ddd75b44cf9b3f7668e05a2f4aed8221f', '3b2f2307357d7afe8743e5336b22b27ab952a2d1a63230b817e35ea5ae364c8d', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-14 15:14:57', 'user action', '2020-03-14 15:14:46', '2020-03-14 14:14:30'),
(472, 48, '2f26e9251890a28536e6fd396f301af78ee8ae55', '2d60fbdb3dcbbdbca56eda88a9cec10ec07c990f349fa9f0ba714cbef28d36bb', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 07:26:50', '2020-03-16 06:26:31'),
(473, 2, '768bf7f395a71f6cc9db9890170f0a8bb1cc3039', '159df4e11318c6238e90bcb4bc3ef6d075b657f369ad37e59a69d26fc7fb6099', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 08:33:21', '2020-03-16 07:31:43'),
(474, 58, '6c1efcf2c4915ca003d2ed65880cefa97a621773', '7ccb5bcf10a297f04168ab1b31813995d25a56cf86fefe51236f0d72ee4b004f', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 10:33:14', '2020-03-16 09:32:30'),
(475, 58, '1156da667a690d8fff934a30775114e35ebffd0e', '417fe38743d314848d187c6048fb1545cb3652d50ccea37e167293d3499e1789', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 10:33:42', '2020-03-16 09:33:27'),
(476, 58, 'e70afc99fb6e2b0842afe4e3958fba0e13c2cac8', '53ad69a401c0f89847671c51f038f60ebd067fefdbdf31bc32b6e7ee90477152', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 11:52:53', '2020-03-16 09:33:49'),
(477, 58, 'ef94bf6c7507d0abd7b18df2956516fdcfa2e360', '41d8d9d5a2d38b8a773d42388fedf1d719a6ad5668390b83937f2f484ce82fa8', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-16 12:10:28', 'user action', '2020-03-16 12:10:19', '2020-03-16 11:10:04'),
(478, 2, 'fa079fba8e5e298d97180522c3abbdf9d7b6bb0a', '0f2574da9a859048272fd96be82e84279fbab2db58025dacb852c4273e5cca78', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 12:58:54', '2020-03-16 11:57:04'),
(479, 58, 'b8a4ee95cadd7c48d35dcd1464232de94ea42608', '26cc9f900b3566a7555c18032ffed0f345be357ff22facf2d067745c7dadceb5', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-16 13:09:29', 'user action', '2020-03-16 13:01:31', '2020-03-16 12:00:46'),
(480, 58, '8f9cf39fcc5409c0ea5f84994ef88e5c3425447f', '11689dbfaddc6bec02ad7681d12f61047cde010dc831f97e41e3ae6333dd81bd', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 16:43:19', '2020-03-16 15:24:24'),
(481, 49, '9cce58696977566e6ef59f1a739f8aa5748b3da6', '4c9d81176e4c2524e13a0cd8a10bc311adcc562e7454260dd0355b8e8c0dc3e5', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-16 21:09:50', '2020-03-16 20:09:43'),
(482, 58, '8c51045154f85d41e2a7ad69caccf507f037edfb', '88896060ea8dc4601edf6f233b81ee0d03a1b01247b63d4344e45c48a16286e9', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-17 10:26:59', 'user action', '2020-03-17 10:26:56', '2020-03-17 08:25:48'),
(483, 48, 'e968a14e792a903a739eef61a73e502c100e910c', '50be951f3b43a1307460716742e9cf9453752463747d198a42f392d3fa2a3b21', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 09:57:35', '2020-03-17 08:36:17'),
(484, 58, '7cf05cc319073192b38b320e60f10df20940ffa3', '0fe1d9d66fe70892413e4bf9fbbff061e9cdf8f041bd8f326fc85e526ed10041', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 11:09:50', '2020-03-17 09:27:01'),
(485, 58, '3c2148a7f59bdbf4b3ef8f2415f9a4e28d7d6e1b', 'c5b873db1c4c0439923c06e4bb79d9b7b47bbc402240a53af20c81d93ef52935', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-17 10:30:01', 'user action', '2020-03-17 10:27:14', '2020-03-17 09:27:06'),
(486, 48, '41416dfda6689a5ed2e9faec34df5a70e6c35f5b', '2c880a8926b9f86a678540055cf8b6435a25597af7b731aece5698253c401c2d', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 11:11:19', '2020-03-17 09:46:02'),
(487, 48, '120415686fde039afc86b6632272471113e4756e', 'a66a8257b32ed9dba92a2a3c385a16e14a15fc10b4360404fecabfb4f5387efc', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 13:19:34', '2020-03-17 12:07:22'),
(488, 2, '5355b7cb3cd5a5f9a115bee7b7e13e76a058fce0', 'a1c5a9ba484f4a7e72d4889b23eea9a01e9335a9448d128953b55aa862fe0d39', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 16:17:46', '2020-03-17 13:39:07'),
(489, 48, '3de3d00030f3f8bee33bf0376cec5fba1e39b4cc', 'd09d1c9282eae583e1951969fde615d53e74e9ad4b4351dd82e8ef53f2e770d3', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-17 16:08:43', '2020-03-17 14:37:48'),
(490, 2, '31f36a4523dd612023ac0f761309159b991a5299', '29edce0dfb9b5678abc04a443e6d98513b893d724f7cbd63cf607ac38e248035', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-18 09:07:14', 'usermanagement', '2020-03-18 09:07:14', '2020-03-18 08:06:19'),
(491, 48, '404472151be76421c8eba561a69d81cbcde48335', '13ab2938917d4448de0f1292fb5679666a35019772ae4924fa26a9fa4ac46cd4', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 09:38:05', '2020-03-18 08:33:10'),
(492, 2, '6cdf4b8d78dadcb0050fdd1cc224e6d797ef75d2', '8b6220b3f1212694b84fab7118da843489785e161e0d48b568e728c64401ebd6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 10:34:49', '2020-03-18 09:34:36'),
(493, 58, '35d56e0421bfa2a7e2f397407fd6ca1cc58fb54b', 'cfe4381940df1a669aab4c35c78a7147be374bc7ba84bf926709859826075cef', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 10:44:03', '2020-03-18 09:40:58'),
(494, 2, '42b54dfebce61142044c4a40119e3f0d07211b5e', 'afa2da8ee42cf09953471711da7020d351b0883df11a1409a357e84a0f460e0d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 10:42:26', '2020-03-18 09:41:17'),
(495, 2, 'd51a19ef5f28363383c0af272e85bae5e8a71afa', '8a41c3d1eb8f8c864c2ba5af7e7d194a6254ffd6855f0f3e917479e0ce3697a7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 10:44:19', '2020-03-18 09:44:19'),
(496, 77, '7176f122eb866be2c7f3ed1e192a54b6c38424b7', 'f642f55a2845ca8d5503b521016ef4f98cdea8a2447d0f64ac5312b6bd5e42b6', '2.247.240.121', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-18 11:26:28', '2020-03-18 10:26:28'),
(497, 58, '6a8db923aa4abe205ba44ee10668aa4b66598f2e', '5e083b561596d4a6f10afaec8835f1668097a683cf05fced4f5f1ee10a514409', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 11:37:33', '2020-03-18 10:30:38'),
(498, 2, 'b0a5b9f21a213ed6825a4b167553d8b772bd79a2', '6862727d11285aaf5d2c1dd09ff051b800e4dc6ee18da6962ee28219528efbbb', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 12:37:09', '2020-03-18 11:36:59'),
(499, 2, '0b197a99975993dded7327a9ce9425bb302b594c', '334a0de94316098e7b9df09a777b7e2bb6b00b4e7b068435186e45e7ba194027', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-18 15:17:07', '2020-03-18 12:42:53'),
(500, 47, '62bf8d6782a29874e06e98a5d0963462a27835c5', '75875cbca2f3916f4b7c46a2403c56bccb876269c7373d755e97f6aac2d4e3b0', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-19 08:07:43', 'user action', '2020-03-19 08:07:33', '2020-03-19 07:07:33'),
(501, 82, '9af8185dac67a96459da0e8492ebb0afd5fc4541', 'eabd6ec5fa2805d08ce94fc50d6169e0064fa263c12ba59ca2c6829d1eddf41e', '143.179.84.122', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', NULL, NULL, '2020-03-19 10:25:17', '2020-03-19 09:25:09'),
(502, 2, '96fd888ddd2feaa7d4f4990703fd22cc97f11b93', '191500bddd688dafe07b45e7ddb012008fa5eee79d77d33f8e6e240566ab693b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-19 14:03:37', '2020-03-19 12:00:16'),
(503, 86, '17da57f9691ff3bd3fc8de1597032ce7b636aa9a', '99937de3d2f634103e4ed7da1ec5fc296eb31e840c5402cac2277c549e284b3c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-19 13:15:23', 'user action', '2020-03-19 13:15:20', '2020-03-19 12:15:20'),
(504, 86, 'bf07702fe51cf1e90062dff6f62e060baeaa7328', 'b59a383dfe4c571965a25c52dcda2779d72dd497e7a253e54748c350481c4dfd', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-19 13:24:48', 'user action', '2020-03-19 13:24:43', '2020-03-19 12:15:32'),
(505, 86, '9e237a618fe029d19aef5f959017e93a00e0c2b6', 'b4f3e3824f4d742a389936749d9cf785134476101787d203890c84f243e2f406', '213.124.47.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-19 13:25:06', '2020-03-19 12:25:06'),
(506, 2, '979114a17153f68d3cd17423455acd00bef92ab8', '9185a0bee72dac70b4b196212128ab1e99a0aa3f2678d6e1e917af1f5bc84e04', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-19 13:41:04', '2020-03-19 12:38:44'),
(507, 2, 'c072cca303440c5629b5c105d2acf113bf9535d9', 'bd5102e700e38e517211985c3800574a8535fe0c180e6d1b7c9947277fe56447', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-19 13:46:44', '2020-03-19 12:45:51'),
(508, 49, 'b79b12ea119a446d86bca32a4fb5646092e28aed', 'ae81f750c098d6c2f725308f0a92a75186282b719a5e260a61cce4f41cb4a3ee', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '2020-03-19 14:58:20', 'user action', '2020-03-19 14:58:17', '2020-03-19 12:52:43'),
(509, 2, '3d3384e88e5b02c62e59c6e3bf0ad99de7204f78', '65133ef0d8df35b3e5accffd7e9949f45dda2ecd31627483cb9329d80d23d599', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, NULL, '2020-03-19 14:22:16', '2020-03-19 13:22:16'),
(510, 80, 'dabe6cd60c8412193b977e0b2cc13afc5c8d24f0', '66976a2b88b1aa252627a13165967bc8b0eea6a065da8cfd1f3c454ecf4b7283', '217.103.166.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-19 18:47:42', 'usermanagement', '2020-03-19 18:47:42', '2020-03-19 17:45:01'),
(511, 80, '5f982eec56f1caa14c84e29d4aa5a5eb6839fd07', 'fb2659fbf9cc3120f27edf8e16c09d24b57a4b5ed3e8fada5e51146db0952bed', '217.103.166.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-19 18:47:53', '2020-03-19 17:47:49'),
(512, 2, '42c5afe8d936e3d6ee94553c5130df628ff5d78c', 'a05774c42b376f2eef60cfe6b3deefc9f990552e4c0c8e97a85d07f9cd456d5e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-20 10:01:37', '2020-03-20 08:55:53'),
(513, 82, '19af1342f8c6b65b3b00cc44253a0980692c0111', '587d7fd2b29ad97a7c48ac2ce81cb48e934eebad291a8ad4894c85c8d5afd4da', '143.179.84.122', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', NULL, NULL, '2020-03-20 11:35:21', '2020-03-20 10:35:20'),
(514, 82, 'e527581fa1b5021223f0ad717e8cafe50b623c40', '0b9d63429e2f0e7a1ccd536a25739ee81f924126bdc17ee65838c1e75348fc1e', '143.179.84.122', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', NULL, NULL, '2020-03-20 12:59:06', '2020-03-20 11:59:06'),
(515, 58, '5408f330f4a769a9073b072dc196ac7f738e205e', 'dfa1e597e5eb9d2e791fcd0d3c353070b9c33f92cfd3a80b01da672934ff6670', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-20 17:04:36', '2020-03-20 16:04:09'),
(516, 82, 'fd4268c3928e4d23d0f49c285da10883bb0505ec', '810fbf75437f6284039a763d463edaa5e6d0138cded2839e7ede998c5150a8f4', '86.83.206.22', 'Mozilla/5.0 (Linux; Android 10; MAR-LX1A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', NULL, NULL, '2020-03-20 17:27:23', '2020-03-20 16:26:44'),
(517, 82, '160c56dda808b25491e6d217ce33e03f90fe6ffa', 'bb261f21bed457054e94afc402f45e4e257e184e7a04aee8ba10a633c5da3df7', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-03-21 11:31:09', '2020-03-21 10:31:08'),
(518, 47, 'ca236b0a616bff060ca7a899c8b0b6ceab50b80e', '9a4fa150930b6b15d62e798880457610aa022a2a20e619b1b4580a9de4795be8', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-21 11:59:43', 'user action', '2020-03-21 11:59:36', '2020-03-21 10:59:03'),
(519, 58, 'd7744af225d1c41c4e6bf38ae2d78bb7c1506c11', '678cbbe6a34cb692c1a278c23032f5ed96e94aab4f79f4ebd47cfe8ba65b357b', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-23 09:24:24', '2020-03-23 08:24:24'),
(520, 48, '779d843b92bae876aa32a3fb0855064849e34485', 'c9ecf2e0a348bcabd490226061f3157af1451c4cd339df4950833df24c44341a', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-23 10:31:19', '2020-03-23 08:42:06'),
(521, 58, 'e39e55ddd9daee3001747f3c4487aaf6de85d124', 'adcf1db5c90882ddac963ca35f0f7977c8d0a7c57035d1dae3f9fa83efbdcde2', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-24 10:05:54', '2020-03-24 08:19:41'),
(522, 2, '8f911f468eb9e99d27292c3344baf1ac6de249de', 'd1a224c3c80a4e3f10b1580077c8cfdde45141bee811d688d7f382e28634e1aa', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-24 12:31:02', '2020-03-24 11:30:10'),
(523, 48, 'fe9e648e2196e608167e9d921204d145039757d6', 'cbaf4fcea4bc47f1d790fe57189fdd9198e555af7f8757315e4e0b3b21697885', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-24 13:25:18', '2020-03-24 12:24:55'),
(524, 2, '6dc978153d8de9af1898fe62764056d782b36098', 'e85af68e45772849c91e6a6a44e8e665d567758fede846cbe975d39a3e8a76aa', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-24 16:15:02', '2020-03-24 14:52:32'),
(525, 58, 'c981e0fdca936a657939adbd67049f003c1a27c9', 'c03fcc7edcd1fafc93e9d1e4b6d903e8e10646073c5c68c06d278e85374cd3e4', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-24 16:08:53', '2020-03-24 15:07:33'),
(526, 47, '5150f293ca66eb3c392199a70737b1c037089e17', '74a9588261283c4ad81fcf5216bc587d2c76b2ce942d2db4e704fd5a598ddf49', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-24 18:12:49', 'user action', '2020-03-24 18:12:43', '2020-03-24 17:12:43'),
(527, 2, '77c50a413ec566313825a5d76b793b3737a94747', '18d8484627b31e31e4aa46bcd2667de4c39ee533adde3af133ea8fcf19578e2e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 08:48:51', '2020-03-25 07:48:45'),
(528, 2, '6e678c11a9419b662e02b3a128b859aa34f1f97f', '2188cc4b2e2ca2f4164a8607ccfc9e7453d02c79e4cbb659790406ac09eacb0d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 10:27:23', '2020-03-25 09:13:06'),
(529, 48, '6bd07d4ebcf7fc1523b672e679f00cdee5aeebaa', 'fb9df7ab30027e12bd8249997a0633040e6fa60e682b72df5d7fcfaf0ccfd65c', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 10:25:10', '2020-03-25 09:22:23'),
(530, 2, 'dd5fe5e633aeac09462bfbd6ff85747db30ccfb9', 'c5f3d14181718dcb943d151ea0e21709a9a475fe236a212871883b146d15e957', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 11:36:26', '2020-03-25 10:01:41'),
(531, 48, '1d208d65576853b854925f8d6cf165bac2137ce6', 'd34cd8ae7a9d1c5747e6c385dede970be2a2ab465235bd9bde262659a9f39c35', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 11:10:43', '2020-03-25 10:09:11'),
(532, 48, '53f9159c55395f55466a43a1e5fd519f051ad5ae', '1c786f8bb52ee07cce4b11c0854784a39e2743254a3063a72d84032262e919e0', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-25 15:43:15', '2020-03-25 14:42:38'),
(533, 47, '83fd4d844686ecdcb33234230811ca295398ba40', 'ba609708241c6c96c7a96bcb3473309f9a3bf7ef4fabf071a9d60e61b20c0896', '213.127.58.223', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-25 18:50:50', 'user action', '2020-03-25 18:50:43', '2020-03-25 17:50:43'),
(534, 49, '15047df5a7307b1a23764116332919ae86cf4289', '1bd990089a3ab2e706696727ac1e51be6209028c154c0b40438bc232e90529d8', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-25 20:57:46', 'user action', '2020-03-25 20:57:39', '2020-03-25 19:55:23'),
(535, 2, '7c140a7986186bef3dcbafc42a10e8a5830837e5', '88bdb1a900d84751010b7d7d31a5a850e1a5af1d1321802bd80dca3d7c5e3cd4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 08:51:13', '2020-03-26 07:50:32'),
(536, 58, '45a61f018fe7f7f0ee59395e23ae80e97b0ddd35', '77ff58bf03523de79aa01d820fc4b15924d2e527ebf3535dcc22b9d57172aa51', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 10:34:32', '2020-03-26 09:33:56'),
(537, 58, '9cacdf8f48a70dd2edff2d9c04f9b2a13084692d', 'a911d6050ed0e8e499bbd679c9d11edd52a4199b744f55574c06492ccc16a154', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 12:55:11', '2020-03-26 11:55:11'),
(538, 2, '3521bca4e4ab5c7692e572cd89578f1a539e4332', '93e9e2408ee675f6ccd424e7c62f9b8d113447335fd0f1cbeb571223852404d0', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 14:22:17', '2020-03-26 12:41:12'),
(539, 2, 'e3a73912499d920c2550fcd581b0c1daca27f506', '64de944e0c9612d3753cd38c856223f5eca56f2c7ce815e605363eb8579844c4', '62.140.137.53', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', NULL, NULL, '2020-03-26 16:00:05', '2020-03-26 13:20:17'),
(540, 48, '7a4cde67b3d461b5dfe8cc016f9202348db61ef8', 'faaf8b8f3aabef73c65c1fa4c5eb964a908b8fe60f61dd0c39c4137f46b707c9', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 14:29:24', '2020-03-26 13:26:58'),
(541, 77, '229fa43e5e1b8a006472d152d0ffb70ead185bc5', '509ac665969c6f4d92cd31e0eb65b5adcab1a94ca05b1ec0c41ffe4ebc746508', '2.247.253.108', 'Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-03-26 15:28:19', '2020-03-26 14:28:19'),
(542, 58, 'b9c45230f48501517c7c58cb7bdff272a1cc319b', 'a7b0f7e7b6770bdd5b011da3fc864a690492226371b98ebb63be9af6e1bc687c', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 17:15:47', '2020-03-26 15:41:20'),
(543, 2, 'bce56c0c942012c2c4833ddbdd64a6120a577d15', '41ee81ab8a596c5d225e172e99704858efb9f97735411136e0af73cba8795a93', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-26 16:52:36', '2020-03-26 15:49:33'),
(544, 2, '82519005aa184a0d054ee82e65edf9d3f16e9067', 'a56a58b706be94fef836c4345900903c183ef10cb62148765331a08ac8fcac71', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-27 09:38:32', '2020-03-27 08:37:32'),
(545, 58, '3532403dc0e9aedd3452603ca2f5debe6c82122a', 'e315685cb85ce86afea73fcecf77edabb6a548c9b66d65f08f4c7df8d9fdc0ac', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-27 09:56:44', '2020-03-27 08:56:36'),
(546, 58, '5e45d6e33b4aa04289b055e86496d4d20e2ff5d0', '57ee889d4cf34ac90dc90f3b8a9249143558fab9b07c39befcc7463acc1f312d', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-27 10:05:14', '2020-03-27 09:02:45'),
(547, 2, '40462008e2ae201e77e805edcb2d881e90556575', '8614def1a4120c21ac1732498b923f972a0705bb84eacc08afd992e1aeba8ad7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-27 10:24:20', '2020-03-27 09:24:17'),
(548, 48, '0c9bee21babf31ee29a6c41e6e4f94383e39e71c', 'ff1398b084f80caf2f32d48e7c6984a11f7917269286e43839eb6e174ff4b825', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-27 13:27:13', '2020-03-27 12:27:07'),
(549, 47, 'e03bbb0ca5ae3047ac8cf6a73e5dbb160c0dc896', '887987018244c222a6864d03e91e3b51c2917d9c20401e33de57b11cce090286', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-28 09:03:54', 'user action', '2020-03-28 09:03:45', '2020-03-28 08:03:45'),
(550, 82, 'a7d8a3eb865fddb059843887d87c3b176e551ba9', '46ac3952a03ee817ddbd076cf0660c405a4f407c6cadd645bcdc75cb5030ddfe', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-03-28 16:58:35', '2020-03-28 15:57:48'),
(551, 2, '1b418ae47b91ac1fe8da05b2405c8b7de53352bb', '27d00620db15db4d137b99aae397c81f92839d0a264f34661adec753f16e3660', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 09:17:02', '2020-03-30 07:16:44'),
(552, 58, '4d79e6212ddc6da15d76554eea9123f11fdd79c7', '255cedcf39f7e7319a4d068cf126f22fa1ca86d4e7e6198f1598fedd8ff3676e', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-30 09:57:35', 'user action', '2020-03-30 09:56:54', '2020-03-30 07:32:11'),
(553, 48, 'e27698a9bad5731e2d75ef76068d1695f49a483e', '35d1aa03357e192ef221b4f0ddf06aa4c5edf4d1837344ed06c606f825896d76', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 10:37:08', '2020-03-30 07:51:37'),
(554, 2, '6ff0f6872bbdd6282e7dfd921ab3ca606d294f74', 'c8a8c0031ebcfffe718d98124116785341a3df12c55947fbab3a297146de18ba', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 10:36:16', '2020-03-30 08:35:50'),
(555, 2, '5c3f0126b73b10f5381c4c9e9192a2ba4c7806f3', 'cb4952d48fb744fe101950470280292dfb8ac02a936d6430ffd05536aa7161a4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 11:17:15', '2020-03-30 08:36:42'),
(556, 58, '5da6f2ce42752e62c444e0ee86e492701bc1bbfb', '53aa7854869523745707292cc514370b37c4bfba4038be1169b3cd6d2aa093ad', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-30 12:59:45', 'user action', '2020-03-30 12:43:41', '2020-03-30 10:43:17'),
(557, 58, '329992f6003601e5af2ec39d644654774c3d8105', 'd98ade7f8685c6d8a54443b7caf3a7d5194a9d4e3d912482b759a103e74602cf', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 13:24:02', '2020-03-30 11:24:01'),
(558, 2, '8135c67e078f72a2b560d87d5cbc85823a15c47d', '2f5d372a6a360efd5c762b0da4d4a0fd2bebafc70fdcdec66354380f583913a8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 16:33:06', '2020-03-30 11:51:17'),
(559, 48, 'c75a5e2188c15732e189ee7904c308b3df684743', 'd436c8ed1b0470e6fc2a33a26f054ad956b328dcb60ad938ba746c6d581886cb', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 14:01:27', '2020-03-30 11:54:03'),
(560, 58, '4d4efd97939c15dc8f744852a079dbb03d100c26', 'cbd9361760d908abd6b2c47accd2ca4348ac4acc787698bb34bad3dc222313ea', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-30 14:42:38', 'user action', '2020-03-30 14:41:36', '2020-03-30 12:32:49'),
(561, 48, '6ac9830f348466f567ea1a2ceab7e20916be4ea5', '1f7a4182b6c4fc1fd13bc5f055738f88d803c78b168e08a3e7e7e06bbf9b111f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 16:17:36', '2020-03-30 14:17:29'),
(562, 2, '12ca064762829b830589066f44a7c3b7e85f97cf', 'efd617cfce30b37bebd0075c26b32a3dd3fe7e6d542854df89769c1987b14368', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-30 16:46:25', '2020-03-30 14:36:08'),
(563, 81, '328f874236f28242f9fe6cd43c584117714720b4', '267ba41fc45a26cbf05148816f6fc37256cdcfb22883027fadac3a810e610095', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 08:53:17', '2020-03-31 06:52:54'),
(564, 81, 'a75b8d4907b2cd310c95773f9a014ef6763fe9ed', '5f87afb873ad5278d65b3115b16740fa01cad04988d8a57a1da4611887c7c9cf', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 08:54:18', '2020-03-31 06:53:59'),
(565, 58, 'e30085339ec85d146af798082aad7b6c078acffe', '897e38a4aa8b0bc8b60d658c0cec87b9b8df22b5d155e937ed84c68cd437f2f1', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 09:41:57', '2020-03-31 07:41:57'),
(566, 58, '62467539609881d45303de628d1cb0e65de79355', '8e3b4b7025706a3854bb8caadd1208b4c0a268a8e31fac702f9409b1cd74eb35', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 09:59:35', '2020-03-31 07:41:57'),
(567, 2, '0bf9df0db3cbc1d3f281ef04885a88968b2a8d2e', 'adcb3946ab64ffd33bbfe9182ce820123105f52f326554d9df2896b5172f0cbe', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 12:24:48', '2020-03-31 07:42:39'),
(568, 48, '38c3f332d73372c595a69da89b24aacdd9d9206e', '7167c45445316cf69e2f56023ec6ca234b5f77d27caa229513aaf69ca61e1b0a', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 12:22:40', '2020-03-31 08:01:58'),
(569, 58, '803fd0cd6ecfdce89dc1c0496a19b76bacd911b5', 'bdda5e09598e8cb2b99c62d007f82363b82b0a4599ab3bf3b54db400370aab1e', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 11:47:59', '2020-03-31 08:41:06'),
(570, 58, 'b46f96c69e45c868037975f257e39a85b7a86e44', '1dfd42cbda909895c04447568ee030d0e7b5b12f3b395d89d58123d30c8789e0', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-03-31 17:05:28', 'user action', '2020-03-31 17:05:24', '2020-03-31 11:33:54'),
(571, 2, '1726e70a7b76ee3950783f9d4a8fbcb08efc4bb8', 'bb44f68e36ebb399108d1b2c411edf28da34a22bf1cd154dee2ea2e93065bcc1', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 13:36:18', '2020-03-31 11:34:26'),
(572, 2, '994d492e7f5f645126146ca020eaee4369db90c1', '1338140e305aea7286bae1de754def4401f122394cd97d73afbf66b58e95bda5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 15:29:31', '2020-03-31 11:40:17'),
(573, 48, 'e62f98d26672868c9bddd2619bcc0160acfe46dd', 'af648eedfff2c00d3b89058e66fce7ef3fea7be8de788a10e3a07726a2b33c1d', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-03-31 15:28:00', '2020-03-31 13:28:00'),
(574, 58, 'cd05b3161f305c34eaf37d98eadb31374e5baa28', 'e64d5c0b0bc1717f8e50580f86636400a2e5baf84d5a00dccf637987144778e8', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-01 08:14:07', '2020-04-01 06:12:49'),
(575, 58, '2994543edee31f8b0467ee00f5eae60b55849307', 'cbc76f1ef4fbe074ac972809de66aeb48ff09056076c9710430ac33ff7852c3b', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-01 12:44:57', 'user action', '2020-04-01 12:42:48', '2020-04-01 06:34:59'),
(576, 48, 'ef78995ede295cdf1d04d7974747937db9095a34', 'c56918f16790bbb8e92f173e0df84d3aa8087f46a8957a1d3de0107c6acafb35', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-01 09:45:52', '2020-04-01 07:27:21'),
(577, 90, '78deba6bf160a485ecbe63c9079db3945c45ced5', '2180eb48061986d6f3eb015f368b9e7792c3400b1434157df6760b41e250a2bc', '86.89.65.66', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_1 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C153 Safari/604.1', NULL, NULL, '2020-04-01 09:37:41', '2020-04-01 07:36:44'),
(578, 2, 'd54107cc2448240fdfe5e0734867cd2c397b9be6', '49d2d78e85f9b4a28864ae2c54c491a1c670d238018ed7ff0ef50c2dde51ee70', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 10:48:14', '2020-04-01 07:43:31'),
(579, 88, '8444a299c1b4135c8a991eb593f93d26173d42cc', 'f9eea295627b56ad1056461915180eca9028d889d4ef7a5f2b0cc50c92097a55', '91.141.200.172', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763', NULL, NULL, '2020-04-01 09:49:02', '2020-04-01 07:47:22'),
(580, 89, '0e6aa95f17c6d35ad60afac2cd6aea90dce618ba', '2821134a0ab7aaebee7674da65228f1b22af7ffa2bc1a93339133f37e8230a56', '86.89.65.66', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Safari/605.1.15', '2020-04-01 09:51:17', 'sign', '2020-04-01 09:51:17', '2020-04-01 07:49:46'),
(581, 2, '5099bab75b1234861f998c2a1f77c55b4f7e5739', '25c4c227f0bf8a0b7011180da37b7bb449d2d02388036d25e9b0ab8cd66d050a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 10:49:52', '2020-04-01 08:49:52'),
(582, 2, '0647caffa118c4e2dba0c8a71cd4101567110c21', '27a87488eacb8582fa1c67c1682691deb0e28e67b7a3998fa1bd65b4998c4236', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 11:25:06', '2020-04-01 08:50:15'),
(583, 2, 'a56df76138e6268436a85dd7fd9a1f5d1d2b385c', '9a4ee6c8ca026b053591f6b7913f93267cb450dbafe1e300f41a6890b2fe742b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 14:52:36', '2020-04-01 09:34:48'),
(584, 91, '4c2f9b067baa66422d5e4a26d5ee75ce3d8109f0', 'b6e02d0fb1e7d4751e72a236a99afd28e7110e0f8c5d7018a0b24fc2e23a48ef', '145.128.195.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-01 11:56:15', 'user action', '2020-04-01 11:54:21', '2020-04-01 09:53:49'),
(585, 58, '547f962d2e3bf956cdee46a0757bb976fceac6e0', 'd2a3cfb087b9769b820c9410e50f0f69f124a68b1aec79de0f53ba5cf3488a8e', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-01 12:24:54', '2020-04-01 10:12:48'),
(586, 58, 'c5e02643d4642a4ecde124f1ffbbd61562affb78', '076271eb25fd210b2bd944ffbc504530a37094861ed568e6c7d9e6e51fb54691', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-01 14:05:09', '2020-04-01 11:27:59'),
(587, 91, '832cb809f0710e228ee48927f6509b55371a6262', '82ec4645da04262c579364a5c8984b740b2b08eb99a325a73cab43e96e5b50c2', '145.128.195.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-01 13:47:39', 'user action', '2020-04-01 13:47:17', '2020-04-01 11:43:03'),
(588, 2, 'd81d0248561ffa2f44e94d044574c45f8cb90748', 'd72703d15c7cbe0b8a91d858ba473004e9e62eadb962f6589d013d310cb7d57e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 15:25:01', '2020-04-01 13:24:46'),
(589, 2, '8d0765ec98f2287793ca9b31113465c79488f321', 'fa0949fe40441fd677b9e38dd91f84d3b85b12729f5f57cf129b80483022c95d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-01 16:09:44', '2020-04-01 14:03:09'),
(590, 58, '2e8008bf24c569f8ca8941b6863e631c7a88007a', '03f6a22b83ac4e36f67a9e14232caf215d07d97aa426ec9b4c377c6069221058', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-01 16:40:10', '2020-04-01 14:40:01'),
(591, 49, '71d801ade317ac23a6315457deaa2fb2fcb3a895', 'a95528fca839b241990e3d4af03e8219396bf408843ef6857521b288cc7799ff', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-01 21:23:06', 'user action', '2020-04-01 21:23:00', '2020-04-01 19:10:01'),
(592, 2, 'f291718f28df8942fe2be05f7471f42a57ced2a9', '6ce3b2e07d6407565324b4c6cb7c7318a2773340e8f504f8d52a1c4ed6ceb233', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-02 09:34:00', '2020-04-02 07:09:13'),
(593, 48, '7f676ca5326e8279c45245e70e160e4b1861aa07', 'c9815e52aed949437200d7e3bdb8806cc961872817946890d8744c25a6ad6328', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 10:39:03', '2020-04-02 08:22:52'),
(594, 2, 'ec5cee4ac7d393690d3ae3cc6ed7c049d1621e65', 'ceee542b745bc1299a424af2c07b657c9b4619f0d85626501cd7b9e12af258a6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-02 13:11:52', '2020-04-02 08:33:53'),
(595, 48, 'fbc6e467d5b140fb26d6cbfcbadd6bcdd5235eee', '46f487660838a5a5580eaf262a3165e61819672531fecb23f8ef43e3df58d048', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 10:55:41', '2020-04-02 08:55:14'),
(596, 58, '26ccaf9173edb530d9a2ec48c43b26df997edfd4', '296e2dcb600b747cd2106ab110cb4da18ad0a01d672fc242408709a99fdb8495', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 13:41:58', '2020-04-02 11:39:15'),
(597, 49, '8a4c47aa0a90ab39ba736c7734598fcc7456283a', 'e5ea5ab3d481b092bfa2f611a513e0eb14d9637d248081891c8737a5fb0552d1', '62.131.11.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-02 14:45:00', 'sign', '2020-04-02 14:45:00', '2020-04-02 12:15:38'),
(598, 2, 'dcda376ecd2b8ae1618baeebea9f7a6ddd6d6f4d', '7386a774d8b2449b7c32dd408409822612732badb007968e8a8ebabb80776da0', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', '2020-04-02 14:45:01', 'sign', '2020-04-02 14:45:01', '2020-04-02 12:16:31'),
(599, 48, 'd6ca001d14c967b46b5380fcde10afa4a954c805', '101cd3f130dcbb7c34a44e09f7b6f6c80161c36c1d4e42d81ad69c48cdaffdfc', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 15:38:28', '2020-04-02 12:16:48'),
(600, 2, 'a79eb42c3c193faabb2b3f9df5f74e471dfff59d', '0255a709960430c6a21fa681e48bd0ad7510a177c188908fc7115e0d59eb2b4a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 14:27:58', '2020-04-02 12:25:49'),
(601, 58, 'bce55d40e36f40a0b74279589945e6e68c642980', 'fdfd4a049bd2efaec976b834135b647a530ff0fee7e209fd3b5554285fe682af', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 14:36:38', '2020-04-02 12:36:05'),
(602, 2, 'a15749d23d31b8c5b1f4f7d149fd8f932080b9b9', 'b8517e8be4eac8bab0d663c41a25c9daa51fa039a3844dfb508fd7671a17738d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-02 16:19:54', '2020-04-02 12:45:09'),
(603, 49, 'c2588c94095c48686ea3d126d78a109308d00293', 'cce1667996d2f3d29f019fc620474ec6634fac670a653f1313c9f45dce5e22a4', '62.131.11.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-02 14:59:37', 'user action', '2020-04-02 14:59:21', '2020-04-02 12:57:39'),
(604, 92, '7d9a6ee108ab1199f2cd15663728b114e69affd2', 'dbece46193db79451d482795a95f57b14171ef714cc62c0731b742c36cda71e3', '77.175.212.90', 'Mozilla/5.0 (Linux; Android 7.0; SM-G928F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36', '2020-04-02 15:37:40', 'sign', '2020-04-02 15:37:39', '2020-04-02 13:35:34'),
(605, 2, '9e473fa1db5723f2550343684b601d3879108c62', '100b9f615efecb9642fa004f27dd7cd815ba74e8053ac44a912325fc59acfbc8', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-02 16:17:17', '2020-04-02 14:06:10'),
(606, 2, 'a2ac7454afd04c79e821fd647a568e13cd0ca1dd', '7fc908d285f7f2ef0427622999b06e633feb91a0d18a626d5cf9e716912be9de', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-02 16:28:40', '2020-04-02 14:26:12'),
(607, 82, '0cd76f841144885e9e780b645dfa822a56fa98c3', '493cab2f253102b6e0c874f04ec5633ba0763699a91716fa5c4e92b27cd60527', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-04-02 21:29:55', '2020-04-02 19:28:55'),
(608, 48, '94149b6fedb11f170e078a5a35336b4946f8b5fa', '1556fe8e216092dc67f188ffe16a436843df0c6bf1ee54bd8b5e48bc3443a526', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-03 08:50:14', '2020-04-03 06:45:47'),
(609, 2, '5991fadf5e9a88be6c81d5e7cfab5cbf5d74f118', '4782ffc8be3435b91241e979483f74724e30c19d71253885ff35973fbb0b8b5a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-03 09:09:35', '2020-04-03 07:09:21'),
(610, 58, '77a2c541d9a9ded45e089406ba1bb47d80f28a77', '8f916f7cbe169dee3284e216e7a9d085e592f430481e7a5117b45b872fd10ec1', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-03 10:29:03', '2020-04-03 07:24:41'),
(611, 2, '7fbf1341ab38b323f8f54a64f61b2eb95c5cd392', 'bf21d400fd73f29cf5bacf85590efa0f225e6260a12e2c7ba8075a4b3620a74d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', NULL, NULL, '2020-04-03 09:49:42', '2020-04-03 07:31:53'),
(612, 94, '8b6c7cd57b3bf62eccb0b4e0353fe8e92c1ad4c3', 'ed6c6b295b1970492dbaa9be63b014f372221e0929e13436b9bb2979c404dc3a', '213.233.104.238', 'Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.1 Chrome/71.0.3578.99 Mobile Safari/537.36', NULL, NULL, '2020-04-03 10:16:49', '2020-04-03 08:13:02'),
(613, 92, '41bf1bff47c8b249d0a630f94d4a15c4b150a535', '7defb5d35a7960cd46a5f1846a44d0fa0c5941492ea2ce33bded1bdfc2b5a07c', '77.175.212.90', 'Mozilla/5.0 (Linux; Android 7.0; SM-G928F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36', NULL, NULL, '2020-04-03 18:09:17', '2020-04-03 16:09:10'),
(614, 47, '1513c8c9900d4662acc8bc907d2fd405487a3530', '1ef4df01bdcb6f014488f6aa18403d3671ad0d9992c6306545f710a40524d5ed', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-03 18:51:05', 'user action', '2020-04-03 18:50:51', '2020-04-03 16:50:51'),
(615, 2, 'f78f531821231ed5ee7d73cbcdb459a6fe4ea5fe', 'd50cb27f19afb8a1a55bb3247b50cd56098413f675a6629af5b75295c653abef', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-06 12:10:14', '2020-04-06 09:45:13'),
(616, 73, 'cbf372c133c96a08efe8ca29e3ec4f0c67016de0', '6576b9c1ad938209e7420b2a4486aa9f9a09bb0b9814bfcbf0cfaf4f70c3de9a', '77.163.222.97', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-06 12:29:58', '2020-04-06 10:23:39'),
(617, 58, '5dcb6cc4160e16b8b8fe88df4485c109213928d5', '68ac255998ca3a09503896469c56feae10b8b7e91ca96ac50419722dcc697c61', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 10:00:06', '2020-04-07 07:07:47'),
(618, 48, '1af1d46db54ebb509730913a4344659d080cfdb4', 'ef39453a01eac8323b91d68f9229fc53ba05cd5d3da2c8813903d1490eea6a1e', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 12:19:38', '2020-04-07 07:41:28'),
(619, 58, '8b188706ac2806011f6ab669984bfeddd6706195', 'f0c155b7aabdc312be348a2d15c15c4e80c7792cb7723c56125d790937323b36', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-07 10:02:34', 'user action', '2020-04-07 10:00:26', '2020-04-07 08:00:09'),
(620, 58, '9f6954b08958a9e22c9be1ca0dbf9e0af85e0d6e', 'c5205cba48120dc1f2857fe8368375b7370365d97be8100fe2df5c0e30edf095', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 10:40:06', '2020-04-07 08:13:48');
INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(621, 2, 'ee18a3ed5fee0a8d0e18bfbbdc620a544e63b276', '31bf0b2d56fa6ba9d4403d1804da2faf25aab585a69243bd77da46d050b67520', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 10:41:25', '2020-04-07 08:23:32'),
(622, 58, 'c91ff42f88bfc6df02a358f9403968471367cfb1', '6a9ed867ec88d9a7e8b371eb62b01c751874d522c2c82bdf2c1073e2fc76688f', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 11:52:32', '2020-04-07 08:44:01'),
(623, 2, 'babb95e4a8e86bc5bf6e171b9113cec3c3d2e6d0', '33d4b49bf4bd4796fa797d8e00c8da7a4f7701d3ecc91b13dd21a2d9e30157bc', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 11:13:47', '2020-04-07 09:13:45'),
(624, 2, '2ab31ae0d6494c59a21fa3ca0b804aea98cee745', 'ba7c325d4974e9b958964d8e3d923c4a17818b0e857481c0eb21a0f055997179', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 12:13:43', '2020-04-07 09:24:01'),
(625, 58, '246aa2be60808f588281931a74967f8b129166e4', '640fd103bc632208e78d7672a26d1871165348021eb7ad8a574e0c1576e4cf1e', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '2020-04-07 16:00:49', 'user action', '2020-04-07 15:58:49', '2020-04-07 11:25:55'),
(626, 58, '67812004de07ef0fb0e382daa0184d7287aaf247', 'f00cd24551d830e58fae237c2ffa2ffd8ea50f425d99e514a8abe9e83f7762d9', '77.60.175.237', 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko', NULL, NULL, '2020-04-07 14:44:40', '2020-04-07 12:44:40'),
(627, 48, 'ed60c4fb133c99c4ac752fa45dd529730b8ff374', 'e35cc1fde76afae8a060f6027c406bc4ff5c2e93d4679e7743f531c777f2010d', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, NULL, '2020-04-07 16:01:43', '2020-04-07 13:05:31'),
(628, 2, '77152636555d1030e459c73ccd5907529ccf4b55', 'c6aa17774a9e86713f1e0ef1d88c4fc71e42a8958c526e3e6369e1801d7249ee', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-07 15:56:03', '2020-04-07 13:54:25'),
(629, 2, '9108ba29a629f328dec26bdde0d2936155da7722', '81ccf6526f021cea01878af044de9b482c5ee3f6a025d7370fb29b282d9957e4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-08 08:58:30', '2020-04-08 06:52:24'),
(630, 58, '4e01cde328fc1df79045f33ca9ad047a78b55a2b', '432075d2a25d975348dfafda0ceefafc94a7ee09cff1ebde5a9a535ceb70a25e', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-08 10:25:44', 'user action', '2020-04-08 10:24:48', '2020-04-08 07:00:58'),
(631, 2, 'f7d067dcceb39ca5fd4e156212d8f734bf7a2044', '6d7d88b7da44ffb126b8f2fb3c7072ebccaba9685acb45e77efb50e5dc182fae', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-08 11:46:08', '2020-04-08 09:45:38'),
(632, 49, '3d476db66ade13f890287e139096758368b7a20f', 'da9928f15e47187a7a36f9ff43f92c8dc8c76344df6ca273e23d73da4e1c16a9', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-08 13:32:10', 'user action', '2020-04-08 13:32:06', '2020-04-08 11:28:26'),
(633, 2, '4a95d8493a20ed65277abd98269df1833dc30ca9', '1928d3f68fd860ca55e43b0ef5630fb59e10454628f496cce8b8f7b488c822c9', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-08 15:31:46', '2020-04-08 12:02:38'),
(634, 2, 'e1b229f615ac91b5f58edd13596e0fb1a0deffcd', 'cf0e9f3a08f1791eed02bfb3ecaf187488b24c9846a6e0abf2116971d6dce422', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-08 15:38:35', '2020-04-08 13:32:33'),
(635, 2, 'f9de7753f38b8b7589b11ead28fbd044bb5bdc8b', 'cce8cf39807f1c765e1eba413961d9b4de36bd0642de20403fe1cba7382bd00c', '62.140.137.150', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36', NULL, NULL, '2020-04-08 17:39:59', '2020-04-08 13:55:51'),
(636, 48, '09c5b22428712ce652afcfcc94ffc98aca5eb94f', '355d95eb3f0a88cc89320d761392aea4821c76ac1a11dd325aa21b64001b2b6a', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-08 15:57:09', '2020-04-08 13:55:52'),
(637, 95, '26eb5732843bb2fc6ef0f38da45a5d2eb9f615ec', 'def0640f2b2979d31cfbc78589ab1b0def93ba5b3538e1db5a4b770da40750dc', '62.194.45.160', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36', '2020-04-08 21:21:53', 'sign', '2020-04-08 21:21:53', '2020-04-08 19:20:34'),
(638, 81, '2ec12c9c96fb982c258d9b1cf9ad7b90b483bfd7', '37fb1d09c91766e3f92a40b381b6253fc81ee8145785715bd7435a47152a8ff5', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko', NULL, NULL, '2020-04-09 08:46:42', '2020-04-09 06:42:56'),
(639, 81, 'd5cbe3e8b3d306c8ff00e4808fcc1977a442828d', 'f9002092dd44bbfc1680438de6d18fadff63785aaaeee81bad240bfc791ff9b9', '149.210.221.141', 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko', NULL, NULL, '2020-04-09 09:14:25', '2020-04-09 07:14:10'),
(640, 94, 'c37601142f55eae94cc1d893663f34c744446920', 'b53dd65c91e9c6d14decba0d54f18671d01db67f751f9d6f507e6c92530c774c', '213.233.84.242', 'Mozilla/5.0 (Linux; Android 9; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36', NULL, NULL, '2020-04-09 09:26:53', '2020-04-09 07:26:34'),
(641, 2, '615f6476ee7db604560c5b3ae7d83354c5ddeef2', 'e15bf6b52fda7069a757cfb0f77e16cf8b12915445283e760043b694c15f1ac7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-09 12:19:53', '2020-04-09 09:06:52'),
(642, 2, '73f235f16b9774442176983429b3d73196715b12', 'aa2bc0096d636d0e3a0ec5af6e5fe2f70d73167a47d80042d21bb6ac693c4575', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-09 11:46:53', '2020-04-09 09:40:17'),
(643, 2, 'db106e2bd230cf3281814571506d101b053c2ff2', 'b226fda131fd05b5b563cfb243a5d40fd1c781ce0d0ccfd3b630025aac9c27d5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-09 12:33:06', '2020-04-09 10:27:54'),
(644, 58, '4e24f59cc92b34f567d58819575aed05d05c9968', 'd52e48b34ecf8ef58cad8e139e82814d3d66f34c55635901003b94a63259f7e3', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-09 15:53:40', '2020-04-09 13:51:19'),
(645, 82, '5767ffffa37d846b97e17be01a08ec0cd2fd8696', 'b6bc488552587bcccc309f941aa2d2f3d78d796af8de5928fb08a339e1210db0', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-04-09 17:20:48', '2020-04-09 15:20:34'),
(646, 58, 'aadbf81cc3aa1ecf69957976bd3af7e85c2e2529', 'ae1967a47de715a389c3b52fa0d5acb69ac388b652fa7ee8a4a1d96bbae1890d', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-09 17:38:58', 'user action', '2020-04-09 17:38:30', '2020-04-09 15:38:22'),
(647, 58, '10cfca903997f8daa97eb0f1c40be79c31c4e950', '49c23d8f9da1f1236a539145039d854879f582daa3a493801bf253f5a694b6df', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-09 17:39:37', 'user action', '2020-04-09 17:39:15', '2020-04-09 15:38:59'),
(648, 2, '6a29978e56a4b360124b2af6ebb3f9b793b02ee5', '15ef86d66ed7e853a517ff38a97c2f4c6358a0d5b2ca8246e28e1e37d8231670', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-10 09:16:42', '2020-04-10 07:16:41'),
(649, 47, '04d50b91774059000fad4158d77497efc7db2036', '9308f0f4b06b99da9feda6440ab4dd4eb344531624e66970eb317827b70c3754', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', '2020-04-10 19:25:55', 'user action', '2020-04-10 19:25:48', '2020-04-10 17:25:38'),
(650, 94, 'c86a0d415a48a3405e7788b7b616641a3ce5d9e4', '79722ee55afea45e0c2fa64c183593250af4c49e8221be6d64c9e09869cff502', '213.233.104.206', 'Mozilla/5.0 (Linux; Android 9; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36', NULL, NULL, '2020-04-14 05:42:20', '2020-04-14 03:42:20'),
(651, 58, '06de96ff0a112530d500a591ef787933c2efc732', '4f6fdb95e1512b4399e72970d4901204e5b1c98f868e363a07f696e2efa336c6', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 11:44:06', '2020-04-14 07:18:34'),
(652, 58, 'd5adf128aefcf25ed45c4632a1adfd0af4cb4567', '1b03b0da1235fee892e5a0d3dfc994a32cc2df025c5f316c3ece284ed52cc2d8', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 15:16:37', '2020-04-14 12:55:38'),
(653, 58, '88df6f2b5eec6a45a7b16fdf5a490d850f21048e', '791c6e74b03ecb607115abb80b7e497f8d8a5f4d7f2c127236a3c59fc68041e4', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 15:20:09', '2020-04-14 13:19:58'),
(654, 58, '6468f66b28755dd78a78243d02dea087503c0020', '32eee7e45bbcd0f5abb931d02ba1a83ce867c01961eaa5eb724b809b6dfe93bc', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 15:53:57', '2020-04-14 13:34:53'),
(655, 58, '50b99bff26fa91d11f09b6896efb9843ffea94ab', '100fa79ee47c33568d302beea48f4a36242a565ccf36cbd7f2289c1e3d322dbc', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 17:19:45', '2020-04-14 14:19:15'),
(656, 48, 'bc7056a7a028e53d6f9d987d406a5fd6f6473061', '4eab0808a10dd29bc2b860f67042ec057b3ed1aeb84ab11b6a82572e9dc76983', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 19:23:22', '2020-04-14 14:20:41'),
(657, 2, '11cfc9712107dbe34be795d34f0cd91c61b6833f', '68912dfb62fade88ec3ae4328fcd8db8ef2411dd0639e0ad3dfd86434cef5324', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 17:11:39', '2020-04-14 15:09:10'),
(658, 2, '2bcd2c180275b16d1ad903c3ac7a234656f31f09', '7c4a1031f033a605881e66ac48e439c0c28462a4339ee10f13ca393a4f0ff44b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 18:49:08', '2020-04-14 16:48:19'),
(659, 2, 'a537c26172a96d269960210d0b32e8a5e17379ef', '709ca3cd0a14e467e4c561d028afabdc452723ed9209f50efa0f0bbfb872400a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-14 21:30:25', '2020-04-14 19:29:08'),
(660, 48, '9700b15a45b9b769fefed1de5e604b839e21965f', '6f93951133d80975d91668683e530f6cd450df4d45107a12c5471619f800966f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 09:12:01', '2020-04-15 06:12:14'),
(661, 48, '8162c0ad845eac670725cc885a3cf6276b7948da', '5b71fc33e371e7ba6008ea3dd099f948c8bb24ffa35338d005206c7f6728f0e2', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 09:42:46', '2020-04-15 07:17:57'),
(662, 2, '910b0a826712b85d1d58f048ae31f1685627dc9f', '985609a3758320cd9048555d18a1bf920a629229d17cb042e94b06e62e28658a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 09:38:08', '2020-04-15 07:33:35'),
(663, 48, '4bb01c01477286def45e5e219b3560712738e4cf', 'eef2779a4c06dee1abe6a1c2de91c2e9d54f40c96d33ea9c51f47c16174a3400', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 10:50:12', '2020-04-15 08:44:22'),
(664, 2, 'b862d24f25b2826f2417600ad009ab4100bbbbb6', 'ac5e393f50ba44c69648f1b734528e465de4756bdc93096e3940eca36ed8ec71', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 11:58:12', '2020-04-15 09:52:48'),
(665, 2, 'c6e3dbd11aff2d388dc5830318f38519c38b17e2', '05ee51a7ea6a68bea8b2390e4a12a2b949d8289dbc46eba54e746d17531bd8b7', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 13:01:52', '2020-04-15 11:01:28'),
(666, 2, 'c1714d5d32fc44be3deda8a99ba6526574d82190', '6c3cc33bfc6ae9145c9b29167ac0067fee9eaf43936e6be86a1de2e96a5b5ff2', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 13:09:02', '2020-04-15 11:08:45'),
(667, 2, '6d54476b258bf2ba76ec956fb326e0202831ea6d', 'd92eca0f672e1119e8913ac33b29867b41a59f5615504a571b4957fe2e32869d', '83.128.38.37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 14:31:48', '2020-04-15 11:11:43'),
(668, 49, '0ecd1409d228fb6d5e1ce681a0f83b5ad9fa3a22', 'd8d9aae05bb097dc2fbaca78457ab19fea8afd36a4280b198e974c991c4e5847', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 13:20:39', '2020-04-15 11:17:06'),
(669, 49, '9b1624468ee389a3538b76e03ae1786fdf095f4f', 'f7d6ca45bc16604c15cf1e71d5f218ecf35a18c49a16ed531086e93ba1bc2430', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 13:24:15', '2020-04-15 11:21:05'),
(670, 2, '7e26bac6c4fac68d108373786d8dd18f9a541b5c', 'f548104a428aadf55cdd8385ad31eea5032c7b2d0c0cdc434882f12603ac12de', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 14:19:46', '2020-04-15 12:11:05'),
(671, 2, '8e69603b6b02440a97ed705ca307590fd06ee584', '96542bdea771a28af33cd205820cfdfb87fc4f459c153f27aabab6eaa793524d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 14:36:43', '2020-04-15 12:29:38'),
(672, 58, '74abfc7edfb61b008a680f64bc38ca9fff71ff7a', 'a86b2a59b62f238cd2cabdf9349ecbd45989e80a0d14b71566ef3bf1de29179c', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-15 15:38:56', '2020-04-15 13:38:08'),
(673, 58, 'b6f6729ec09d7ead236f0f67b3aa60cc865ec065', '25a68225d67f4dba7e041ae403b626d1b7b51e5a3320e074b79b449c8ee984c3', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-15 17:04:20', 'user action', '2020-04-15 17:02:38', '2020-04-15 14:49:32'),
(674, 95, 'e509aaa43515b646d2593d8e59d9dcd48c67cc60', '91da0d59810e2c823a12d564d2023958dcebaf0f61f7b873bba009d008a5cf39', '109.36.139.19', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36', '2020-04-16 07:29:41', 'usermanagement', '2020-04-16 07:29:41', '2020-04-16 05:28:23'),
(675, 48, '348e0729baf064b64f08d5bc039b39c1462c48b1', 'e8b1905aac171c35b7312e7dd134c18b42c9931fc7fd59602a3072bd64e7e7c6', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 09:06:34', '2020-04-16 06:38:01'),
(676, 2, '8a0262355df358decdcb7071c6aa48ac4fa5b3e4', 'd9d533d47a5c2de7a8284633e852e56b37b2395ee902a0ca6dbe2aa14aab92f0', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 09:45:13', '2020-04-16 07:05:31'),
(677, 58, '3e340917f461b9b42286ac8a70e049f67aa3f370', 'd82170e2bc4edf2e17d5361375f736aef4123041bd86b8872a61e98b910ae582', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 09:16:51', '2020-04-16 07:14:40'),
(678, 2, '6f0a3711acdde190446ead2bc1047c6eda702f22', '1f2fd19cf0815769dc32a9eae1a34e34b36ddf93f400204e8cf16896b8beb9ad', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 09:35:54', '2020-04-16 07:35:54'),
(679, 2, '3678f805640c2def3faa144f35c719c7382e73cb', '361bd2a5b8bdbbb8f9698271d883559671418eede250009be47b6e7f81ada6ba', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 11:14:10', '2020-04-16 08:03:27'),
(680, 58, 'cab987da298b0771263bb2f985d5ac875d90535f', '32921af590316b0f35d81e80dd222885fd17a70f0ffa91f456e181a2c13f0415', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 10:28:55', '2020-04-16 08:25:13'),
(681, 58, '0a3c16ef2a0cf27fd2b0b52b19365e03371d057d', '65929c0908cca3f756ac7dffd8912f57fac4eb5430cfe5169b751136b8cb9f8f', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 13:25:37', '2020-04-16 10:32:21'),
(682, 2, '5152c85f272525916d1a8463cdbf721b4a1e3eee', '0ebb524c5b02ac514fd2f68920d90c74e9e66547ce1a3c666536872f25aa09a2', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 14:35:10', '2020-04-16 11:40:36'),
(683, 98, '58c44f8253fe51e7f9ee50d998cf3a9c11c3e446', '5f5459aabf02075685e6370160de4bc9f6af80f22d6a5830dbf56d46115205c6', '83.128.38.37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 14:04:18', '2020-04-16 11:42:28'),
(684, 58, '49f71fea2cbdfd524e6a23e05ad46176d4104716', '2160de58d7344d3ae1c22b966988f94da01f7fcc3c269c13cccae6aa1820c39e', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 13:50:33', '2020-04-16 11:50:15'),
(685, 58, '9f507a7839d39e9c5b42224c75026da48d1092ec', 'b22c12cfe188944d752f9717c7bca12c04b5c625e5da58da814d84cf8282e569', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 14:00:08', '2020-04-16 11:53:53'),
(686, 58, '6709bb3c4649e35783d71b7895e9184d06af83da', 'e9a0c80c90c1f8d96b1301a78177b8e108ed5a1e3943ed73ad1d637d7c67ce6b', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-16 18:18:54', 'user action', '2020-04-16 18:14:19', '2020-04-16 12:00:22'),
(687, 2, '16bbf49ec98af7559e8f13afab2e309c7d8b25c8', 'bec9a5f3a53c7c5d9d83f84f91088255d63b377dc157ea56b808da30854ff430', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 15:58:45', '2020-04-16 12:54:17'),
(688, 58, '0f43c23edf5bcca216bf95bee81ec31cd274ef76', 'cfff8161bdf437dde6a0aa7087d6a8fefff52efbb44c72cf13c994a525397972', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 15:45:22', '2020-04-16 13:38:05'),
(689, 2, '688579679df27181973706225ea5030daf3f3f59', '4e0d651e4c3e122ed1c73bb922f36a8366df5b7e913f792f1cd26f6fbc344710', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 16:20:41', '2020-04-16 14:20:41'),
(690, 2, 'faa6e0b67a49c407f4ce69caa050e6580ef90a46', 'c55585de65a7f3f0836c3829b8a9dabd95b13e87c7a85319af53c8d57ab3006a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-16 16:35:37', '2020-04-16 14:35:14'),
(691, 2, '8db8ddfc954bc617c4492497ea560647a618b6ae', '93c7582a73b69847aadb99e783664ff628203a2f07301c3187739fd1d2eaf50b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-17 00:04:42', '2020-04-16 20:58:05'),
(692, 48, '5f9f0ae03f95817b7c14d6fed692fd5bbf1673da', '3584957b9ff87dc23164fd9c2dfca2b0ff0a8e0654cf747f28ba91e6ebb00fb8', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-17 11:59:41', '2020-04-17 06:32:29'),
(693, 94, '845ceb030f2f8874f004af19d88f3175090c9d63', '20276eddd324760848251e5f1c29983df60967c898e92394f888d381d6fad401', '213.233.84.143', 'Mozilla/5.0 (Linux; Android 9; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36', NULL, NULL, '2020-04-17 09:25:29', '2020-04-17 07:25:21'),
(694, 2, '4f20cb02b29da9852ec407a36695842cbefa3533', 'ab97826fc5932511c08b5b14561421e0cf781512676c36c04554161f5e8f87e3', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-17 09:45:55', '2020-04-17 07:41:53'),
(695, 2, 'e0c89848749e408f1e2f322b777a5b42a6e28043', '0ef8e7bb5ee95fb05863e9eadc27d60d7a95ba61f62c477126fc181601fdd540', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-17 11:52:28', '2020-04-17 08:33:34'),
(696, 2, '2896d17ec198979018089f96e18694620b291767', '05422479f7fc4e1ddad600d8e47bd4619c98405ba8fbdc21f94c5653f1e42f69', '46.243.29.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-17 12:39:06', '2020-04-17 10:35:51'),
(697, 58, 'a832cc4822cd376f8ab3904dc1a8ab710805b1ca', 'c88ef20794d1e763cf62e232d941a38625fb4ed279416d8681bb08e7af3690fa', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-17 13:42:53', '2020-04-17 11:42:46'),
(698, 48, '926d14938ee08259478b3f9e2af57104e8f4756c', '32fc469a877ce6d7734219812fcef690ebcc72c0d4724352ff3c407d7290a915', '217.123.217.215', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-17 15:24:07', '2020-04-17 13:24:07'),
(699, 2, 'f3cf34529ac9eb6f235c56b2c3f9c3bf6728444f', '0c9f26446f0d20dafbdaf669b99be80b78bb2df46839a697f8820ae734119ce6', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-17 15:29:09', '2020-04-17 13:27:25'),
(700, 47, '2d2b551d0b19adee6604e9cb8c1d656838051d4e', '63e4a022220a8e4e7892148d11ce4049d91d95111ff7aa6709fe259d536e896c', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', '2020-04-18 15:24:05', 'user action', '2020-04-18 15:23:46', '2020-04-18 13:23:35'),
(701, 58, '3fb7527866624bfc1f3f7c964233e4d8941c915b', 'ac9e118f656295c952f8d0b3c7e57aa02b75cb1e7f7c513ec5efc82d9c3dd132', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-20 10:57:57', 'user action', '2020-04-20 10:55:44', '2020-04-20 07:21:29'),
(702, 58, '31d6b254c829f4951c4f24c56f45b7f01c325e1d', '2f714ca48f09e1c52406a8fd1bce7c12c45d204c730320723dcf7884d7a0a9e7', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-20 09:23:36', '2020-04-20 07:22:05'),
(703, 48, '75009cd63fe95083e5caab95f499d541c213f0f2', '87dbcad0918f3eb037826a468232a73f4c65303d1f9f35addad4b1d8b748d5fa', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-20 10:43:14', '2020-04-20 07:25:51'),
(704, 2, '3cd72acf5ae1f15bedb559c8bc3628bd4c4db247', 'b0836c271cee9596587adb82bca4a5426cc2a228b1c48085233d6a665e058374', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-20 10:29:32', '2020-04-20 08:21:30'),
(705, 2, '43af5cd63e379bf6d533c589878a704ab44b007d', 'f302fb57abd49d87c6bfcf8c7a62d3035720ace6a7af01d238c9586a5722d35f', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-20 11:26:26', '2020-04-20 09:23:25'),
(706, 73, 'e0113a6b73f8a0e1d6be4763eb0418706725f99c', '00d9dc4c321e85f579232855b85a6b6ed3e91e69fad1b7b39c72a2e82af01c56', '77.163.222.97', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-20 12:37:51', 'user action', '2020-04-20 12:37:33', '2020-04-20 10:33:30'),
(707, 48, '4e3558e36ed16aef20af64bef934091af25d0a0e', '9da0b123b8264d5bb82df50af94d1154edd3b21633eec82b9b210f2400f9f072', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-20 13:40:29', '2020-04-20 11:36:32'),
(708, 58, 'c382c60fbe6634d02659575a6ec3ac6bc53b38f1', 'c9526bef6db6b6a90a0f1171851323a67a790193545205900dd33e22485144fc', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-20 17:07:57', 'user action', '2020-04-20 16:37:03', '2020-04-20 14:00:34'),
(709, 58, '0161386357c6678c00cbf83480821133d47403ef', 'bf27a0e26a44f7b4215f053c3ebab4ff08dad9c3b591c5437c6b587b2e97bcbf', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 08:33:44', 'user action', '2020-04-21 08:33:34', '2020-04-21 06:33:19'),
(710, 2, '2b95c033ac47745302aa5471008ff7180ac24bc8', '79a46226afd304423da5224774e2bd9f792c964a4ea836d9fd241af36c86282d', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 12:39:19', '2020-04-21 07:00:07'),
(711, 58, '8bb8b25c8d7d42ee97f96db6edb5b7d1f6fec0d1', '8f53d7c1e42b1a5de131ab29a47b4f684d180dd73a2571a1e926e804794862a4', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 11:13:16', '2020-04-21 07:30:05'),
(712, 48, '257b013fc116f78fe7b77ab3497e382e30330c5e', '4fa2e765f0c6bc2def1c3d20e228deb6b477a534bddec524e836845c9d24343d', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 11:02:39', '2020-04-21 08:05:10'),
(713, 58, '4577354425fdf1b55889a2ebf837f7925a87a35c', 'b16d7bfcad98bd33642e30bc7b97df80516da19272ad78b5f8b8994f28b7fac7', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 11:04:52', 'user action', '2020-04-21 11:03:17', '2020-04-21 08:47:04'),
(714, 48, '2f92ac884b92a1131b02186a38733e7174c5c57b', 'aa46fff9081f661c6a79d89327530ef7f5bba319cb771d0b323353f5e38caaf6', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 11:03:00', '2020-04-21 09:02:48'),
(715, 48, 'b88a426e395b7f2302362b9d33e08f87c0c3eeeb', '1e621bd2461a7c9a73601e7d6d0ee6bea84b24c1a25e99f2b7c68970936a5fb2', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 11:08:13', '2020-04-21 09:04:05'),
(716, 58, 'fb0a654a5959be7cf2527992904ed87192e9eeee', 'ea0d2729f27dee29a7d8ded6bbb26b6b0c3ce158d8cade8398fcdb2ea8ecf545', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 11:07:20', 'user action', '2020-04-21 11:07:14', '2020-04-21 09:07:09'),
(717, 58, '9f6bedd230be0b485d43cd88f73ff62c30806857', '191200bfb599c33a17679fcebdb231c1552c5b79c2155d59407715ec916fe308', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 11:07:41', 'user action', '2020-04-21 11:07:39', '2020-04-21 09:07:24'),
(718, 48, '4c0fb4028ece750ab25b425ff575f692e0becd2b', 'aec0924d23ddb4e941070f3e010c153d96f8706b357417a31d5494cc9f1b11e3', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 15:26:10', '2020-04-21 10:38:59'),
(719, 2, 'c12d12a6074fc1ef38990d1e133f3b0230625d25', '7dbbeb5c4c7525ad8d1de47025dd4b56e82a44a532a8dc0c0ae96ff2a48ba65a', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 12:53:33', '2020-04-21 10:50:54'),
(720, 2, 'd2a9840a4784cb3f1ce7a1e2e4e07b6160f7da51', 'a8a20a85a403e400adddeda508b2dc95a3d8a92a6a5cfa5e902bee6ea718f431', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 13:14:33', '2020-04-21 11:14:32'),
(721, 2, '620084eb2f098703e6d93f86430c2c79218a4430', '67dc89cabe76f3e0dc270299f65d1274ff1b72a3eba368b8949a650afe4be69f', '62.140.137.42', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36', NULL, NULL, '2020-04-21 13:25:06', '2020-04-21 11:24:38'),
(722, 58, '910da31dd7fcf4bc5c279ea3fea6772a612869fa', '7c6050d310df1b51a4159fd86e58f5e117ebd245374e0688eed626d06f6b1675', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 13:44:55', 'user action', '2020-04-21 13:33:56', '2020-04-21 11:31:05'),
(723, 49, '8005c42d3752b47c3025acbf94ba25177371938f', 'cfd136661f3663869dad1893b5e6818d15f9aa0d76dd2913d56a08a290ce7626', '62.131.11.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-21 14:55:30', 'user action', '2020-04-21 14:55:27', '2020-04-21 12:48:22'),
(724, 2, '058a912f8d451ab22a3aab32a3666c1408bf3c9f', 'ffd631886cc69a838b69311d3e952dc39f8825c9c6b29532f616f5556dde8d6e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 15:33:08', '2020-04-21 13:14:47'),
(725, 2, 'a7e32cb27d88bad1b5fb98e2c67b1812710e9653', 'eeaafdccdfb87d056709dee2f2c2ed7e25ec23674f03eaea7580900604738209', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-21 15:43:10', '2020-04-21 13:35:40'),
(726, 47, 'f129d20250bd689ba6194c8ec0ff773cd19cc082', '57fd5ab71411c0ff7addeb467a8d7ec2605995b7d6c75b07933114f93a732087', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', '2020-04-21 18:31:36', 'user action', '2020-04-21 18:31:29', '2020-04-21 16:31:29'),
(727, 58, '9a1c51ed6ce20d1f77b9ff27548374abca63d83a', 'acdea5d773ad4c1473f9f9a5220000f8b5f40ec989d9fecf8764316087af5484', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-22 09:17:19', '2020-04-22 07:06:18'),
(728, 58, 'e445a91881a115a9c1f06afe9aabd147feacf020', '4c611f91ec120434cc76cc9d1740272355589c74247fd18e2a82601efc096f30', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '2020-04-22 10:19:29', 'user action', '2020-04-22 10:19:25', '2020-04-22 07:19:21'),
(729, 48, 'bd97e0324edac1428182c9e36ff64d15c5748b3e', '54e106df4f0d3708484f6a436341034d082fca0b6a0dfbf2f30537d9713d900f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-22 09:32:22', '2020-04-22 07:24:20'),
(730, 48, 'ca7c407e768d6695b58dbf6d9aea2b505818b1e3', 'dbd3cdbff5811a3cc7fa63d8e79ed250a05b4ae3ada33235b38ceb98fa01824e', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-22 09:40:45', '2020-04-22 07:39:22'),
(731, 2, '13f2c1b75c78744ef0804108603ccef120854692', '6d0faecbec8e00b11928adf07d9c106e41aa0ef91844614b8475163046858814', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-22 11:53:43', '2020-04-22 07:40:44'),
(732, 48, 'abc5776bae5e9bdfa98428f47135915fff35804e', 'dc064458a1525ab44b128e751379b6de3e49812f5a7f293043b3bdfed9945aad', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-22 10:30:40', '2020-04-22 08:27:50'),
(733, 2, '8d5d3f575bae65d6346b9b050d4a9c513e5d9f1b', '9d0fa179d7ffa647c26ebe74e656d82a8e29254e6d91c5a85ad6f6989b78fcbd', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-22 12:42:14', '2020-04-22 10:36:29'),
(734, 2, '247a8394ea0d24343aa4e21db5203895347f4d2c', 'fe4da5e7b6a2b6f6e64e3a7462c7f3beb430f2cbf60bc3a65478581c9b27c2a1', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 10:56:07', '2020-04-23 06:05:19'),
(735, 2, 'fee9e40fdcef1a2f0e27544973e13daf4734bfb0', 'f3e74b46b20dbc265a21effb9e74ae51097e9a29de2780ea9db166d56345fcae', '82.74.254.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 09:53:12', '2020-04-23 07:08:02'),
(736, 58, 'd3872ae4d583f539daf49743f4f4d880fdd4f1a7', 'a818ff38e28e52bed003cfb30f6c43bbe98ef57b75ae50659796d76eb9433910', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', '2020-04-23 09:51:57', 'user action', '2020-04-23 09:51:52', '2020-04-23 07:11:42'),
(737, 48, 'bb5fc6bbf49d1f33ba03d8632c0ade0b1bd21f2e', 'b17c98cc86c46d7b79c00431e87c3ecda9454d333ffded13f4ddfbce19ec63f5', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 10:47:07', '2020-04-23 08:39:45'),
(738, 48, '29d4fb7f290f54f239c6ce0ee38887730cb604ca', '791010bbd7435f0138d68d42d5ab96fcfe0d3d59d3591bff27e23e22b223126f', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 11:03:14', '2020-04-23 08:53:38'),
(739, 2, '4a8731d07dfa48bd8bb74e9fc6e779eb32535d3c', 'c77955b201eefc3d6313c97bdf332a63a46ea1bc837fe660a7980bc6b3fa994b', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 11:02:26', '2020-04-23 09:02:08'),
(740, 58, '2124d8c842a3a33ae14ed0184fa8c4c4174da153', 'fb50ceccd27d3d7bec5b2be3e9e2e38093888be6424b286f277bfc35f6d96f3d', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-23 12:44:46', '2020-04-23 09:18:22'),
(741, 94, '8c6391e10c2ed1e6271e4ced289a94e15742db14', 'f1255d5c41bfb927d3427aaf03b42ebed4e01ee5391113cef8caec47efe7f145', '213.233.84.189', 'Mozilla/5.0 (Linux; Android 9; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36', NULL, NULL, '2020-04-23 13:57:51', '2020-04-23 11:55:50'),
(742, 49, 'f8ba99fd78321c8bf3e0d7052c758a44f64c7f9e', 'c497a9a9ebecbc94f06439834368574f75674e2ecb5c9cb985e74bcbbf21ae20', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', NULL, NULL, '2020-04-23 16:02:07', '2020-04-23 13:10:59'),
(743, 58, '02188640e7ec41526486cc182cc3eef0eac78d9e', '4cc1c4a8376ef17154643bd4273608c41626b55aff2361b10c8790641b54442a', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', '2020-04-23 16:22:35', 'user action', '2020-04-23 16:22:30', '2020-04-23 13:54:11'),
(744, 2, 'dee189d7e4b6d74db35fc84de4216e6931a68764', '2092c8e9eeae59929617415d9312aabe899f190a550952962bd994b2f8161c77', '62.140.137.42', 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36', NULL, NULL, '2020-04-23 15:54:36', '2020-04-23 13:54:28'),
(745, 2, '1c00a0255609d0f49cc5a6d2b8d41efc58fb712a', 'ae76b254489fdce7587c5d7a0fd42f7a82b6d4c2de69f61281ced71694a68d51', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 16:26:22', '2020-04-23 14:14:08'),
(746, 95, '99a4dc7368e4e254b2f8e555d48ecf66d9e28dbf', '79010658a8fa5c88c14d2b6267fe5c79c88c74ecf352a9953eebf799411cf5d1', '62.194.45.160', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36', NULL, NULL, '2020-04-23 16:29:50', '2020-04-23 14:28:54'),
(747, 48, '0988329a5851d87a876bd695d848266ce05747a6', '6f7f8edaeef979c9e9d6fe96988a8301def093f3c8dcbdd961a0b6139e291552', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-23 16:40:27', '2020-04-23 14:40:07'),
(748, 95, 'fd2b9f9704f4de822869e22094ef7c6c628cb4e2', 'b6c305bf88dd9bc9b10e1c6a144a9fcca77301fb06e27eb9e51ba1560ebf3c92', '109.36.141.134', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.117 Mobile Safari/537.36', NULL, NULL, '2020-04-24 07:08:42', '2020-04-24 05:08:35'),
(749, 2, 'bd4112eb2691464e65784d7e614475c1729d12a4', '62883df024cd555a615872c2b0fd77ed3bb397185fbd82e52c13c37fd7f5ff3e', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-24 09:24:41', '2020-04-24 07:14:45'),
(750, 48, '35d253718044a9b078aca00c42f27e437eda63b7', '129688a8ec494d160b799ec0eacfce850fbe44d1cf85de48e60549d7dc6155de', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-24 11:54:59', '2020-04-24 09:31:49'),
(751, 95, '0634e0745f6832a40b2fd157c1bb417920ccad2a', 'd94e6de909d967294645f2218f5b6c6ace0842cc633d3360dcaf9f29d226fe2d', '109.36.141.134', 'Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.117 Mobile Safari/537.36', NULL, NULL, '2020-04-24 13:37:47', '2020-04-24 11:37:38'),
(752, 2, 'b868d1558106b762fd8e3c8b61aa2b4f319ee920', 'a9b1515cba69ee52e10240033fa3064f0f823b60400adc74dd5a1a8cfcb9d727', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-24 14:02:24', '2020-04-24 12:02:03'),
(753, 82, '1f1aeeced57e4dab2dd3bc2d8deef7943a3de010', '848df683f3a916e7ea559d96f48ed85eafa039539cabbff83401db3a27d58cfc', '86.83.206.22', 'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1', NULL, NULL, '2020-04-24 17:19:35', '2020-04-24 15:19:13'),
(754, 47, '1570d41b50d5062e7a487962e615e5abcb5f7a13', 'e7edcb60f8ec61514d340c2caa0f14d064025a96f830afe85c2fc830e2ea385b', '213.127.58.223', 'Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Safari/537.36', '2020-04-24 18:07:10', 'user action', '2020-04-24 18:06:55', '2020-04-24 16:06:35'),
(755, 81, '0e6585d1a28005b8b3b910b0eb7cde4fb9cf68b4', 'bb374a34500ff15738efdb7dd28942eb5e8b58bf1385aa9238ccbaed95bb8e9b', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-25 09:54:27', '2020-04-25 07:54:27'),
(756, 81, '0362d92335ceefcaf92e17dca064da0e0c24e14b', '5241fa98ab471f145d24944d5eb5c55c414e7511f613f063a5cca176bb3493c1', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-25 09:56:38', '2020-04-25 07:56:12'),
(757, 81, 'ba8e84fa2fd596184587ccfd2fcebb35f68fbaf8', 'f9b7caaac0f5e19c06635aca6e341ae9ec3731a6fd1cf60b44ce9ade9553deb9', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-25 10:00:06', '2020-04-25 07:59:25'),
(758, 81, '345dab6a151666ad77e1b93a3b6e372ef5ae455a', 'b2cf5c981f2fd3515d0c29d76ffea418b20dde2ea1d743571d8101d4b84875ea', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-25 10:01:36', '2020-04-25 08:01:36'),
(759, 81, '8ac9b39439a68c5f9669a9e68b6182e955130b15', 'dc5312d37d9bdbefd5ce07483e803f1fe289bc7d7405e6ba82b67d3e557df2c8', '62.194.115.222', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-25 15:51:39', '2020-04-25 13:51:05'),
(760, 58, '29ba1e7cff735f74b629366dc2edbc46facd396f', 'e742282d7f5a9f771b12c14a17c90a5bed432867a42dc3f9bacbf52e8903f95a', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-28 09:04:27', '2020-04-28 07:03:04'),
(761, 58, '82ed9f224df94c3bc3307218ca308f6f8d05e225', '3ac34de1ebe23081380b8855726f87246f6910375f5189c459981f8debfd20de', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 14:40:12', '2020-04-28 07:22:50'),
(762, 58, '742c09d039e5d93f4619c020bdf46cf6d9847d8a', 'd03b4b6b849a7ed02adbf54150046f198b94aa782b551491b82d10e78df753d9', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-28 10:03:02', '2020-04-28 07:57:51'),
(763, 48, '5189595993880e8a44734ba3905572d1465d4cbc', '469b8904ae43b7935ed8646c14945c85c09a929be3fbe57331d10bfbef5856d5', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 12:41:24', '2020-04-28 08:22:06'),
(764, 58, '3994f655b58be8fd8e2dec5e7dc78454afdf033d', 'b2f03bb9037cf6e58304c6877160261daec4e2cde60e103cbf1d81d3d3e32178', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', NULL, NULL, '2020-04-28 10:45:08', '2020-04-28 08:24:44'),
(765, 2, '22984b10fdd1b154b16999b45f1be758c56926c7', 'a2b9166e5e7f35c9a95f9ad8bfbca657a7ade5a061f5fa7712be2264e8fc15d4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 12:25:13', '2020-04-28 08:45:55'),
(766, 58, 'd0313025ef86259cbf8d1f66d81d83eaa2609804', 'e321b7e08271ba060fe2cd243b23d0e255d53303d2ded3312a8c38afbacccc52', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36', '2020-04-28 14:41:18', 'user action', '2020-04-28 14:23:08', '2020-04-28 11:19:58'),
(767, 2, '9d40ccf0fbfedb7f76a1b8cece7398e07259dd7f', 'dfe90939b2dd062c35a878e6944813ab93bb8f5f92e984bde9e8870e79204655', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 14:45:29', '2020-04-28 12:45:01'),
(768, 103, '5b345f25f81d3c487610a5f9e7ea070c2076592e', 'd5b0065c410fbc2904221b05057802cc61b32b64e881ad3750427f2f0fc2dcd6', '31.149.79.170', 'Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', NULL, NULL, '2020-04-28 15:38:54', '2020-04-28 13:38:30'),
(769, 103, 'ecc2b1824cd38e7aa0dc08143a569a94020bd674', '8f7ba3faa0c8b1461d8b28e093b0b405c0102d07115bf2c203fa7ae8ed73afd3', '31.149.79.170', 'Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36', '2020-04-28 15:41:34', 'sign', '2020-04-28 15:41:34', '2020-04-28 13:40:01'),
(770, 48, '2398c81ddca914de5f81bf9b9de73cfd76b90604', '679d3cb0761eca7f3b2e13375e7a1e841f793eed7074675dbe079f2337f6ed80', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 16:09:16', '2020-04-28 13:42:03'),
(771, 2, '0053eab1abb04956f39c8c264a5db13522512c27', 'a46e7ef2a59b088f575b2342b355e12c781f13a381ad2b361d3d831164f6cf7c', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-28 16:27:59', '2020-04-28 13:55:40'),
(772, 49, 'b774955ac4beab13650cd9e400df8a3337f92d04', 'e0184d0ebe8859f14c45e1634b7ca4b61638643dbff038f0951c4c886c4ca4ea', '213.93.151.227', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36', '2020-04-28 18:38:51', 'user action', '2020-04-28 18:38:47', '2020-04-28 16:33:00'),
(773, 2, 'd46840788a49366ea82d1e11546c5bd396a26c4c', 'c5bf25ed42cefc544ed2d8e57d1833f521e7f0bb0359cb968106360a312d8ad4', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36', NULL, NULL, '2020-04-29 09:16:14', '2020-04-29 07:15:13'),
(774, 2, '9995de9976a864eae45610ab7d8a9f818bc0c3e9', '86668b7328498173d9d2c27ba49a13ae00776e07ff7e44f64b6f02d5bf5dcfe5', '82.74.254.28', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36', NULL, NULL, '2020-04-29 10:44:10', '2020-04-29 07:17:23'),
(775, 58, '9f05b097143219bd4142a41aa5238376997b1496', '3491f3f9cc4f2befff45a799acdd4e98c5a92f4fa1ea0983084fd4b1d2c71773', '77.60.175.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-29 10:41:14', '2020-04-29 07:23:19'),
(776, 48, '55db5abb9cdbc0e075fb0866781cd07164188a74', '548b1492cbb242fc5f2949a95630ab7c15173d83a95242a8fc116d3e368a04cd', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-29 10:44:32', '2020-04-29 07:32:00');
INSERT INTO `users_sessions` (`id`, `user_id`, `sid`, `secret`, `ip`, `browser`, `session_logout`, `session_logout_reason`, `session_last_action`, `session_start`) VALUES
(777, 58, '321444375d4f0d8a159f4ad6e02daaf43bf25524', '1492d1e943ada59bb6e4cad06d01831083b486c9450715e154992e3e405c82b9', '109.205.192.200', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', '2020-04-29 11:08:09', 'user action', '2020-04-29 10:40:09', '2020-04-29 07:55:14'),
(778, 48, 'cde1ed89336f55dd97a62f383726c497e76464a5', '7bc9f8cf9703efeeb14ae6dbb8f7424cfeab686887c6397701e263b45fde0ffd', '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', NULL, NULL, '2020-04-29 10:56:56', '2020-04-29 08:49:50');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkgevers`
--

CREATE TABLE `werkgevers` (
  `werkgever_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('uitzenden','bemiddeling','','') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'uitzenden',
  `wid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wg_hash` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_user` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_password` varbinary(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `werkgevers`
--

INSERT INTO `werkgevers` (`werkgever_id`, `name`, `type`, `wid`, `wg_hash`, `db_name`, `db_user`, `db_password`) VALUES
(1, 'Abering Uitzenden', 'uitzenden', 'wid3', '12hash34', 'app_user', 'app_user', 0xa10ea314a0fb2999cfd977c53f5e9a30),
(2, 'Abering Bemiddeling', 'bemiddeling', 'wid4', 'dasj85dasy', 'app_user_002', 'app_user_002', 0x5e391c81630f4d3a91f9af5708ac71e8),
(3, 'Abering *Demo* Uitzenden', 'uitzenden', 'wid5', 'fds9lds2as1n', 'app_demo', 'app_demo', 0x7287f4d54d4312c2119958323e1f0808),
(4, 'Abering *Demo* Bemiddeling', 'bemiddeling', 'wid6', 'dajds456t41nm', 'app_demo_bemiddeling', 'app_demo_b', 0x128f04c2d355fc6d73fc2d4ed30b4323);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexen voor tabel `emails_attachments`
--
ALTER TABLE `emails_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `emails_log`
--
ALTER TABLE `emails_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `list_burgelijkestaat`
--
ALTER TABLE `list_burgelijkestaat`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `list_landen`
--
ALTER TABLE `list_landen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `list_nationaliteiten`
--
ALTER TABLE `list_nationaliteiten`
  ADD PRIMARY KEY (`code`);

--
-- Indexen voor tabel `list_soort_id`
--
ALTER TABLE `list_soort_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `login_blacklist_ip`
--
ALTER TABLE `login_blacklist_ip`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexen voor tabel `users_accounts`
--
ALTER TABLE `users_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_link_werkgever_id` (`werkgever_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_id_2` (`user_id`);

--
-- Indexen voor tabel `users_sessions`
--
ALTER TABLE `users_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `werkgevers`
--
ALTER TABLE `werkgevers`
  ADD PRIMARY KEY (`werkgever_id`),
  ADD UNIQUE KEY `wid` (`wid`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `emails`
--
ALTER TABLE `emails`
  MODIFY `email_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT voor een tabel `emails_attachments`
--
ALTER TABLE `emails_attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `emails_log`
--
ALTER TABLE `emails_log`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `list_burgelijkestaat`
--
ALTER TABLE `list_burgelijkestaat`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `list_landen`
--
ALTER TABLE `list_landen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT voor een tabel `list_soort_id`
--
ALTER TABLE `list_soort_id`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT voor een tabel `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT voor een tabel `login_blacklist_ip`
--
ALTER TABLE `login_blacklist_ip`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT voor een tabel `users_accounts`
--
ALTER TABLE `users_accounts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT voor een tabel `users_sessions`
--
ALTER TABLE `users_sessions`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=779;

--
-- AUTO_INCREMENT voor een tabel `werkgevers`
--
ALTER TABLE `werkgevers`
  MODIFY `werkgever_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `users_accounts`
--
ALTER TABLE `users_accounts`
  ADD CONSTRAINT `users_link_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_link_werkgever_id` FOREIGN KEY (`werkgever_id`) REFERENCES `werkgevers` (`werkgever_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `users_sessions`
--
ALTER TABLE `users_sessions`
  ADD CONSTRAINT `users_sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

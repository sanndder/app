
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `documenten_handtekeningen`
--

CREATE TABLE `documenten_handtekeningen` (
  `id` int(11) UNSIGNED NOT NULL,
  `document_id` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `naam` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `handtekening` longblob,
  `ip` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signed_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `documenten_handtekeningen`
--

INSERT INTO `documenten_handtekeningen` (`id`, `document_id`, `user_id`, `werknemer_id`, `zzp_id`, `inlener_id`, `uitzender_id`, `naam`, `handtekening`, `ip`, `signed_on`) VALUES
(3, 3, 55, NULL, NULL, NULL, 103, 'Jürgen  Hoffmann', NULL, '77.168.28.99', '2020-01-09 12:31:57'),
(4, 4, NULL, NULL, NULL, NULL, 104, NULL, NULL, NULL, NULL),
(5, 5, 61, NULL, NULL, NULL, 104, 'Stephen  Bart', NULL, '62.145.37.18', '2020-01-30 13:34:47'),
(6, 6, 48, NULL, NULL, NULL, 105, 'Moonier  Zarouali  4You', NULL, '84.31.244.50', '2020-02-12 13:45:54'),
(7, 7, 62, NULL, NULL, 3007, NULL, 'Raimond de Jong', NULL, '185.210.131.47', '2020-02-20 13:24:41'),
(8, 8, 70, NULL, NULL, 3008, NULL, 'Jan van Hamond', NULL, '212.83.227.41', '2020-02-20 13:49:59');

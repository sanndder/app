
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkgever_logo`
--

CREATE TABLE `werkgever_logo` (
  `id` int(11) UNSIGNED NOT NULL,
  `entiteit_id` int(11) UNSIGNED DEFAULT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name_display` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `werkgever_logo`
--

INSERT INTO `werkgever_logo` (`id`, `entiteit_id`, `file_dir`, `file_name`, `file_name_display`, `file_size`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(6, 1, 'werkgever/logo', 'logo_0481392001575907276_ftw3EDiN.png', NULL, 74812, 2, NULL, 1, 2, '2019-12-17 15:13:50'),
(7, 1, 'werkgever/logo', 'logo_0892264001576595640_8jBE7AaU.png', NULL, 74812, 2, NULL, 1, 2, '2020-01-07 14:30:22'),
(8, 1, 'werkgever/logo', 'logo_0808039001578403835_QBVuwnC7.png', NULL, 80611, 2, NULL, 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_projecten`
--

CREATE TABLE `inleners_projecten` (
  `id` int(11) UNSIGNED NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `omschrijving` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_uitzenders`
--

CREATE TABLE `zzp_uitzenders` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_uitzenders`
--

INSERT INTO `zzp_uitzenders` (`id`, `zzp_id`, `uitzender_id`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 105, 48, '2020-02-18 10:56:44', 0, NULL, NULL),
(2, 2, 105, 2, '2020-02-20 07:38:45', 0, NULL, NULL),
(3, 8003, 105, 2, '2020-03-04 12:39:30', 0, NULL, NULL);

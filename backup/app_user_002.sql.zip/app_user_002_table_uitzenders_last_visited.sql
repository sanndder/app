
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_last_visited`
--

CREATE TABLE `uitzenders_last_visited` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_last_visited`
--

INSERT INTO `uitzenders_last_visited` (`id`, `user_id`, `uitzender_id`, `timestamp`) VALUES
(136, 2, 0, '2020-01-07 15:51:35'),
(199, 0, 103, '2020-01-08 11:18:22'),
(202, 2, 101, '2020-01-08 13:15:22'),
(214, 0, 0, '2020-01-09 10:18:07'),
(249, 48, 103, '2020-02-06 09:23:04'),
(250, 2, 103, '2020-02-06 09:23:05'),
(264, 49, 105, '2020-02-20 09:43:35'),
(292, 48, 105, '2020-02-27 09:47:07'),
(315, 2, 104, '2020-03-10 10:27:51'),
(317, 48, 104, '2020-03-10 11:43:38'),
(326, 2, 105, '2020-03-11 12:03:52');

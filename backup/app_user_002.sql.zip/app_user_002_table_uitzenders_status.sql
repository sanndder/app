
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_status`
--

CREATE TABLE `uitzenders_status` (
  `uitzender_id` int(11) UNSIGNED NOT NULL,
  `archief` tinyint(1) NOT NULL DEFAULT '0',
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `bedrijfsgegevens_complete` tinyint(1) DEFAULT NULL,
  `factuurgegevens_complete` tinyint(1) DEFAULT NULL,
  `contactpersoon_complete` tinyint(1) DEFAULT NULL,
  `emailadressen_complete` tinyint(1) DEFAULT NULL,
  `ip` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_update_by` int(11) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_status`
--

INSERT INTO `uitzenders_status` (`uitzender_id`, `archief`, `complete`, `bedrijfsgegevens_complete`, `factuurgegevens_complete`, `contactpersoon_complete`, `emailadressen_complete`, `ip`, `last_update_by`, `last_update`) VALUES
(103, 1, 1, 1, 1, 1, 1, '77.168.28.99', 48, '2020-02-06 09:23:04'),
(104, 1, 1, 1, 1, 1, 1, '77.250.126.248', 48, '2020-03-10 11:43:38'),
(105, 0, 1, 1, 1, 1, 1, '46.243.29.50', NULL, '2020-01-06 10:45:46');

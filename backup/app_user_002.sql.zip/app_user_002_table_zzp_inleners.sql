
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_inleners`
--

CREATE TABLE `zzp_inleners` (
  `plaatsing_id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `start_plaatsing` date DEFAULT NULL,
  `einde_plaatsing` date DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_inleners`
--

INSERT INTO `zzp_inleners` (`plaatsing_id`, `zzp_id`, `inlener_id`, `start_plaatsing`, `einde_plaatsing`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 3007, '2020-02-10', NULL, NULL, '2020-02-20 07:33:03', 1, 2, '2020-02-20 08:35:00'),
(2, 1, 3007, '2020-02-10', NULL, NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(3, 2, 3008, '2020-02-10', NULL, NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(4, 8003, 3008, '2020-03-02', NULL, NULL, '2020-03-04 12:43:00', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_last_visited`
--

CREATE TABLE `inleners_last_visited` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_last_visited`
--

INSERT INTO `inleners_last_visited` (`id`, `user_id`, `inlener_id`, `timestamp`) VALUES
(30, 55, 0, '2020-01-09 12:22:54'),
(54, 2, 3003, '2020-02-06 09:02:39'),
(56, 2, 3002, '2020-02-06 09:02:42'),
(70, 2, 3001, '2020-02-06 09:10:50'),
(72, 2, 0, '2020-02-06 09:19:49'),
(73, 48, 0, '2020-02-06 09:20:05'),
(79, 2, 3000, '2020-02-06 09:24:37'),
(80, 2, 3005, '2020-02-06 12:40:26'),
(82, 48, 3000, '2020-02-07 10:33:37'),
(105, 48, 3006, '2020-02-13 09:40:17'),
(133, 48, 3008, '2020-02-20 11:32:29'),
(147, 2, 3007, '2020-02-20 12:25:10'),
(149, 48, 3007, '2020-02-20 12:27:31'),
(155, 2, 3008, '2020-02-20 12:51:36'),
(158, 2, 3006, '2020-02-20 12:58:26'),
(164, 49, 3007, '2020-03-04 10:51:43'),
(165, 49, 3008, '2020-03-04 13:03:35');

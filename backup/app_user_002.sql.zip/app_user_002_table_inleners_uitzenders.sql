
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_uitzenders`
--

CREATE TABLE `inleners_uitzenders` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_uitzenders`
--

INSERT INTO `inleners_uitzenders` (`id`, `inlener_id`, `uitzender_id`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3000, 103, 2, '2020-01-08 14:38:00', 0, NULL, NULL),
(7, 3006, 104, 48, '2020-02-06 09:20:05', 0, NULL, NULL),
(8, 3007, 105, 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(9, 3008, 105, 48, '2020-02-20 07:52:32', 0, NULL, NULL);

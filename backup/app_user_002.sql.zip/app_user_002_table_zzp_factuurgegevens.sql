
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_factuurgegevens`
--

CREATE TABLE `zzp_factuurgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tav` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `factuur_emailen` tinyint(1) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_factuurgegevens`
--

INSERT INTO `zzp_factuurgegevens` (`id`, `zzp_id`, `iban`, `tav`, `factuur_emailen`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 'NL32INGB0007694163', 'El Maki', 1, 48, '2020-02-18 11:08:47', 0, NULL, NULL),
(2, 2, 'NL19INGB0008790691', 'Ouaaa Sloop', 1, 2, '2020-02-20 07:51:30', 0, NULL, NULL),
(3, 8003, 'NL95INGB0007729113', 'E.S.W. Sloop & Schoonmaak', 1, 2, '2020-03-04 12:42:48', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemer_et_inhouding_huisvesting`
--

CREATE TABLE `werknemer_et_inhouding_huisvesting` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `inhouden_huisvesting` tinyint(1) NOT NULL DEFAULT '0',
  `bedrag` decimal(6,2) DEFAULT NULL,
  `document_id` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

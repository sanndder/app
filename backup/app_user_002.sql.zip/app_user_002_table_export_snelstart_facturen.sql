
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `export_snelstart_facturen`
--

CREATE TABLE `export_snelstart_facturen` (
  `id` int(11) UNSIGNED DEFAULT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_av_accepted`
--

CREATE TABLE `uitzenders_av_accepted` (
  `id` int(11) NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `av_id` int(11) UNSIGNED DEFAULT NULL,
  `accepted_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted_by` int(11) DEFAULT NULL,
  `accepted_ip` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted_device` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_av_accepted`
--

INSERT INTO `uitzenders_av_accepted` (`id`, `uitzender_id`, `av_id`, `accepted_on`, `accepted_by`, `accepted_ip`, `accepted_device`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(2, 103, 28, '2020-01-09 10:48:22', 55, '77.168.28.99', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763', 0, NULL, NULL),
(3, 104, 28, '2020-02-03 11:51:21', 61, '62.145.37.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 0, NULL, NULL),
(4, 105, 28, '2020-02-12 12:44:54', 48, '84.31.244.50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 0, NULL, NULL);

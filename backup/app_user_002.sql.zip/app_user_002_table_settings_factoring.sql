
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings_factoring`
--

CREATE TABLE `settings_factoring` (
  `id` int(11) UNSIGNED NOT NULL,
  `iban` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cessie_tekst` text COLLATE utf8_unicode_ci,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `settings_factoring`
--

INSERT INTO `settings_factoring` (`id`, `iban`, `cessie_tekst`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'NL14 INGB 0007 8661 77 ', 'Abering Uitzend B.V. maakt gebruik van factoring. In verband hiermee hebben wij conform art. 3:94 BW onze huidige en toekomstige vorderingen, waaronder deze, (bij voorbaat) gecedeerd aan Factris NL1 B.V., te Amsterdam. Mitsdien kan rechtsgeldige en bevrijdende betaling van de vordering zoals aangeduid op deze factuur en onze toekomstige vorderingen uitsluitend binnen de op de factuur vermelde betalingstermijn plaatsvinden door betaling op rekening (IBAN) NL14 INGB 0007 8661 77 ten name van Factris NL1 B.V. te Amsterdam, behoudens indien Factris u andersluidend heeft bericht. Indien op deze factuur een G-gedeelte vermeld staat, dient u dit gedeelte echter over te maken naar het bij u bekende G-rekeningnummer.', 2, '2020-02-17 12:45:54', 0, NULL, NULL);

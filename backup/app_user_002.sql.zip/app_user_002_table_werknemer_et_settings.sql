
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemer_et_settings`
--

CREATE TABLE `werknemer_et_settings` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `uitruilen_huisvesting` tinyint(1) NOT NULL DEFAULT '1',
  `uitruilen_levensonderhoud` tinyint(1) NOT NULL DEFAULT '1',
  `uitruilen_reiskosten` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

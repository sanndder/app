
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `urentypes_categorien`
--

CREATE TABLE `urentypes_categorien` (
  `urentype_categorie_id` int(11) UNSIGNED NOT NULL,
  `naam` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `factor` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `urentypes_categorien`
--

INSERT INTO `urentypes_categorien` (`urentype_categorie_id`, `naam`, `label`, `factor`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'uren', 'uren', NULL, NULL, '2019-09-25 12:19:36', 0, NULL, NULL),
(2, 'overuren', 'overuren/toeslag', NULL, NULL, '2019-09-25 12:21:32', 0, NULL, NULL),
(3, 'reisuren', 'reisuren', NULL, NULL, '2019-09-25 12:21:32', 0, NULL, NULL);

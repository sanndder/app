
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_av_accepted`
--

CREATE TABLE `inleners_av_accepted` (
  `id` int(11) NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `av_id` int(11) UNSIGNED DEFAULT NULL,
  `accepted_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted_by` int(11) DEFAULT NULL,
  `accepted_ip` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted_device` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_av_accepted`
--

INSERT INTO `inleners_av_accepted` (`id`, `inlener_id`, `av_id`, `accepted_on`, `accepted_by`, `accepted_ip`, `accepted_device`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3007, 28, '2020-02-20 12:24:23', 62, '185.210.131.47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 0, NULL, NULL),
(2, 3008, 28, '2020-02-20 12:49:38', 70, '212.83.227.41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 0, NULL, NULL);

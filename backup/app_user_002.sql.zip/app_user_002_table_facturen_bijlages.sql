
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `facturen_bijlages`
--

CREATE TABLE `facturen_bijlages` (
  `id` int(11) UNSIGNED NOT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `invoer_bijlage_id` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

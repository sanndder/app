
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_vergoedingen`
--

CREATE TABLE `inleners_vergoedingen` (
  `inlener_vergoeding_id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `vergoeding_id` int(11) UNSIGNED DEFAULT NULL,
  `vergoeding_type` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bedrag_per_uur` decimal(4,2) DEFAULT NULL,
  `doorbelasten` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uitkeren_werknemer` tinyint(1) DEFAULT '1',
  `label` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

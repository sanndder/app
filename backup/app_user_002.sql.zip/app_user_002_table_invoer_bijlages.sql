
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_bijlages`
--

CREATE TABLE `invoer_bijlages` (
  `file_id` int(11) UNSIGNED NOT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name_display` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) UNSIGNED DEFAULT NULL,
  `file_ext` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tijdvak` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jaar` mediumint(4) DEFAULT NULL,
  `periode` tinyint(2) DEFAULT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `invoer_bijlages`
--

INSERT INTO `invoer_bijlages` (`file_id`, `file_dir`, `file_name`, `file_name_display`, `file_size`, `file_ext`, `tijdvak`, `jaar`, `periode`, `uitzender_id`, `inlener_id`, `project_id`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'invoer/bijlages', 'bijlage_0384406001582796981_4gWpuAev.pdf', 'MDM week 8.pdf', 142897, 'pdf', 'w', 2020, 8, 105, 3007, NULL, 49, '2020-02-27 09:49:41', 0, NULL, NULL),
(2, 'invoer/bijlages', 'bijlage_0768114001582801943_FTnVrCGt.pdf', 'Horyon week 8.pdf', 278553, 'pdf', 'w', 2020, 8, 105, 3008, NULL, 49, '2020-02-27 11:12:23', 0, NULL, NULL),
(3, 'invoer/bijlages', 'bijlage_0645154001583317378_S2xguh3s.pdf', 'MDM week 9.pdf', 144754, 'pdf', 'w', 2020, 9, 105, 3007, NULL, 49, '2020-03-04 10:22:58', 0, NULL, NULL),
(4, 'invoer/bijlages', 'bijlage_0680890001583327073_Wtk6H74b.pdf', 'Horyon week 9.pdf', 238854, 'pdf', 'w', 2020, 9, 105, 3008, NULL, 49, '2020-03-04 13:04:33', 0, NULL, NULL),
(5, 'invoer/bijlages', 'bijlage_0423388001583843204_YQgSwA5v.pdf', 'Week 10 MDM.pdf', 147969, 'pdf', 'w', 2020, 10, 105, 3007, NULL, 49, '2020-03-10 12:26:44', 0, NULL, NULL),
(6, 'invoer/bijlages', 'bijlage_0104880001583928086_W8nN8SRX.pdf', 'Manurenstaat week 10 2020 .pdf', 244271, 'pdf', 'w', 2020, 10, 105, 3008, NULL, 2, '2020-03-11 12:01:26', 0, NULL, NULL);

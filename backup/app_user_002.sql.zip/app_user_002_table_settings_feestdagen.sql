
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings_feestdagen`
--

CREATE TABLE `settings_feestdagen` (
  `id` int(11) UNSIGNED NOT NULL,
  `jaar` int(4) DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `omschrijving` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

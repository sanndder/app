
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_verloning_instellingen`
--

CREATE TABLE `werknemers_verloning_instellingen` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `et_regeling` tinyint(1) NOT NULL DEFAULT '0',
  `vakantiegeld_direct` tinyint(1) DEFAULT NULL,
  `feestdagen_direct` tinyint(1) NOT NULL DEFAULT '0',
  `kortverzuim_direct` tinyint(1) NOT NULL DEFAULT '0',
  `vakantieuren_wettelijk_direct` tinyint(1) DEFAULT NULL,
  `vakantieuren_bovenwettelijk_direct` tinyint(1) DEFAULT NULL,
  `aantal_vakantiedagen_wettelijk` decimal(4,2) DEFAULT NULL,
  `aantal_vakantiedagen_bovenwettelijk` decimal(4,2) DEFAULT NULL,
  `atv_direct` tinyint(1) DEFAULT NULL,
  `aantal_atv_dagen` decimal(4,2) DEFAULT NULL,
  `inhouden_zorgverzekering` tinyint(1) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

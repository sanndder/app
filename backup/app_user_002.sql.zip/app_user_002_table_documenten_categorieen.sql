
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `documenten_categorieen`
--

CREATE TABLE `documenten_categorieen` (
  `categorie_id` int(11) NOT NULL,
  `categorie` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dir` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `documenten_categorieen`
--

INSERT INTO `documenten_categorieen` (`categorie_id`, `categorie`, `dir`, `deleted`) VALUES
(1, 'bemiddelingsovereenkomst', 'documenten/bemiddelingsovereenkomst', 0),
(2, 'overeenkomst van dienstverlening', 'documenten/overeenkomst_dienstverlening', 0),
(5, 'inleenovereenkomst', 'documenten/inleenovereenkomst', 0),
(6, 'overeenkomst van tussenkomst', 'documenten/overeenkomst_tussenkomst', 0),
(7, 'verklaring inlener', 'verklaring_inlener', 0);

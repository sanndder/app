
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `facturen_log`
--

CREATE TABLE `facturen_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `action` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

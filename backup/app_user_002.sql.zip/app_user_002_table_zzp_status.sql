
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_status`
--

CREATE TABLE `zzp_status` (
  `zzp_id` int(11) UNSIGNED NOT NULL,
  `archief` tinyint(1) NOT NULL DEFAULT '0',
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `bedrijfsgegevens_complete` tinyint(1) DEFAULT NULL,
  `persoonsgegevens_complete` tinyint(1) DEFAULT NULL,
  `documenten_complete` tinyint(1) DEFAULT NULL,
  `factuurgegevens_complete` tinyint(1) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_status`
--

INSERT INTO `zzp_status` (`zzp_id`, `archief`, `complete`, `bedrijfsgegevens_complete`, `persoonsgegevens_complete`, `documenten_complete`, `factuurgegevens_complete`, `last_update`) VALUES
(1, 0, 1, 1, 1, 1, 1, '2020-02-20 07:32:42'),
(2, 0, 1, 1, 1, 1, 1, '2020-02-20 07:51:30'),
(8003, 0, 1, 1, 1, 1, 1, '2020-03-04 12:42:48');

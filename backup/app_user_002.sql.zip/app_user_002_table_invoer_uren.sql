
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_uren`
--

CREATE TABLE `invoer_uren` (
  `invoer_id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `aantal` decimal(5,2) DEFAULT NULL,
  `uren_type_id_werknemer` int(11) UNSIGNED DEFAULT NULL,
  `plaatsing_id` int(11) UNSIGNED DEFAULT NULL,
  `doorbelasten` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uitkeren` tinyint(1) NOT NULL DEFAULT '1',
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `verloning_id` int(11) UNSIGNED DEFAULT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `project_tekst` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opmerking_tekst` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `locatie_tekst` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `invoer_uren`
--

INSERT INTO `invoer_uren` (`invoer_id`, `uitzender_id`, `inlener_id`, `werknemer_id`, `zzp_id`, `datum`, `aantal`, `uren_type_id_werknemer`, `plaatsing_id`, `doorbelasten`, `uitkeren`, `factuur_id`, `verloning_id`, `project_id`, `project_tekst`, `opmerking_tekst`, `locatie_tekst`, `user_id`, `timestamp`) VALUES
(1, 105, 3007, NULL, 1, '2020-02-10', '8.00', 5, 2, NULL, 1, 8, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:44:08'),
(2, 105, 3007, NULL, 1, '2020-02-11', '8.00', 5, 2, NULL, 1, 8, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:44:10'),
(3, 105, 3007, NULL, 1, '2020-02-12', '8.00', 5, 2, NULL, 1, 8, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:44:11'),
(4, 105, 3007, NULL, 1, '2020-02-13', '8.00', 5, 2, NULL, 1, 8, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:44:11'),
(5, 105, 3007, NULL, 1, '2020-02-14', '8.00', 5, 2, NULL, 1, 8, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:44:11'),
(6, 105, 3008, NULL, 2, '2020-02-10', '4.00', 10, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:00'),
(7, 105, 3008, NULL, 2, '2020-02-11', '4.00', 10, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:00'),
(8, 105, 3008, NULL, 2, '2020-02-12', '4.00', 10, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:01'),
(9, 105, 3008, NULL, 2, '2020-02-13', '4.00', 10, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:01'),
(10, 105, 3008, NULL, 2, '2020-02-10', '4.00', 12, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:08'),
(11, 105, 3008, NULL, 2, '2020-02-12', '4.00', 12, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:13'),
(12, 105, 3008, NULL, 2, '2020-02-11', '4.00', 12, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:17'),
(13, 105, 3008, NULL, 2, '2020-02-13', '4.00', 12, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:21'),
(14, 105, 3008, NULL, 2, '2020-02-14', '4.00', 10, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:25'),
(15, 105, 3008, NULL, 2, '2020-02-14', '4.00', 12, 3, NULL, 1, 14, NULL, NULL, NULL, '', NULL, NULL, '2020-02-20 07:54:26'),
(16, 105, 3007, NULL, 1, '2020-02-17', '8.00', 5, 2, NULL, 1, 20, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 09:48:58'),
(17, 105, 3007, NULL, 1, '2020-02-18', '8.00', 5, 2, NULL, 1, 20, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 09:49:01'),
(18, 105, 3007, NULL, 1, '2020-02-19', '8.00', 5, 2, NULL, 1, 20, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 09:49:04'),
(19, 105, 3007, NULL, 1, '2020-02-20', '8.00', 5, 2, NULL, 1, 20, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 09:49:07'),
(20, 105, 3007, NULL, 1, '2020-02-21', '8.00', 5, 2, NULL, 1, 20, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 09:49:10'),
(21, 105, 3008, NULL, 2, '2020-02-17', '4.00', 10, 3, NULL, 1, 25, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 10:04:48'),
(22, 105, 3008, NULL, 2, '2020-02-17', '4.00', 12, 3, NULL, 1, 25, NULL, NULL, NULL, '', NULL, NULL, '2020-02-27 10:04:52'),
(23, 105, 3007, NULL, 1, '2020-02-27', '8.00', 5, 2, NULL, 1, 34, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 10:22:35'),
(24, 105, 3007, NULL, 1, '2020-02-28', '7.00', 5, 2, NULL, 1, 34, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 10:22:38'),
(25, 105, 3008, NULL, 8003, '2020-02-24', '8.00', 15, 4, NULL, 1, 31, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 13:04:02'),
(26, 105, 3008, NULL, 8003, '2020-02-25', '8.00', 15, 4, NULL, 1, 31, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 13:04:03'),
(27, 105, 3008, NULL, 8003, '2020-02-26', '8.00', 15, 4, NULL, 1, 31, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 13:04:03'),
(28, 105, 3008, NULL, 8003, '2020-02-27', '8.00', 15, 4, NULL, 1, 31, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 13:04:04'),
(29, 105, 3008, NULL, 8003, '2020-02-28', '8.00', 15, 4, NULL, 1, 31, NULL, NULL, NULL, '', NULL, NULL, '2020-03-04 13:04:04'),
(30, 105, 3007, NULL, 1, '2020-03-02', '8.00', 5, 2, NULL, 1, 39, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 10:18:52'),
(31, 105, 3007, NULL, 1, '2020-03-03', '8.00', 5, 2, NULL, 1, 39, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 10:18:53'),
(32, 105, 3007, NULL, 1, '2020-03-04', '8.00', 5, 2, NULL, 1, 39, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 10:18:53'),
(33, 105, 3007, NULL, 1, '2020-03-05', '8.00', 5, 2, NULL, 1, 39, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 10:18:54'),
(34, 105, 3007, NULL, 1, '2020-03-06', '8.00', 5, 2, NULL, 1, 39, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 10:18:55'),
(35, 105, 3008, NULL, 8003, '2020-03-02', '8.00', 15, 4, NULL, 1, 44, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 12:27:25'),
(36, 105, 3008, NULL, 8003, '2020-03-03', '8.00', 15, 4, NULL, 1, 44, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 12:27:25'),
(37, 105, 3008, NULL, 8003, '2020-03-04', '8.00', 15, 4, NULL, 1, 44, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 12:27:26'),
(38, 105, 3008, NULL, 8003, '2020-03-05', '8.00', 15, 4, NULL, 1, 44, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 12:27:26'),
(39, 105, 3008, NULL, 8003, '2020-03-06', '8.00', 15, 4, NULL, 1, 44, NULL, NULL, NULL, '', NULL, NULL, '2020-03-10 12:27:28');

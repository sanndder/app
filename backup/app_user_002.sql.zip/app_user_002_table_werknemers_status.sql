
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_status`
--

CREATE TABLE `werknemers_status` (
  `werknemer_id` int(11) UNSIGNED NOT NULL,
  `archief` tinyint(1) NOT NULL DEFAULT '0',
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `gegevens_complete` tinyint(1) DEFAULT NULL,
  `documenten_complete` tinyint(1) DEFAULT NULL,
  `dienstverband_complete` tinyint(1) DEFAULT NULL,
  `verloning_complete` tinyint(1) DEFAULT NULL,
  `etregeling_complete` tinyint(1) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings_betaaltermijnen`
--

CREATE TABLE `settings_betaaltermijnen` (
  `id` int(11) UNSIGNED NOT NULL,
  `termijn` int(4) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `settings_betaaltermijnen`
--

INSERT INTO `settings_betaaltermijnen` (`id`, `termijn`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 5, NULL, '2019-10-02 13:45:53', 1, NULL, NULL),
(2, 8, NULL, '2019-10-02 13:45:53', 1, NULL, NULL),
(3, 10, NULL, '2019-10-02 13:46:01', 1, NULL, NULL),
(4, 14, NULL, '2019-10-02 13:46:01', 1, NULL, NULL),
(5, 21, NULL, '2019-10-02 13:46:19', 1, NULL, NULL),
(6, 28, NULL, '2019-10-02 13:46:19', 1, NULL, NULL),
(7, 30, NULL, '2019-10-02 13:46:41', 0, NULL, NULL),
(8, 45, NULL, '2019-10-02 13:46:41', 1, NULL, NULL),
(9, 60, NULL, '2019-10-02 13:46:47', 1, NULL, NULL),
(10, 90, NULL, '2019-10-02 13:46:47', 1, NULL, NULL);

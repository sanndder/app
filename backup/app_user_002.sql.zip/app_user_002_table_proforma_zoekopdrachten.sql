
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `proforma_zoekopdrachten`
--

CREATE TABLE `proforma_zoekopdrachten` (
  `id` int(12) NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `netto_loon` decimal(10,2) NOT NULL,
  `geboortejaar` int(4) NOT NULL,
  `loonheffingskorting` tinyint(1) NOT NULL,
  `bruto` decimal(10,2) NOT NULL,
  `prestatietoeslag` decimal(10,2) NOT NULL,
  `km` decimal(10,2) NOT NULL,
  `cao` varchar(10) NOT NULL,
  `pensioen` tinyint(1) NOT NULL,
  `uren` decimal(6,2) NOT NULL,
  `dagen` int(2) NOT NULL,
  `frequentie` varchar(2) NOT NULL,
  `vakantieuren_direct` tinyint(1) NOT NULL DEFAULT '0',
  `atv_direct` tinyint(1) NOT NULL DEFAULT '0',
  `vakantiegeld_direct` tinyint(1) NOT NULL DEFAULT '0',
  `et_regeling` tinyint(1) NOT NULL DEFAULT '0',
  `et_huisvesting` decimal(8,2) NOT NULL,
  `et_km` decimal(8,2) NOT NULL,
  `et_verschil_leven` decimal(8,2) NOT NULL,
  `verkooptarief` decimal(8,2) NOT NULL,
  `factor_belast` decimal(5,3) NOT NULL,
  `factor_onbelast` decimal(5,3) NOT NULL,
  `doelgroepverklaring` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `proforma_zoekopdrachten`
--

INSERT INTO `proforma_zoekopdrachten` (`id`, `user_id`, `timestamp`, `netto_loon`, `geboortejaar`, `loonheffingskorting`, `bruto`, `prestatietoeslag`, `km`, `cao`, `pensioen`, `uren`, `dagen`, `frequentie`, `vakantieuren_direct`, `atv_direct`, `vakantiegeld_direct`, `et_regeling`, `et_huisvesting`, `et_km`, `et_verschil_leven`, `verkooptarief`, `factor_belast`, `factor_onbelast`, `doelgroepverklaring`) VALUES
(1, 49, '2020-03-10 10:23:35', '445.36', 1980, 1, '14.04', '0.00', '0.00', 'NBBU', 0, '40.00', 5, 'w', 0, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', '1.730', '1.550', 0),
(2, 49, '2020-03-10 10:24:10', '407.81', 1980, 1, '14.04', '0.00', '0.00', 'NBBU', 0, '40.00', 5, 'w', 0, 0, 0, 1, '70.00', '0.00', '0.00', '0.00', '1.730', '1.550', 0),
(3, 49, '2020-03-10 10:24:12', '407.81', 1980, 1, '14.04', '0.00', '0.00', 'NBBU', 0, '40.00', 5, 'w', 0, 0, 0, 1, '70.00', '0.00', '0.00', '0.00', '1.730', '1.550', 0),
(4, 49, '2020-03-10 10:26:18', '407.81', 1980, 1, '14.04', '0.00', '0.00', 'NBBU', 0, '40.00', 5, 'w', 0, 0, 0, 1, '70.00', '0.00', '0.00', '0.00', '1.730', '1.550', 0),
(5, 49, '2020-03-10 10:26:18', '407.81', 1980, 1, '14.04', '0.00', '0.00', 'NBBU', 0, '40.00', 5, 'w', 0, 0, 0, 1, '70.00', '0.00', '0.00', '0.00', '1.730', '1.550', 0);

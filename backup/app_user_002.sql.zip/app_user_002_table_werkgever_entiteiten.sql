
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkgever_entiteiten`
--

CREATE TABLE `werkgever_entiteiten` (
  `entiteit_id` int(11) UNSIGNED NOT NULL,
  `default_entiteit` tinyint(1) NOT NULL DEFAULT '0',
  `schermnaam` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `werkgever_entiteiten`
--

INSERT INTO `werkgever_entiteiten` (`entiteit_id`, `default_entiteit`, `schermnaam`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 'Abering Uitzend B.V.', 1, NULL, 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_bedrijfsgegevens`
--

CREATE TABLE `zzp_bedrijfsgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `bedrijfsnaam` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `btwnr` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` int(5) UNSIGNED DEFAULT NULL,
  `huisnummer_toevoeging` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_nummer` int(5) DEFAULT NULL,
  `postbus_postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_bedrijfsgegevens`
--

INSERT INTO `zzp_bedrijfsgegevens` (`id`, `zzp_id`, `bedrijfsnaam`, `kvknr`, `btwnr`, `telefoon`, `straat`, `huisnummer`, `huisnummer_toevoeging`, `postcode`, `plaats`, `postbus_nummer`, `postbus_postcode`, `postbus_plaats`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 'Elmaki Pro demolition', '68737084', 'NL123456789B01', '0611847158', 'Elsland', 1412, NULL, '6605KL', 'WIJCHEN', NULL, NULL, NULL, 48, '2020-02-18 10:56:44', 0, NULL, NULL),
(2, 2, 'Ouaaa Sloop', '73435465', 'NL218611791B01', '0685058102', 'Broekstraat', 50, NULL, '6612AD', 'Nederasselt', NULL, NULL, NULL, 2, '2020-02-20 07:38:45', 0, NULL, NULL),
(3, 8003, 'E.S.W. Sloop & Schoonmaak', '68609515', 'NL854569182B01', '0685502260', 'Lankforst', 2152, NULL, '6538GH', 'NIJMEGEN', NULL, NULL, NULL, 2, '2020-03-04 12:39:30', 0, NULL, NULL);

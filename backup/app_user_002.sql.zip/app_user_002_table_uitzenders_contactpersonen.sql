
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_contactpersonen`
--

CREATE TABLE `uitzenders_contactpersonen` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `tekenbevoegd` tinyint(1) DEFAULT NULL,
  `aanhef` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voorletters` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voornaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tussenvoegsel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `achternaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `functie` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `afdeling` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opmerking` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_contactpersonen`
--

INSERT INTO `uitzenders_contactpersonen` (`id`, `uitzender_id`, `contact_id`, `tekenbevoegd`, `aanhef`, `voorletters`, `voornaam`, `tussenvoegsel`, `achternaam`, `functie`, `afdeling`, `telefoon`, `email`, `opmerking`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(11, 103, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-08 11:18:22', 1, 0, '2020-01-08 12:18:22'),
(12, 103, 1, NULL, 'dhr', 'J', 'Jürgen', NULL, 'Hoffmann', 'eigenaar', NULL, '0646-253563', 'info@henh.eu', NULL, 0, '2020-01-08 11:18:22', 0, NULL, NULL),
(13, 104, 7, 1, 'dhr', 'SMJ', 'Stephen', NULL, 'Bart', 'Directeur', NULL, '0629625764', 'smjbart@gmail.com', NULL, 0, '2020-01-30 11:34:08', 0, NULL, NULL),
(14, 105, 1, NULL, 'dhr', 'M', 'Moonier', NULL, 'Zarouali', 'Directeur', NULL, '0682208331', 'moonier@4you-pd.nl', NULL, 0, '2020-02-12 12:43:59', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_kilometers`
--

CREATE TABLE `invoer_kilometers` (
  `invoer_id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `locatie_van` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locatie_naar` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aantal` decimal(6,2) DEFAULT NULL,
  `aantal_kortste` decimal(6,2) NOT NULL,
  `aantal_snelste` decimal(6,2) NOT NULL,
  `doorbelasten` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `verloning_id` int(11) UNSIGNED DEFAULT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `project_tekst` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opmerking_tekst` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locatie_tekst` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkgever_bedrijfsgegevens`
--

CREATE TABLE `werkgever_bedrijfsgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `entiteit_id` int(11) DEFAULT NULL,
  `bedrijfsnaam` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `btwnr` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `plaats` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `werkgever_bedrijfsgegevens`
--

INSERT INTO `werkgever_bedrijfsgegevens` (`id`, `entiteit_id`, `bedrijfsnaam`, `kvknr`, `btwnr`, `straat`, `huisnummer`, `postcode`, `plaats`, `telefoon`, `email`, `website`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(19, 1, 'Abering Bemiddeling B.V.', '76504050', 'NL860648394B01', 'Reitscheweg', '37', '5232BX', '\'s-Hertogenbosch', NULL, NULL, NULL, 2, '2020-01-07 13:30:20', 0, NULL, NULL);

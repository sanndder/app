
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_inleners`
--

CREATE TABLE `werknemers_inleners` (
  `plaatsing_id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `document_id` int(11) UNSIGNED DEFAULT NULL,
  `factor_id` int(11) DEFAULT NULL,
  `cao_id_intern` int(11) DEFAULT NULL,
  `loontabel_id_intern` int(11) DEFAULT NULL,
  `job_id_intern` int(11) DEFAULT NULL,
  `schaal` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `periodiek` int(2) DEFAULT NULL,
  `start_plaatsing` date DEFAULT NULL,
  `einde_plaatsing` date DEFAULT NULL,
  `bruto_loon` decimal(4,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

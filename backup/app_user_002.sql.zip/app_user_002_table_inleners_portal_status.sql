
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_portal_status`
--

CREATE TABLE `inleners_portal_status` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `portal_closed_kredietlimiet` tinyint(1) NOT NULL DEFAULT '0',
  `portal_closed_betaaltermijn` tinyint(1) NOT NULL DEFAULT '0',
  `portal_closed_kredietlimiet_override` tinyint(1) NOT NULL DEFAULT '0',
  `portal_closed_betaaltermijn_override` tinyint(1) NOT NULL DEFAULT '0',
  `kredietlimiet_override_end` date DEFAULT NULL,
  `betaaltermijn_override_end` date DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_recipients`
--

CREATE TABLE `emails_recipients` (
  `id` int(11) UNSIGNED NOT NULL,
  `email_id` int(11) DEFAULT NULL,
  `type` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'to',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `meta` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `emails_recipients`
--

INSERT INTO `emails_recipients` (`id`, `email_id`, `type`, `name`, `email`, `uitzender_id`, `inlener_id`, `werknemer_id`, `meta`) VALUES
(1, 1, 'to', 'hsmeijering@home.nl', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(2, 2, 'to', 'hsmeijering@home.nl', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(3, 3, 'to', 'hsmeijering@home.nl', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(4, 4, 'to', 'hsmeijering@home.nl', 'hsmeijering@home.nl', NULL, NULL, NULL, NULL),
(5, 5, 'to', 'info@henh.eu', 'info@henh.eu', NULL, NULL, NULL, NULL),
(6, 6, 'to', 'Jürgen  Hoffmann', 'info@henh.eu', NULL, NULL, NULL, NULL),
(7, 7, 'to', 'Stephens Consultancy Holding BV', 'smjbart@gmail.com', NULL, NULL, NULL, NULL),
(8, 8, 'to', 'MDM Milieutechniek B.V.', 'info@mdmasbest.com', NULL, NULL, NULL, NULL),
(9, 8, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(10, 9, 'to', 'Horyon Innovaties en Technieken B.V.', 'administratie@horyon-innovaties.nl', NULL, NULL, NULL, NULL),
(11, 9, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(12, 10, 'to', 'MDM Milieutechniek B.V.', 'info@mdmasbest.com', NULL, NULL, NULL, NULL),
(13, 10, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(14, 11, 'to', 'Horyon Innovaties en Technieken B.V.', 'administratie@horyon-innovaties.nl', NULL, NULL, NULL, NULL),
(15, 11, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(16, 12, 'to', 'MDM Milieutechniek B.V.', 'info@mdmasbest.com', NULL, NULL, NULL, NULL),
(17, 12, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(18, 13, 'to', 'Horyon Innovaties en Technieken B.V.', 'administratie@horyon-innovaties.nl', NULL, NULL, NULL, NULL),
(19, 13, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(20, 14, 'to', 'MDM Milieutechniek B.V.', 'info@mdmasbest.com', NULL, NULL, NULL, NULL),
(21, 14, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL),
(22, 15, 'to', 'Horyon Innovaties en Technieken B.V.', 'administratie@horyon-innovaties.nl', NULL, NULL, NULL, NULL),
(23, 15, 'to', 'Factris', 'facturen@factris.com', NULL, NULL, NULL, NULL);

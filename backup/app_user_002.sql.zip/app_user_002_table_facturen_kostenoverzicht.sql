
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `facturen_kostenoverzicht`
--

CREATE TABLE `facturen_kostenoverzicht` (
  `kosten_id` int(11) UNSIGNED NOT NULL,
  `sessie_id` int(11) UNSIGNED DEFAULT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `facturen_kostenoverzicht`
--

INSERT INTO `facturen_kostenoverzicht` (`kosten_id`, `sessie_id`, `factuur_id`, `file_dir`, `file_name`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3, 2, 'facturen/2020', '2_kostenoverzicht_ECHz.pdf', 49, '2020-02-20 09:33:05', 1, 49, '2020-02-20 10:36:37'),
(2, 8, 8, 'facturen/2020', '8_kostenoverzicht_MrKH.pdf', 49, '2020-02-20 09:43:27', 0, NULL, NULL),
(3, 9, 10, 'facturen/2020', '10_kostenoverzicht_ad2b.pdf', 49, '2020-02-20 09:47:12', 1, 2, '2020-02-20 10:50:30'),
(4, 10, 12, 'facturen/2020', '12_kostenoverzicht_WUt3.pdf', 2, '2020-02-20 09:51:40', 1, 2, '2020-02-20 10:52:02'),
(5, 11, 14, 'facturen/2020', '14_kostenoverzicht_GRyN.pdf', 2, '2020-02-20 09:54:21', 0, NULL, NULL),
(6, 16, 20, 'facturen/2020', '20_kostenoverzicht_PZKP.pdf', 49, '2020-02-27 09:51:04', 0, NULL, NULL),
(7, 20, 25, 'facturen/2020', '25_kostenoverzicht_xyxp.pdf', 49, '2020-02-27 11:43:53', 0, NULL, NULL),
(8, 25, 31, 'facturen/2020', '31_kostenoverzicht_9xh4.pdf', 49, '2020-03-04 13:05:02', 0, NULL, NULL),
(9, 32, 34, 'facturen/2020', '34_kostenoverzicht_5Jn5.pdf', 49, '2020-03-04 13:12:41', 0, NULL, NULL),
(10, 37, 39, 'facturen/2020', '39_kostenoverzicht_v7SY.pdf', 49, '2020-03-10 12:26:56', 0, NULL, NULL),
(11, 46, 42, 'facturen/2020', '42_kostenoverzicht_jMqM.pdf', 2, '2020-03-11 07:46:02', 1, 2, '2020-03-11 08:46:15'),
(12, 47, 44, 'facturen/2020', '44_kostenoverzicht_WF98.pdf', 2, '2020-03-11 12:01:29', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_log`
--

CREATE TABLE `emails_log` (
  `id` int(12) NOT NULL,
  `email_id` int(11) NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `emails_log`
--

INSERT INTO `emails_log` (`id`, `email_id`, `action`, `user_id`, `timestamp`) VALUES
(1, 1, 'email aangemaakt', 2, '2020-01-07 15:50:56'),
(2, 1, 'Email verzonden', 2, '2020-01-07 15:50:58'),
(3, 2, 'email aangemaakt', 2, '2020-01-07 15:54:00'),
(4, 2, 'Email verzonden', 2, '2020-01-07 15:54:01'),
(5, 3, 'email aangemaakt', 2, '2020-01-07 15:55:19'),
(6, 3, 'Email verzonden', 2, '2020-01-07 15:55:21'),
(7, 4, 'email aangemaakt', 2, '2020-01-07 15:58:24'),
(8, 4, 'Email verzonden', 2, '2020-01-07 15:58:26'),
(9, 5, 'email aangemaakt', 48, '2020-01-07 16:01:04'),
(10, 5, 'Email verzonden', 48, '2020-01-07 16:01:07'),
(11, 6, 'email aangemaakt', 48, '2020-01-08 14:11:47'),
(12, 6, 'Email verzonden', 48, '2020-01-08 14:11:48'),
(13, 7, 'email aangemaakt', 48, '2020-02-06 09:20:05'),
(14, 7, 'Email verzonden', 48, '2020-02-06 09:20:06'),
(15, 8, 'email aangemaakt', 2, '2020-02-20 10:37:37'),
(16, 8, 'Email verzonden', 2, '2020-02-20 10:37:38'),
(17, 9, 'email aangemaakt', 2, '2020-02-20 10:37:51'),
(18, 9, 'Email verzonden', 2, '2020-02-20 10:37:54'),
(19, 10, 'email aangemaakt', 2, '2020-02-27 12:22:31'),
(20, 10, 'Email verzonden', 2, '2020-02-27 12:22:34'),
(21, 11, 'email aangemaakt', 2, '2020-02-27 12:23:34'),
(22, 11, 'Email verzonden', 2, '2020-02-27 12:23:37'),
(23, 12, 'email aangemaakt', 2, '2020-03-04 14:17:18'),
(24, 12, 'Email verzonden', 2, '2020-03-04 14:17:19'),
(25, 13, 'email aangemaakt', 2, '2020-03-04 14:17:22'),
(26, 13, 'Email verzonden', 2, '2020-03-04 14:17:23'),
(27, 14, 'email aangemaakt', 2, '2020-03-11 09:58:00'),
(28, 14, 'Email verzonden', 2, '2020-03-11 09:58:01'),
(29, 15, 'email aangemaakt', 2, '2020-03-11 12:03:51'),
(30, 15, 'Email verzonden', 2, '2020-03-11 12:03:52');

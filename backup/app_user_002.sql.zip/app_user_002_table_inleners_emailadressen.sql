
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_emailadressen`
--

CREATE TABLE `inleners_emailadressen` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `standaard` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facturatie` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `administratie` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_emailadressen`
--

INSERT INTO `inleners_emailadressen` (`id`, `inlener_id`, `standaard`, `facturatie`, `administratie`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3006, 'jboeve@vandamgroep.com', 'hbrinks@vandamgroep.com', 'hbrinks@vandamgroep.com', 48, '2020-02-10 09:50:19', 0, NULL, NULL),
(2, 3007, 'info@mdmasbest.com', 'info@mdmasbest.com', 'info@mdmasbest.com', 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(3, 3008, 'administratie@horyon-innovaties.nl', NULL, 'j.v.hamond@horyon.nl', 2, '2020-02-20 07:52:32', 0, NULL, NULL);

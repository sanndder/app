
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `emails_attachments`
--

CREATE TABLE `emails_attachments` (
  `id` int(11) NOT NULL,
  `email_id` int(11) NOT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_name_display` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_table` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `temp_file_dir` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `temp_file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `emails_attachments`
--

INSERT INTO `emails_attachments` (`id`, `email_id`, `file_dir`, `file_name`, `file_name_display`, `file_table`, `file_id`, `temp_file_dir`, `temp_file_name`, `file_size`) VALUES
(1, 8, 'facturen/2020', '8_verkoop_uren_3_ZMgt.pdf', 'factuur_3.pdf', 'facturen', 8, '', '', 0),
(2, 9, 'facturen/2020', '14_verkoop_uren_9_iG7U.pdf', 'factuur_9.pdf', 'facturen', 14, '', '', 0),
(3, 10, 'facturen/2020', '20_verkoop_uren_11_WACZ.pdf', 'factuur_11.pdf', 'facturen', 20, '', '', 0),
(4, 11, 'facturen/2020', '25_verkoop_uren_13_rcUj.pdf', 'factuur_13.pdf', 'facturen', 25, '', '', 0),
(5, 12, 'facturen/2020', '34_verkoop_uren_17_usNA.pdf', 'factuur_17.pdf', 'facturen', 34, '', '', 0),
(6, 13, 'facturen/2020', '31_verkoop_uren_15_2sS3.pdf', 'factuur_15.pdf', 'facturen', 31, '', '', 0),
(7, 14, 'facturen/2020', '39_verkoop_uren_19_zzcH.pdf', 'factuur_19.pdf', 'facturen', 39, '', '', 0),
(8, 15, 'facturen/2020', '44_verkoop_uren_23_E6FY.pdf', 'factuur_23.pdf', 'facturen', 44, '', '', 0);

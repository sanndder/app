
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_emailadressen`
--

CREATE TABLE `uitzenders_emailadressen` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `standaard` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facturatie` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `administratie` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_emailadressen`
--

INSERT INTO `uitzenders_emailadressen` (`id`, `uitzender_id`, `standaard`, `facturatie`, `administratie`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(5, 103, 'info@henh.eu', 'info@henh.eu', 'info@henh.eu', 0, '2020-01-08 11:16:23', 0, NULL, NULL),
(6, 104, 'smjbart@gmail.com', 'smjbart@gmail.com', 'smjbart@gmail.com', 0, '2020-01-30 11:34:08', 0, NULL, NULL),
(7, 105, 'moonier@4you-pd.nl', 'moonier@4you-pd.nl', NULL, 48, '2020-02-12 12:43:59', 0, NULL, NULL);

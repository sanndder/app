
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_bedrijfsgegevens`
--

CREATE TABLE `inleners_bedrijfsgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `bedrijfsnaam` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `btwnr` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` int(5) UNSIGNED DEFAULT NULL,
  `huisnummer_toevoeging` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_nummer` int(5) DEFAULT NULL,
  `postbus_postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_bedrijfsgegevens`
--

INSERT INTO `inleners_bedrijfsgegevens` (`id`, `inlener_id`, `bedrijfsnaam`, `kvknr`, `btwnr`, `telefoon`, `straat`, `huisnummer`, `huisnummer_toevoeging`, `postcode`, `plaats`, `postbus_nummer`, `postbus_postcode`, `postbus_plaats`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3000, 'Coatacoustic B.V.', '18066055', 'NL810536262B01', '0418587030', 'Schimminck', 16, NULL, '5301KR', 'Zaltbommel', NULL, NULL, NULL, 2, '2020-01-08 14:33:24', 0, NULL, NULL),
(7, 3006, 'Installatiebedrijf G. van Dam B.V.', '06060664', 'NL007725759B01', '+31 (0) 548 51 44 11', 'Fahrenheitstraat', 4, NULL, '7461JA', 'Rijssen', NULL, NULL, NULL, 48, '2020-02-06 09:20:05', 0, NULL, NULL),
(8, 3007, 'MDM Milieutechniek B.V.', '59203242', 'NL853365854B01', '+31612550777', 'Dalderhaag', 11, NULL, '6136KM', 'SITTARD', NULL, NULL, NULL, 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(9, 3008, 'Horyon Innovaties en Technieken B.V.', '63774267', 'NL855395370B01', '0402904000', 'Papendorpseweg', 100, NULL, '3528BJ', 'Utrecht', NULL, NULL, NULL, 48, '2020-02-20 07:52:32', 0, NULL, NULL);

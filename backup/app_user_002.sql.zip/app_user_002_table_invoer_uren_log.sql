
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_uren_log`
--

CREATE TABLE `invoer_uren_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `invoer_id` int(11) UNSIGNED DEFAULT NULL,
  `action` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `json` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `invoer_uren_log`
--

INSERT INTO `invoer_uren_log` (`id`, `invoer_id`, `action`, `json`, `user_id`, `timestamp`) VALUES
(1, 1, 'update', '{\"invoer_id\":\"1\",\"uitzender_id\":\"105\",\"inlener_id\":\"3007\",\"werknemer_id\":null,\"zzp_id\":\"1\",\"datum\":\"2020-02-10\",\"aantal\":\"0.00\",\"uren_type_id_werknemer\":\"5\",\"plaatsing_id\":\"2\",\"doorbelasten\":null,\"uitkeren\":\"1\",\"factuur_id\":null,\"verloning_id\":null,\"project_id\":null,\"project_tekst\":null,\"opmerking_tekst\":\"\",\"locatie_tekst\":null,\"user_id\":null,\"timestamp\":\"2020-02-20 08:44:08\"}', 2, '2020-02-20 07:44:10'),
(2, 14, 'update', '{\"invoer_id\":\"14\",\"uitzender_id\":\"105\",\"inlener_id\":\"3008\",\"werknemer_id\":null,\"zzp_id\":\"2\",\"datum\":\"2020-02-14\",\"aantal\":\"4.00\",\"uren_type_id_werknemer\":\"12\",\"plaatsing_id\":\"3\",\"doorbelasten\":null,\"uitkeren\":\"1\",\"factuur_id\":null,\"verloning_id\":null,\"project_id\":null,\"project_tekst\":null,\"opmerking_tekst\":\"\",\"locatie_tekst\":null,\"user_id\":null,\"timestamp\":\"2020-02-20 08:54:25\"}', 2, '2020-02-20 07:54:36'),
(3, 15, 'update', '{\"invoer_id\":\"15\",\"uitzender_id\":\"105\",\"inlener_id\":\"3008\",\"werknemer_id\":null,\"zzp_id\":\"2\",\"datum\":\"2020-02-14\",\"aantal\":\"4.00\",\"uren_type_id_werknemer\":\"10\",\"plaatsing_id\":\"3\",\"doorbelasten\":null,\"uitkeren\":\"1\",\"factuur_id\":null,\"verloning_id\":null,\"project_id\":null,\"project_tekst\":null,\"opmerking_tekst\":\"\",\"locatie_tekst\":null,\"user_id\":null,\"timestamp\":\"2020-02-20 08:54:26\"}', 2, '2020-02-20 07:54:37');

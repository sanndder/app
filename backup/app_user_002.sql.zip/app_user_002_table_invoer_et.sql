
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_et`
--

CREATE TABLE `invoer_et` (
  `invoer_id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `tijdvak` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jaar` int(4) DEFAULT NULL,
  `periode` int(2) DEFAULT NULL,
  `bedrag_huisvesting` decimal(6,2) NOT NULL,
  `bedrag_vervoer` decimal(6,2) DEFAULT NULL,
  `bedrag_levensstandaard` decimal(6,2) DEFAULT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `verloning_id` int(11) UNSIGNED DEFAULT NULL,
  `project_id` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

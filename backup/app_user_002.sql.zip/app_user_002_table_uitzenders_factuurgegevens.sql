
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_factuurgegevens`
--

CREATE TABLE `uitzenders_factuurgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tav` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `factuur_emailen` tinyint(1) DEFAULT NULL,
  `bijlages_invoegen` tinyint(1) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_factuurgegevens`
--

INSERT INTO `uitzenders_factuurgegevens` (`id`, `uitzender_id`, `iban`, `tav`, `factuur_emailen`, `bijlages_invoegen`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(6, 103, 'NL65RABO0309416663', 'Huls & Hoffmann uitzendorganisatie', 1, 1, 0, '2020-01-08 11:17:48', 0, NULL, NULL),
(7, 104, 'NL06ABNA0248736485', 'STEPHENS CONSULTANCY', 1, 1, 0, '2020-01-30 11:34:08', 0, NULL, NULL),
(8, 105, 'NL60RABO0310262496', '4 You Personeelsdiensten', 1, 1, 48, '2020-02-12 12:43:59', 0, NULL, NULL);

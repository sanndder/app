
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `urentypes`
--

CREATE TABLE `urentypes` (
  `urentype_id` int(11) UNSIGNED NOT NULL,
  `urentype_categorie_id` int(11) DEFAULT NULL,
  `naam` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `factor` decimal(4,3) DEFAULT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `urentypes`
--

INSERT INTO `urentypes` (`urentype_id`, `urentype_categorie_id`, `naam`, `factor`, `percentage`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 'uren', '1.630', '100.00', 2, '2019-09-25 15:03:40', 0, 2, '2019-09-26 14:15:43'),
(2, 1, 'uren/toeslag 120%', '1.630', '120.00', 2, '2019-09-25 15:13:13', 0, 2, '2019-09-26 14:15:43'),
(3, 2, 'overuren 150%', '1.420', '150.00', 2, '2019-09-26 11:20:04', 0, 2, '2019-09-26 14:15:43'),
(4, 3, 'reisuren 100%', '1.000', '100.00', 2, '2019-09-26 11:24:19', 0, 2, '2019-09-26 14:15:43'),
(5, 2, 'overuren 150%', '1.420', '150.00', 2, '2019-09-26 11:20:04', 1, 2, '2019-09-26 14:17:42'),
(6, 1, 'uren/toeslag 150%', '1.630', '150.00', 2, '2019-09-26 12:33:55', 1, 2, '2019-12-04 15:49:48'),
(7, 1, 'uren/toeslag 200%', NULL, '200.00', 2, '2019-10-02 19:08:47', 0, NULL, NULL),
(8, 2, 'toeslag 50%', NULL, '50.00', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(9, 2, 'overuren 125.00%', NULL, '125.00', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(10, 2, 'overuren 200.00%', NULL, '200.00', 2, '2020-02-19 12:45:04', 0, NULL, NULL);

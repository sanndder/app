
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_status`
--

CREATE TABLE `inleners_status` (
  `inlener_id` int(11) UNSIGNED NOT NULL,
  `archief` tinyint(1) NOT NULL DEFAULT '0',
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `bedrijfsgegevens_complete` tinyint(1) DEFAULT NULL,
  `factuurgegevens_complete` tinyint(1) DEFAULT NULL,
  `contactpersoon_complete` tinyint(1) DEFAULT NULL,
  `emailadressen_complete` tinyint(1) DEFAULT NULL,
  `cao_complete` tinyint(1) DEFAULT NULL,
  `last_update_by` int(11) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_status`
--

INSERT INTO `inleners_status` (`inlener_id`, `archief`, `complete`, `bedrijfsgegevens_complete`, `factuurgegevens_complete`, `contactpersoon_complete`, `emailadressen_complete`, `cao_complete`, `last_update_by`, `last_update`) VALUES
(3000, 1, 0, 0, NULL, NULL, NULL, 1, 48, '2020-02-07 10:35:38'),
(3006, 1, 1, 1, 1, 1, 1, 1, 2, '2020-02-20 12:58:26'),
(3007, 0, 1, 1, 1, 1, 1, 1, NULL, '2020-02-03 11:25:00'),
(3008, 0, 1, 1, 1, 1, 1, 1, NULL, '2020-02-18 09:52:53');

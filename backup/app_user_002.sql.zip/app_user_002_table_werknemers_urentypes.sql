
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_urentypes`
--

CREATE TABLE `werknemers_urentypes` (
  `id` int(11) UNSIGNED NOT NULL,
  `urentype_active` int(1) NOT NULL DEFAULT '1',
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_urentype_id` int(11) UNSIGNED DEFAULT NULL,
  `urentype_id` int(11) UNSIGNED DEFAULT NULL,
  `plaatsing_id` int(10) UNSIGNED DEFAULT NULL,
  `verkooptarief` decimal(5,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

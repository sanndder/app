
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_dienstverband_duur`
--

CREATE TABLE `werknemers_dienstverband_duur` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `weken_start` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `weken` smallint(3) UNSIGNED NOT NULL DEFAULT '0',
  `indienst` date DEFAULT NULL,
  `fase` varchar(4) COLLATE utf8_unicode_ci DEFAULT 'A',
  `fase_a` tinyint(1) DEFAULT '0',
  `indienst_a` date DEFAULT NULL,
  `uitdienst_a` date DEFAULT NULL,
  `fase_b` tinyint(1) NOT NULL DEFAULT '0',
  `indienst_b` date DEFAULT NULL,
  `uitdienst_b` date DEFAULT NULL,
  `fase_c` tinyint(1) NOT NULL DEFAULT '0',
  `indienst_c` date DEFAULT NULL,
  `uitdienst_c` date DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

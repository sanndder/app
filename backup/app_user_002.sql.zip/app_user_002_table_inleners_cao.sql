
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_cao`
--

CREATE TABLE `inleners_cao` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `no_cao` tinyint(4) DEFAULT NULL,
  `cao_id_intern` int(11) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_cao`
--

INSERT INTO `inleners_cao` (`id`, `inlener_id`, `no_cao`, `cao_id_intern`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3007, NULL, 60, 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(2, 3008, NULL, 60, 48, '2020-02-20 07:52:32', 0, NULL, NULL);

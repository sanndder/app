
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_kredietgebruik`
--

CREATE TABLE `inleners_kredietgebruik` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `kredietgebruik` decimal(9,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_kredietgebruik`
--

INSERT INTO `inleners_kredietgebruik` (`id`, `inlener_id`, `kredietgebruik`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3000, '0.00', 2, '2020-01-08 14:33:24', 0, NULL, NULL),
(2, 3006, '0.00', 48, '2020-02-06 09:20:05', 0, NULL, NULL);

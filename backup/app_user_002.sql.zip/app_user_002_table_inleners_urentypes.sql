
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_urentypes`
--

CREATE TABLE `inleners_urentypes` (
  `inlener_urentype_id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `urentype_id` int(11) UNSIGNED DEFAULT NULL,
  `default_urentype` tinyint(1) DEFAULT '0',
  `standaard_verkooptarief` decimal(4,2) DEFAULT NULL,
  `doorbelasten_uitzender` tinyint(1) NOT NULL DEFAULT '0',
  `label` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_urentypes`
--

INSERT INTO `inleners_urentypes` (`inlener_urentype_id`, `inlener_id`, `urentype_id`, `default_urentype`, `standaard_verkooptarief`, `doorbelasten_uitzender`, `label`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3006, 1, 1, NULL, 0, NULL, 48, '2020-02-10 09:53:30', 0, NULL, NULL),
(2, 3007, 8, 0, NULL, 0, '', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(3, 3007, 9, 0, NULL, 0, '', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(4, 3007, 3, 0, NULL, 0, '', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(5, 3007, 10, 0, NULL, 0, '', 2, '2020-02-19 12:45:04', 0, NULL, NULL),
(6, 3007, 1, 1, NULL, 0, NULL, 48, '2020-02-10 09:53:30', 0, NULL, NULL),
(24, 3008, 1, 1, NULL, 0, NULL, 48, '2020-02-20 07:52:32', 0, NULL, NULL),
(25, 3008, 8, 0, NULL, 0, '', 2, '2020-02-20 07:52:32', 0, NULL, NULL),
(26, 3008, 9, 0, NULL, 0, '', 2, '2020-02-20 07:52:32', 0, NULL, NULL),
(27, 3008, 3, 0, NULL, 0, '', 2, '2020-02-20 07:52:32', 0, NULL, NULL),
(28, 3008, 10, 0, NULL, 0, '', 2, '2020-02-20 07:52:32', 0, NULL, NULL);

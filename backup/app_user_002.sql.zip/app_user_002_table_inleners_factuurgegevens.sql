
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_factuurgegevens`
--

CREATE TABLE `inleners_factuurgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tav` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequentie` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `termijn` tinyint(3) DEFAULT NULL,
  `btw_verleggen` tinyint(1) NOT NULL DEFAULT '0',
  `g_rekening` tinyint(1) UNSIGNED DEFAULT NULL,
  `g_rekening_percentage` tinyint(2) UNSIGNED DEFAULT NULL,
  `factoring` tinyint(1) NOT NULL DEFAULT '1',
  `factuur_per_medewerker` tinyint(1) NOT NULL DEFAULT '0',
  `factuur_per_project` tinyint(1) NOT NULL DEFAULT '0',
  `afgesproken_werk` tinyint(1) NOT NULL DEFAULT '0',
  `factuur_emailen` tinyint(1) DEFAULT NULL,
  `bijlages_invoegen` tinyint(1) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_factuurgegevens`
--

INSERT INTO `inleners_factuurgegevens` (`id`, `inlener_id`, `iban`, `tav`, `frequentie`, `termijn`, `btw_verleggen`, `g_rekening`, `g_rekening_percentage`, `factoring`, `factuur_per_medewerker`, `factuur_per_project`, `afgesproken_werk`, `factuur_emailen`, `bijlages_invoegen`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 3006, 'NL72RABO0347341500', 'Van Dam Technisch Beheer bv', 'w', 30, 0, 1, 30, 1, 0, 0, 0, 1, 1, 48, '2020-02-10 09:52:07', 0, NULL, NULL),
(2, 3007, 'NL07ABNA0557276977', 'MDM Milieutechniek B.V.', 'w', 30, 0, 1, 30, 1, 0, 0, 0, 1, 1, 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(3, 3008, NULL, NULL, 'w', 45, 1, 1, 30, 1, 0, 0, 0, 1, 1, 48, '2020-02-20 07:52:32', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `documenten_templates_settings`
--

CREATE TABLE `documenten_templates_settings` (
  `id` int(11) UNSIGNED NOT NULL,
  `entiteit_id` int(11) UNSIGNED DEFAULT NULL,
  `template_id` int(11) UNSIGNED DEFAULT NULL,
  `template_code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `arbeidsovereenkomst` tinyint(1) NOT NULL DEFAULT '0',
  `fase` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_werknemer` tinyint(1) DEFAULT NULL,
  `email_zzp` tinyint(1) DEFAULT NULL,
  `email_inlener` tinyint(1) DEFAULT NULL,
  `email_uitzender` tinyint(1) DEFAULT NULL,
  `sign_werknemer` tinyint(1) DEFAULT NULL,
  `sign_inlener` tinyint(1) DEFAULT NULL,
  `sign_uitzender` tinyint(1) DEFAULT NULL,
  `block_access` tinyint(1) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `documenten_templates_settings`
--

INSERT INTO `documenten_templates_settings` (`id`, `entiteit_id`, `template_id`, `template_code`, `categorie_id`, `arbeidsovereenkomst`, `fase`, `template_name`, `lang`, `owner`, `email_werknemer`, `email_zzp`, `email_inlener`, `email_uitzender`, `sign_werknemer`, `sign_inlener`, `sign_uitzender`, `block_access`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(10, 1, 1, NULL, 2, 0, NULL, 'Overeenkomst van dienstverlening', 'NL', 'uitzender', NULL, NULL, NULL, 1, NULL, NULL, 1, 1, NULL, '2020-01-08 19:52:42', 0, NULL, NULL),
(11, 1, 2, NULL, 7, 0, NULL, 'overeenkomst inlener', 'NL', 'inlener', NULL, NULL, 1, NULL, NULL, 1, NULL, 1, NULL, '2020-02-18 06:50:11', 0, NULL, NULL);

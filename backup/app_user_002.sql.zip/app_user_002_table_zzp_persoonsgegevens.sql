
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_persoonsgegevens`
--

CREATE TABLE `zzp_persoonsgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `gb_datum` date DEFAULT NULL,
  `achternaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tussenvoegsel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voorletters` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voornaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `geslacht` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobiel` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` int(5) UNSIGNED DEFAULT NULL,
  `huisnummer_toevoeging` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `woonland_id` int(11) DEFAULT NULL,
  `nationaltieit_id` int(11) DEFAULT NULL,
  `bsn` int(9) UNSIGNED ZEROFILL DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tav` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_persoonsgegevens`
--

INSERT INTO `zzp_persoonsgegevens` (`id`, `zzp_id`, `gb_datum`, `achternaam`, `tussenvoegsel`, `voorletters`, `voornaam`, `geslacht`, `telefoon`, `mobiel`, `email`, `straat`, `huisnummer`, `huisnummer_toevoeging`, `postcode`, `plaats`, `woonland_id`, `nationaltieit_id`, `bsn`, `iban`, `tav`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, '0000-00-00', 'El Maki', NULL, 'A.', 'Abdelmalak', 'm', '0611847158', '0611847158', 'abdelmalik77@live.nl', 'Elsland', 1412, NULL, '6605KL', 'Wijchen', 151, 1, NULL, NULL, NULL, 48, '2020-02-18 11:01:01', 1, 48, '2020-02-18 12:09:23'),
(2, 1, '0000-00-00', 'El Maki', NULL, 'A.', 'Abdelmalak', 'm', '0611847158', '0611847158', 'abdelmalik77@live.nl', 'Elsland', 1412, NULL, '6605KL', 'Wijchen', 151, 1, NULL, NULL, NULL, 48, '2020-02-18 11:09:23', 0, NULL, NULL),
(3, 2, '0000-00-00', 'Ouaaa', NULL, 'H', 'Hamid', 'm', '0685058102', '0685058102', 'hamid.ouaaa@hotmail.com', 'Broekstraat', 50, 'b', '6612AD', 'Nederasselt', 151, 1, NULL, NULL, NULL, 2, '2020-02-20 07:40:54', 0, NULL, NULL),
(4, 8003, '0000-00-00', 'Windefelde', NULL, 'EW', 'Esmond', 'm', '0685502260', '0685502260', 'esmond-nwa@hotmail.com', 'Malvert', 84, NULL, '6538CN', 'NL97INGB0749428422', 151, 1, NULL, NULL, NULL, 2, '2020-03-04 12:40:36', 0, NULL, NULL);

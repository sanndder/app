
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `invoer_vergoedingen_log`
--

CREATE TABLE `invoer_vergoedingen_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `invoer_id` int(11) UNSIGNED DEFAULT NULL,
  `action` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `json` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

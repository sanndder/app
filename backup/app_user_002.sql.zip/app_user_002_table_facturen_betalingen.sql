
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `facturen_betalingen`
--

CREATE TABLE `facturen_betalingen` (
  `id` int(11) UNSIGNED NOT NULL,
  `factuur_id` int(11) UNSIGNED DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bedrag` decimal(6,2) DEFAULT NULL,
  `betaald_op` date DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

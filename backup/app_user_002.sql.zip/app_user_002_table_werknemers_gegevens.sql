
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_gegevens`
--

CREATE TABLE `werknemers_gegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `gb_datum` date DEFAULT NULL,
  `achternaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tussenvoegsel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voorletters` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voornaam` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `geslacht` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobiel` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` int(5) UNSIGNED DEFAULT NULL,
  `huisnummer_toevoeging` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `woonland_id` int(11) DEFAULT NULL,
  `nationaltieit_id` int(11) DEFAULT NULL,
  `bsn` int(9) UNSIGNED ZEROFILL DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tav` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings_grootboek`
--

CREATE TABLE `settings_grootboek` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rekening` int(6) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `settings_grootboek`
--

INSERT INTO `settings_grootboek` (`id`, `name`, `rekening`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'verkoop', 1300, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(2, 'omzet_btw_hoog', 8000, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(3, 'btw_afdragen_hoog', 1602, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(4, 'omzet_btw_verlegd', 8020, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(5, 'inkoop', 1500, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(6, 'marge_uitzenders', 7002, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(7, 'btw_vorderen_hoog', 1612, 2, '2020-04-15 09:49:21', 1, 2, '2020-04-15 11:52:24'),
(8, 'verkoop', 1300, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(9, 'omzet_btw_hoog', 8001, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(10, 'btw_afdragen_hoog', 1602, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(11, 'omzet_btw_verlegd', 8020, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(12, 'inkoop', 1500, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(13, 'marge_uitzenders', 7002, 2, '2020-04-15 09:52:24', 0, NULL, NULL),
(14, 'btw_vorderen_hoog', 1612, 2, '2020-04-15 09:52:24', 0, NULL, NULL);

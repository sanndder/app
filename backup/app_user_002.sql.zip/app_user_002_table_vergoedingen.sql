
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vergoedingen`
--

CREATE TABLE `vergoedingen` (
  `vergoeding_id` int(11) UNSIGNED NOT NULL,
  `naam` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `belast` tinyint(1) DEFAULT '0',
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `vergoedingen`
--

INSERT INTO `vergoedingen` (`vergoeding_id`, `naam`, `belast`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 'reiskosten cao', 1, 2, '2019-12-04 14:45:52', 0, NULL, NULL),
(2, 'chauffeursvergoeding', 1, 2, '2019-12-04 14:50:46', 0, 2, '2019-12-04 15:54:42'),
(3, 'gereedschapgeld', 0, 2, '2019-12-04 14:51:45', 0, NULL, NULL),
(4, 'kledingeld', 0, 2, '2019-12-04 14:51:52', 0, NULL, NULL),
(5, 'laarzengeld', 0, 2, '2019-12-04 14:52:02', 0, NULL, NULL),
(6, 'prestatietoeslag', 1, 2, '2019-12-04 14:52:11', 0, NULL, NULL);

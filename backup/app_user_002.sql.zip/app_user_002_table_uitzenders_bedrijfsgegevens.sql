
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_bedrijfsgegevens`
--

CREATE TABLE `uitzenders_bedrijfsgegevens` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `bedrijfsnaam` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `btwnr` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` int(5) UNSIGNED DEFAULT NULL,
  `huisnummer_toevoeging` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_nummer` int(5) DEFAULT NULL,
  `postbus_postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postbus_plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `uitzenders_bedrijfsgegevens`
--

INSERT INTO `uitzenders_bedrijfsgegevens` (`id`, `uitzender_id`, `bedrijfsnaam`, `kvknr`, `btwnr`, `telefoon`, `straat`, `huisnummer`, `huisnummer_toevoeging`, `postcode`, `plaats`, `postbus_nummer`, `postbus_postcode`, `postbus_plaats`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(6, 103, 'Huls & Hoffmann Uitzendorganisatie V.O.F.', '65524381', 'NL856147072B01', '024-6793574', 'Prinses Beatrixstraat', 4, 'b', '6585XN', 'Mook', NULL, NULL, NULL, 0, '2020-01-08 11:15:59', 0, NULL, NULL),
(7, 104, 'Stephens Consultancy Holding BV', '69288674', 'NL857818090B01', '0629625764', 'Maximiliaanstraat', 14, NULL, '3082EB', 'Rotterdam', NULL, NULL, NULL, 0, '2020-01-30 11:34:08', 0, NULL, NULL),
(8, 105, '4You Personeelsdiensten', '66122422', 'NL164327496B01', '0682208331', 'Zwaneveld', 1603, NULL, '6538LP', 'Nijmegen', NULL, NULL, NULL, 0, '2020-02-12 12:43:59', 0, NULL, NULL);


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_urentypes`
--

CREATE TABLE `zzp_urentypes` (
  `id` int(11) UNSIGNED NOT NULL,
  `urentype_active` int(1) NOT NULL DEFAULT '1',
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_urentype_id` int(11) UNSIGNED DEFAULT NULL,
  `urentype_id` int(11) UNSIGNED DEFAULT NULL,
  `plaatsing_id` int(11) UNSIGNED DEFAULT NULL,
  `uurtarief` decimal(6,2) DEFAULT NULL,
  `verkooptarief` decimal(5,2) DEFAULT NULL,
  `marge` decimal(4,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_urentypes`
--

INSERT INTO `zzp_urentypes` (`id`, `urentype_active`, `inlener_id`, `zzp_id`, `inlener_urentype_id`, `urentype_id`, `plaatsing_id`, `uurtarief`, `verkooptarief`, `marge`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 3007, 1, 2, 8, 1, NULL, '39.00', '1.25', NULL, '2020-02-20 07:33:03', 1, 2, '2020-02-20 08:35:00'),
(2, 1, 3007, 1, 3, 9, 1, NULL, '48.75', '1.25', NULL, '2020-02-20 07:33:03', 1, 2, '2020-02-20 08:35:00'),
(3, 1, 3007, 1, 4, 3, 1, NULL, '58.50', '1.25', NULL, '2020-02-20 07:33:03', 1, 2, '2020-02-20 08:35:00'),
(4, 1, 3007, 1, 5, 10, 1, NULL, NULL, '1.25', NULL, '2020-02-20 07:33:03', 1, 2, '2020-02-20 08:35:00'),
(5, 1, 3007, 1, 6, 1, 2, '33.50', '39.00', '1.25', NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(6, 1, 3007, 1, 2, 8, 2, '16.75', '19.50', '1.25', NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(7, 1, 3007, 1, 3, 9, 2, '41.88', '48.75', '1.25', NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(8, 1, 3007, 1, 4, 3, 2, '50.25', '58.50', '1.25', NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(9, 1, 3007, 1, 5, 10, 2, '67.00', '78.00', '1.25', NULL, '2020-02-20 07:35:04', 0, NULL, NULL),
(10, 1, 3008, 2, 24, 1, 3, '27.00', '33.50', '1.25', NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(11, 1, 3008, 2, 25, 8, 3, '13.50', '16.75', '1.25', NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(12, 1, 3008, 2, 26, 9, 3, '33.75', '41.88', '1.25', NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(13, 1, 3008, 2, 27, 3, 3, '40.50', '50.25', '1.25', NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(14, 1, 3008, 2, 28, 10, 3, '54.00', '67.00', '1.25', NULL, '2020-02-20 07:53:09', 0, NULL, NULL),
(15, 1, 3008, 8003, 24, 1, 4, '27.50', '33.50', '1.25', NULL, '2020-03-04 12:43:00', 0, NULL, NULL),
(16, 1, 3008, 8003, 25, 8, 4, NULL, NULL, '1.25', NULL, '2020-03-04 12:43:00', 0, NULL, NULL),
(17, 1, 3008, 8003, 26, 9, 4, '34.38', '41.88', '1.45', NULL, '2020-03-04 12:43:00', 0, NULL, NULL),
(18, 1, 3008, 8003, 27, 3, 4, '41.25', '50.25', '1.60', NULL, '2020-03-04 12:43:00', 0, NULL, NULL),
(19, 1, 3008, 8003, 28, 10, 4, '55.00', '67.00', '1.75', NULL, '2020-03-04 12:43:00', 0, NULL, NULL);

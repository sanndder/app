
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `loonstroken_zip`
--

CREATE TABLE `loonstroken_zip` (
  `zip_id` int(11) UNSIGNED NOT NULL,
  `status_done` tinyint(1) NOT NULL DEFAULT '0',
  `pdf_totaal` int(5) DEFAULT NULL,
  `pdf_resterend` int(5) NOT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name_display` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) UNSIGNED DEFAULT NULL,
  `file_ext` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

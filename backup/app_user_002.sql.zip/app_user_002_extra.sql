
--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `cao`
--
ALTER TABLE `cao`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `cao_jobs`
--
ALTER TABLE `cao_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `cao_salary_table`
--
ALTER TABLE `cao_salary_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `cao_salary_table_salaries`
--
ALTER TABLE `cao_salary_table_salaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `cao_werksoort`
--
ALTER TABLE `cao_werksoort`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `creditsafe_id`
--
ALTER TABLE `creditsafe_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `creditsafe_reports`
--
ALTER TABLE `creditsafe_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `documenten`
--
ALTER TABLE `documenten`
  ADD PRIMARY KEY (`document_id`);

--
-- Indexen voor tabel `documenten_categorieen`
--
ALTER TABLE `documenten_categorieen`
  ADD PRIMARY KEY (`categorie_id`);

--
-- Indexen voor tabel `documenten_handtekeningen`
--
ALTER TABLE `documenten_handtekeningen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `documenten_templates_html`
--
ALTER TABLE `documenten_templates_html`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `documenten_templates_settings`
--
ALTER TABLE `documenten_templates_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexen voor tabel `emails_attachments`
--
ALTER TABLE `emails_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `emails_log`
--
ALTER TABLE `emails_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `emails_recipients`
--
ALTER TABLE `emails_recipients`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `export_snelstart_facturen`
--
ALTER TABLE `export_snelstart_facturen`
  ADD UNIQUE KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `export_snelstart_file`
--
ALTER TABLE `export_snelstart_file`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `facturen`
--
ALTER TABLE `facturen`
  ADD PRIMARY KEY (`factuur_id`),
  ADD UNIQUE KEY `factuur_nr` (`factuur_nr`),
  ADD KEY `sessie_id` (`sessie_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexen voor tabel `facturen_betalingen`
--
ALTER TABLE `facturen_betalingen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_bijlages`
--
ALTER TABLE `facturen_bijlages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_cessie_tekst`
--
ALTER TABLE `facturen_cessie_tekst`
  ADD PRIMARY KEY (`id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_correcties`
--
ALTER TABLE `facturen_correcties`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `facturen_kostenoverzicht`
--
ALTER TABLE `facturen_kostenoverzicht`
  ADD PRIMARY KEY (`kosten_id`),
  ADD KEY `sessie_id` (`sessie_id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_log`
--
ALTER TABLE `facturen_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_regels`
--
ALTER TABLE `facturen_regels`
  ADD PRIMARY KEY (`regel_id`),
  ADD KEY `werknemer_id` (`werknemer_id`),
  ADD KEY `zzp_id` (`zzp_id`),
  ADD KEY `factuur_id` (`factuur_id`);

--
-- Indexen voor tabel `facturen_sessies`
--
ALTER TABLE `facturen_sessies`
  ADD PRIMARY KEY (`sessie_id`);

--
-- Indexen voor tabel `facturen_sessies_log`
--
ALTER TABLE `facturen_sessies_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexen voor tabel `inleners_av_accepted`
--
ALTER TABLE `inleners_av_accepted`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `inleners_bedrijfsgegevens`
--
ALTER TABLE `inleners_bedrijfsgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_cao`
--
ALTER TABLE `inleners_cao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_contactpersonen`
--
ALTER TABLE `inleners_contactpersonen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_id` (`contact_id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_emailadressen`
--
ALTER TABLE `inleners_emailadressen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_factoren`
--
ALTER TABLE `inleners_factoren`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_factuurgegevens`
--
ALTER TABLE `inleners_factuurgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_kredietaanvragen`
--
ALTER TABLE `inleners_kredietaanvragen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE,
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `inleners_kredietgebruik`
--
ALTER TABLE `inleners_kredietgebruik`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_kredietgegevens`
--
ALTER TABLE `inleners_kredietgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_last_visited`
--
ALTER TABLE `inleners_last_visited`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`inlener_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `inleners_portal_status`
--
ALTER TABLE `inleners_portal_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_projecten`
--
ALTER TABLE `inleners_projecten`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE;

--
-- Indexen voor tabel `inleners_status`
--
ALTER TABLE `inleners_status`
  ADD PRIMARY KEY (`inlener_id`);

--
-- Indexen voor tabel `inleners_uitzenders`
--
ALTER TABLE `inleners_uitzenders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `inleners_urentypes`
--
ALTER TABLE `inleners_urentypes`
  ADD PRIMARY KEY (`inlener_urentype_id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE,
  ADD KEY `inleners_urentypes_urentypes` (`urentype_id`);

--
-- Indexen voor tabel `inleners_vergoedingen`
--
ALTER TABLE `inleners_vergoedingen`
  ADD PRIMARY KEY (`inlener_vergoeding_id`),
  ADD KEY `inlener_id` (`inlener_id`) USING BTREE,
  ADD KEY `inleners_urentypes_urentypes` (`vergoeding_id`);

--
-- Indexen voor tabel `invoer_bijlages`
--
ALTER TABLE `invoer_bijlages`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexen voor tabel `invoer_et`
--
ALTER TABLE `invoer_et`
  ADD PRIMARY KEY (`invoer_id`);

--
-- Indexen voor tabel `invoer_et_log`
--
ALTER TABLE `invoer_et_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `invoer_kilometers`
--
ALTER TABLE `invoer_kilometers`
  ADD PRIMARY KEY (`invoer_id`);

--
-- Indexen voor tabel `invoer_kilometers_log`
--
ALTER TABLE `invoer_kilometers_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `invoer_uren`
--
ALTER TABLE `invoer_uren`
  ADD PRIMARY KEY (`invoer_id`);

--
-- Indexen voor tabel `invoer_uren_log`
--
ALTER TABLE `invoer_uren_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `invoer_vergoedingen`
--
ALTER TABLE `invoer_vergoedingen`
  ADD PRIMARY KEY (`invoer_id`);

--
-- Indexen voor tabel `invoer_vergoedingen_log`
--
ALTER TABLE `invoer_vergoedingen_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `loonstroken_pdf`
--
ALTER TABLE `loonstroken_pdf`
  ADD PRIMARY KEY (`loonstrook_id`);

--
-- Indexen voor tabel `loonstroken_zip`
--
ALTER TABLE `loonstroken_zip`
  ADD PRIMARY KEY (`zip_id`);

--
-- Indexen voor tabel `proforma_zoekopdrachten`
--
ALTER TABLE `proforma_zoekopdrachten`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_betaaltermijnen`
--
ALTER TABLE `settings_betaaltermijnen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_cola_bedragen`
--
ALTER TABLE `settings_cola_bedragen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_factoring`
--
ALTER TABLE `settings_factoring`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_feestdagen`
--
ALTER TABLE `settings_feestdagen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_grootboek`
--
ALTER TABLE `settings_grootboek`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_minimumloon`
--
ALTER TABLE `settings_minimumloon`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `settings_proforma`
--
ALTER TABLE `settings_proforma`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `uitzenders_av_accepted`
--
ALTER TABLE `uitzenders_av_accepted`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `uitzenders_bedrijfsgegevens`
--
ALTER TABLE `uitzenders_bedrijfsgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_contactpersonen`
--
ALTER TABLE `uitzenders_contactpersonen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexen voor tabel `uitzenders_emailadressen`
--
ALTER TABLE `uitzenders_emailadressen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_factoren`
--
ALTER TABLE `uitzenders_factoren`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_factuurgegevens`
--
ALTER TABLE `uitzenders_factuurgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_handtekening`
--
ALTER TABLE `uitzenders_handtekening`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_korting`
--
ALTER TABLE `uitzenders_korting`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `uitzenders_last_visited`
--
ALTER TABLE `uitzenders_last_visited`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `uitzenders_logo`
--
ALTER TABLE `uitzenders_logo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`uitzender_id`);

--
-- Indexen voor tabel `uitzenders_status`
--
ALTER TABLE `uitzenders_status`
  ADD PRIMARY KEY (`uitzender_id`);

--
-- Indexen voor tabel `urentypes`
--
ALTER TABLE `urentypes`
  ADD PRIMARY KEY (`urentype_id`),
  ADD KEY `urentype_categorie_id` (`urentype_categorie_id`);

--
-- Indexen voor tabel `urentypes_categorien`
--
ALTER TABLE `urentypes_categorien`
  ADD PRIMARY KEY (`urentype_categorie_id`);

--
-- Indexen voor tabel `vergoedingen`
--
ALTER TABLE `vergoedingen`
  ADD PRIMARY KEY (`vergoeding_id`);

--
-- Indexen voor tabel `werkgever_av`
--
ALTER TABLE `werkgever_av`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entiteit_id` (`entiteit_id`) USING BTREE;

--
-- Indexen voor tabel `werkgever_bankrekeningen`
--
ALTER TABLE `werkgever_bankrekeningen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entiteit_id` (`entiteit_id`);

--
-- Indexen voor tabel `werkgever_bedrijfsgegevens`
--
ALTER TABLE `werkgever_bedrijfsgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entiteit_id` (`entiteit_id`);

--
-- Indexen voor tabel `werkgever_entiteiten`
--
ALTER TABLE `werkgever_entiteiten`
  ADD PRIMARY KEY (`entiteit_id`),
  ADD KEY `default_entiteit` (`default_entiteit`);

--
-- Indexen voor tabel `werkgever_handtekening`
--
ALTER TABLE `werkgever_handtekening`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entiteit_id` (`entiteit_id`) USING BTREE;

--
-- Indexen voor tabel `werkgever_logo`
--
ALTER TABLE `werkgever_logo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entiteit_id` (`entiteit_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_dienstverband_cao`
--
ALTER TABLE `werknemers_dienstverband_cao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_dienstverband_duur`
--
ALTER TABLE `werknemers_dienstverband_duur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_gegevens`
--
ALTER TABLE `werknemers_gegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_idbewijs`
--
ALTER TABLE `werknemers_idbewijs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`werknemer_id`);

--
-- Indexen voor tabel `werknemers_inleners`
--
ALTER TABLE `werknemers_inleners`
  ADD PRIMARY KEY (`plaatsing_id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`werknemer_id`) USING BTREE,
  ADD KEY `werknemers_inleners_cao` (`cao_id_intern`);

--
-- Indexen voor tabel `werknemers_last_visited`
--
ALTER TABLE `werknemers_last_visited`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`werknemer_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `werknemers_pensioen`
--
ALTER TABLE `werknemers_pensioen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_reserveringen`
--
ALTER TABLE `werknemers_reserveringen`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `werknemer_id_2` (`werknemer_id`,`datum`),
  ADD KEY `werknemer_id` (`werknemer_id`);

--
-- Indexen voor tabel `werknemers_status`
--
ALTER TABLE `werknemers_status`
  ADD PRIMARY KEY (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_uitzenders`
--
ALTER TABLE `werknemers_uitzenders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`uitzender_id`),
  ADD KEY ` werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_urentypes`
--
ALTER TABLE `werknemers_urentypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`werknemer_id`) USING BTREE,
  ADD KEY `urentype_id` (`urentype_id`),
  ADD KEY `inlener_urentype_id` (`inlener_urentype_id`),
  ADD KEY `werknemers_urentypes_uurloon_id` (`plaatsing_id`);

--
-- Indexen voor tabel `werknemers_uurloon`
--
ALTER TABLE `werknemers_uurloon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemers_vergoedingen`
--
ALTER TABLE `werknemers_vergoedingen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`werknemer_id`) USING BTREE,
  ADD KEY `urentype_id` (`vergoeding_id`),
  ADD KEY `inlener_urentype_id` (`inlener_vergoeding_id`);

--
-- Indexen voor tabel `werknemers_verloning_instellingen`
--
ALTER TABLE `werknemers_verloning_instellingen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`werknemer_id`) USING BTREE;

--
-- Indexen voor tabel `werknemer_et_bsn`
--
ALTER TABLE `werknemer_et_bsn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`werknemer_id`);

--
-- Indexen voor tabel `werknemer_et_inhouding_huisvesting`
--
ALTER TABLE `werknemer_et_inhouding_huisvesting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`werknemer_id`);

--
-- Indexen voor tabel `werknemer_et_settings`
--
ALTER TABLE `werknemer_et_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`werknemer_id`);

--
-- Indexen voor tabel `werknemer_et_verblijf`
--
ALTER TABLE `werknemer_et_verblijf`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `zzp_bedrijfsgegevens`
--
ALTER TABLE `zzp_bedrijfsgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_factuurgegevens`
--
ALTER TABLE `zzp_factuurgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_idbewijs`
--
ALTER TABLE `zzp_idbewijs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`zzp_id`);

--
-- Indexen voor tabel `zzp_inleners`
--
ALTER TABLE `zzp_inleners`
  ADD PRIMARY KEY (`plaatsing_id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_kvk_inschrijving`
--
ALTER TABLE `zzp_kvk_inschrijving`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`zzp_id`);

--
-- Indexen voor tabel `zzp_last_visited`
--
ALTER TABLE `zzp_last_visited`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`zzp_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `zzp_logo`
--
ALTER TABLE `zzp_logo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uitzender_id` (`zzp_id`);

--
-- Indexen voor tabel `zzp_persoonsgegevens`
--
ALTER TABLE `zzp_persoonsgegevens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `werknemer_id` (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_status`
--
ALTER TABLE `zzp_status`
  ADD PRIMARY KEY (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_uitzenders`
--
ALTER TABLE `zzp_uitzenders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`uitzender_id`),
  ADD KEY ` werknemer_id` (`zzp_id`) USING BTREE;

--
-- Indexen voor tabel `zzp_urentypes`
--
ALTER TABLE `zzp_urentypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`zzp_id`) USING BTREE,
  ADD KEY `urentype_id` (`urentype_id`),
  ADD KEY `inlener_urentype_id` (`inlener_urentype_id`);

--
-- Indexen voor tabel `zzp_vergoedingen`
--
ALTER TABLE `zzp_vergoedingen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inlener_id` (`inlener_id`),
  ADD KEY ` werknemer_id` (`zzp_id`) USING BTREE,
  ADD KEY `urentype_id` (`vergoeding_id`),
  ADD KEY `inlener_urentype_id` (`inlener_vergoeding_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `cao`
--
ALTER TABLE `cao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT voor een tabel `cao_jobs`
--
ALTER TABLE `cao_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35241;

--
-- AUTO_INCREMENT voor een tabel `cao_salary_table`
--
ALTER TABLE `cao_salary_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1914;

--
-- AUTO_INCREMENT voor een tabel `cao_salary_table_salaries`
--
ALTER TABLE `cao_salary_table_salaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117325;

--
-- AUTO_INCREMENT voor een tabel `cao_werksoort`
--
ALTER TABLE `cao_werksoort`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2082;

--
-- AUTO_INCREMENT voor een tabel `creditsafe_id`
--
ALTER TABLE `creditsafe_id`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT voor een tabel `creditsafe_reports`
--
ALTER TABLE `creditsafe_reports`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT voor een tabel `documenten`
--
ALTER TABLE `documenten`
  MODIFY `document_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `documenten_categorieen`
--
ALTER TABLE `documenten_categorieen`
  MODIFY `categorie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `documenten_handtekeningen`
--
ALTER TABLE `documenten_handtekeningen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `documenten_templates_html`
--
ALTER TABLE `documenten_templates_html`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT voor een tabel `documenten_templates_settings`
--
ALTER TABLE `documenten_templates_settings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT voor een tabel `emails`
--
ALTER TABLE `emails`
  MODIFY `email_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT voor een tabel `emails_attachments`
--
ALTER TABLE `emails_attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `emails_log`
--
ALTER TABLE `emails_log`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT voor een tabel `emails_recipients`
--
ALTER TABLE `emails_recipients`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT voor een tabel `export_snelstart_file`
--
ALTER TABLE `export_snelstart_file`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `facturen`
--
ALTER TABLE `facturen`
  MODIFY `factuur_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT voor een tabel `facturen_betalingen`
--
ALTER TABLE `facturen_betalingen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `facturen_bijlages`
--
ALTER TABLE `facturen_bijlages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `facturen_cessie_tekst`
--
ALTER TABLE `facturen_cessie_tekst`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT voor een tabel `facturen_correcties`
--
ALTER TABLE `facturen_correcties`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `facturen_kostenoverzicht`
--
ALTER TABLE `facturen_kostenoverzicht`
  MODIFY `kosten_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT voor een tabel `facturen_log`
--
ALTER TABLE `facturen_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `facturen_regels`
--
ALTER TABLE `facturen_regels`
  MODIFY `regel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT voor een tabel `facturen_sessies`
--
ALTER TABLE `facturen_sessies`
  MODIFY `sessie_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT voor een tabel `facturen_sessies_log`
--
ALTER TABLE `facturen_sessies_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=802;

--
-- AUTO_INCREMENT voor een tabel `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `inleners_av_accepted`
--
ALTER TABLE `inleners_av_accepted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `inleners_bedrijfsgegevens`
--
ALTER TABLE `inleners_bedrijfsgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT voor een tabel `inleners_cao`
--
ALTER TABLE `inleners_cao`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `inleners_contactpersonen`
--
ALTER TABLE `inleners_contactpersonen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `inleners_emailadressen`
--
ALTER TABLE `inleners_emailadressen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `inleners_factoren`
--
ALTER TABLE `inleners_factoren`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `inleners_factuurgegevens`
--
ALTER TABLE `inleners_factuurgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `inleners_kredietaanvragen`
--
ALTER TABLE `inleners_kredietaanvragen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `inleners_kredietgebruik`
--
ALTER TABLE `inleners_kredietgebruik`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `inleners_kredietgegevens`
--
ALTER TABLE `inleners_kredietgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `inleners_last_visited`
--
ALTER TABLE `inleners_last_visited`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT voor een tabel `inleners_portal_status`
--
ALTER TABLE `inleners_portal_status`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `inleners_projecten`
--
ALTER TABLE `inleners_projecten`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `inleners_status`
--
ALTER TABLE `inleners_status`
  MODIFY `inlener_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3009;

--
-- AUTO_INCREMENT voor een tabel `inleners_uitzenders`
--
ALTER TABLE `inleners_uitzenders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT voor een tabel `inleners_urentypes`
--
ALTER TABLE `inleners_urentypes`
  MODIFY `inlener_urentype_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT voor een tabel `inleners_vergoedingen`
--
ALTER TABLE `inleners_vergoedingen`
  MODIFY `inlener_vergoeding_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_bijlages`
--
ALTER TABLE `invoer_bijlages`
  MODIFY `file_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT voor een tabel `invoer_et`
--
ALTER TABLE `invoer_et`
  MODIFY `invoer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_et_log`
--
ALTER TABLE `invoer_et_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_kilometers`
--
ALTER TABLE `invoer_kilometers`
  MODIFY `invoer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_kilometers_log`
--
ALTER TABLE `invoer_kilometers_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_uren`
--
ALTER TABLE `invoer_uren`
  MODIFY `invoer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT voor een tabel `invoer_uren_log`
--
ALTER TABLE `invoer_uren_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `invoer_vergoedingen`
--
ALTER TABLE `invoer_vergoedingen`
  MODIFY `invoer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `invoer_vergoedingen_log`
--
ALTER TABLE `invoer_vergoedingen_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `loonstroken_pdf`
--
ALTER TABLE `loonstroken_pdf`
  MODIFY `loonstrook_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `loonstroken_zip`
--
ALTER TABLE `loonstroken_zip`
  MODIFY `zip_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `proforma_zoekopdrachten`
--
ALTER TABLE `proforma_zoekopdrachten`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `settings_betaaltermijnen`
--
ALTER TABLE `settings_betaaltermijnen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT voor een tabel `settings_cola_bedragen`
--
ALTER TABLE `settings_cola_bedragen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT voor een tabel `settings_factoring`
--
ALTER TABLE `settings_factoring`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `settings_feestdagen`
--
ALTER TABLE `settings_feestdagen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `settings_grootboek`
--
ALTER TABLE `settings_grootboek`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT voor een tabel `settings_minimumloon`
--
ALTER TABLE `settings_minimumloon`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT voor een tabel `settings_proforma`
--
ALTER TABLE `settings_proforma`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_av_accepted`
--
ALTER TABLE `uitzenders_av_accepted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_bedrijfsgegevens`
--
ALTER TABLE `uitzenders_bedrijfsgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_contactpersonen`
--
ALTER TABLE `uitzenders_contactpersonen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_emailadressen`
--
ALTER TABLE `uitzenders_emailadressen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_factoren`
--
ALTER TABLE `uitzenders_factoren`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_factuurgegevens`
--
ALTER TABLE `uitzenders_factuurgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_handtekening`
--
ALTER TABLE `uitzenders_handtekening`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_korting`
--
ALTER TABLE `uitzenders_korting`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_last_visited`
--
ALTER TABLE `uitzenders_last_visited`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=327;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_logo`
--
ALTER TABLE `uitzenders_logo`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `uitzenders_status`
--
ALTER TABLE `uitzenders_status`
  MODIFY `uitzender_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT voor een tabel `urentypes`
--
ALTER TABLE `urentypes`
  MODIFY `urentype_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT voor een tabel `urentypes_categorien`
--
ALTER TABLE `urentypes_categorien`
  MODIFY `urentype_categorie_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `vergoedingen`
--
ALTER TABLE `vergoedingen`
  MODIFY `vergoeding_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT voor een tabel `werkgever_av`
--
ALTER TABLE `werkgever_av`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT voor een tabel `werkgever_bankrekeningen`
--
ALTER TABLE `werkgever_bankrekeningen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werkgever_bedrijfsgegevens`
--
ALTER TABLE `werkgever_bedrijfsgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT voor een tabel `werkgever_entiteiten`
--
ALTER TABLE `werkgever_entiteiten`
  MODIFY `entiteit_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `werkgever_handtekening`
--
ALTER TABLE `werkgever_handtekening`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `werkgever_logo`
--
ALTER TABLE `werkgever_logo`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `werknemers_dienstverband_cao`
--
ALTER TABLE `werknemers_dienstverband_cao`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_dienstverband_duur`
--
ALTER TABLE `werknemers_dienstverband_duur`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_gegevens`
--
ALTER TABLE `werknemers_gegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_idbewijs`
--
ALTER TABLE `werknemers_idbewijs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `werknemers_inleners`
--
ALTER TABLE `werknemers_inleners`
  MODIFY `plaatsing_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_last_visited`
--
ALTER TABLE `werknemers_last_visited`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT voor een tabel `werknemers_pensioen`
--
ALTER TABLE `werknemers_pensioen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_reserveringen`
--
ALTER TABLE `werknemers_reserveringen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_status`
--
ALTER TABLE `werknemers_status`
  MODIFY `werknemer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_uitzenders`
--
ALTER TABLE `werknemers_uitzenders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_urentypes`
--
ALTER TABLE `werknemers_urentypes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_uurloon`
--
ALTER TABLE `werknemers_uurloon`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_vergoedingen`
--
ALTER TABLE `werknemers_vergoedingen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemers_verloning_instellingen`
--
ALTER TABLE `werknemers_verloning_instellingen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemer_et_bsn`
--
ALTER TABLE `werknemer_et_bsn`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemer_et_inhouding_huisvesting`
--
ALTER TABLE `werknemer_et_inhouding_huisvesting`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemer_et_settings`
--
ALTER TABLE `werknemer_et_settings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `werknemer_et_verblijf`
--
ALTER TABLE `werknemer_et_verblijf`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `zzp_bedrijfsgegevens`
--
ALTER TABLE `zzp_bedrijfsgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `zzp_factuurgegevens`
--
ALTER TABLE `zzp_factuurgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `zzp_idbewijs`
--
ALTER TABLE `zzp_idbewijs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `zzp_inleners`
--
ALTER TABLE `zzp_inleners`
  MODIFY `plaatsing_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `zzp_kvk_inschrijving`
--
ALTER TABLE `zzp_kvk_inschrijving`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `zzp_last_visited`
--
ALTER TABLE `zzp_last_visited`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT voor een tabel `zzp_logo`
--
ALTER TABLE `zzp_logo`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `zzp_persoonsgegevens`
--
ALTER TABLE `zzp_persoonsgegevens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `zzp_status`
--
ALTER TABLE `zzp_status`
  MODIFY `zzp_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8004;

--
-- AUTO_INCREMENT voor een tabel `zzp_uitzenders`
--
ALTER TABLE `zzp_uitzenders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `zzp_urentypes`
--
ALTER TABLE `zzp_urentypes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT voor een tabel `zzp_vergoedingen`
--
ALTER TABLE `zzp_vergoedingen`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `export_snelstart_facturen`
--
ALTER TABLE `export_snelstart_facturen`
  ADD CONSTRAINT `export_snelstart_facturen` FOREIGN KEY (`factuur_id`) REFERENCES `facturen` (`factuur_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `facturen`
--
ALTER TABLE `facturen`
  ADD CONSTRAINT `facturen_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `facturen` (`factuur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `facturen_regels`
--
ALTER TABLE `facturen_regels`
  ADD CONSTRAINT `facturen_regels_factuur_id` FOREIGN KEY (`factuur_id`) REFERENCES `facturen` (`factuur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `inleners_bedrijfsgegevens`
--
ALTER TABLE `inleners_bedrijfsgegevens`
  ADD CONSTRAINT `inleners_bedrijfsgegevens` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_cao`
--
ALTER TABLE `inleners_cao`
  ADD CONSTRAINT `inleners_cao_inlener_id` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_contactpersonen`
--
ALTER TABLE `inleners_contactpersonen`
  ADD CONSTRAINT `inleners_contactpersonen` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_emailadressen`
--
ALTER TABLE `inleners_emailadressen`
  ADD CONSTRAINT `inleners_emailadressen` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_factoren`
--
ALTER TABLE `inleners_factoren`
  ADD CONSTRAINT `inleners_factoren` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_factuurgegevens`
--
ALTER TABLE `inleners_factuurgegevens`
  ADD CONSTRAINT `inleners_factuurgegevens` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_portal_status`
--
ALTER TABLE `inleners_portal_status`
  ADD CONSTRAINT `inleners_portal_status` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_uitzenders`
--
ALTER TABLE `inleners_uitzenders`
  ADD CONSTRAINT `inleners_uitzenders` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `inleners_urentypes`
--
ALTER TABLE `inleners_urentypes`
  ADD CONSTRAINT `inleners_urentypes` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `inleners_urentypes_urentypes` FOREIGN KEY (`urentype_id`) REFERENCES `urentypes` (`urentype_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werkgever_av`
--
ALTER TABLE `werkgever_av`
  ADD CONSTRAINT `entiteit_id av` FOREIGN KEY (`entiteit_id`) REFERENCES `werkgever_entiteiten` (`entiteit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werkgever_logo`
--
ALTER TABLE `werkgever_logo`
  ADD CONSTRAINT `entiteit_id` FOREIGN KEY (`entiteit_id`) REFERENCES `werkgever_entiteiten` (`entiteit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werknemers_inleners`
--
ALTER TABLE `werknemers_inleners`
  ADD CONSTRAINT `werknemers_inleners_inlener` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_inleners_werknemer` FOREIGN KEY (`werknemer_id`) REFERENCES `werknemers_status` (`werknemer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werknemers_uitzenders`
--
ALTER TABLE `werknemers_uitzenders`
  ADD CONSTRAINT `werknemers_uitzenders_uitzender_id` FOREIGN KEY (`uitzender_id`) REFERENCES `uitzenders_status` (`uitzender_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_uitzenders_werknemer_id` FOREIGN KEY (`werknemer_id`) REFERENCES `werknemers_status` (`werknemer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werknemers_urentypes`
--
ALTER TABLE `werknemers_urentypes`
  ADD CONSTRAINT `werknemers_urentypes_inlener_id` FOREIGN KEY (`inlener_id`) REFERENCES `inleners_status` (`inlener_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_urentypes_inlener_urentype_id` FOREIGN KEY (`inlener_urentype_id`) REFERENCES `inleners_urentypes` (`inlener_urentype_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_urentypes_urentype_id` FOREIGN KEY (`urentype_id`) REFERENCES `urentypes` (`urentype_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_urentypes_uurloon_id` FOREIGN KEY (`plaatsing_id`) REFERENCES `werknemers_inleners` (`plaatsing_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `werknemers_urentypes_werknemer_id` FOREIGN KEY (`werknemer_id`) REFERENCES `werknemers_status` (`werknemer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `werknemers_uurloon`
--
ALTER TABLE `werknemers_uurloon`
  ADD CONSTRAINT `werknemers_uurloon_werknemer_id` FOREIGN KEY (`werknemer_id`) REFERENCES `werknemers_status` (`werknemer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

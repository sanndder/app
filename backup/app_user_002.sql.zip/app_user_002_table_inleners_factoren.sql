
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_factoren`
--

CREATE TABLE `inleners_factoren` (
  `id` int(11) UNSIGNED NOT NULL,
  `factor_id` int(11) DEFAULT NULL,
  `default_factor` tinyint(1) NOT NULL DEFAULT '0',
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `omschrijving` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `factor_hoog` decimal(4,3) DEFAULT NULL,
  `factor_laag` decimal(4,3) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_factoren`
--

INSERT INTO `inleners_factoren` (`id`, `factor_id`, `default_factor`, `inlener_id`, `omschrijving`, `factor_hoog`, `factor_laag`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 1, 1, 3006, 'standaard factoren', NULL, NULL, 48, '2020-02-10 09:53:30', 0, NULL, NULL),
(2, 1, 1, 3007, 'standaard factoren', '1.720', '1.550', 48, '2020-02-12 14:27:20', 0, NULL, NULL),
(3, 3, 1, 3008, 'Standaard factor', '1.720', '1.550', 48, '2020-02-20 07:52:32', 0, NULL, NULL);

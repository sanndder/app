
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `uitzenders_korting`
--

CREATE TABLE `uitzenders_korting` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `korting_percentage` decimal(4,2) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

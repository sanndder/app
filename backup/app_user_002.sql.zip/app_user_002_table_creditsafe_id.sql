
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `creditsafe_id`
--

CREATE TABLE `creditsafe_id` (
  `id` int(11) UNSIGNED NOT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creditsafe_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `creditsafe_id`
--

INSERT INTO `creditsafe_id` (`id`, `kvknr`, `creditsafe_id`, `user_id`, `timestamp`) VALUES
(5, '20164427', 'NL-X-201644270000', 2, '2020-01-08 12:24:18'),
(6, '11024263', 'NL-X-110242630000', 2, '2020-01-08 14:15:02'),
(7, '11024263', 'NL-X-110242630001', 48, '2020-01-08 14:16:36'),
(8, '18066055', 'NL-X-180660550000', 48, '2020-01-08 14:25:39'),
(9, '06060664', 'NL-X-060606640000', 61, '2020-02-04 11:25:57'),
(10, '68737084', 'NL-X-687370840000', 48, '2020-02-18 10:55:03'),
(11, '73435465', 'NL-X-734354650000', 2, '2020-02-20 07:38:03'),
(12, '63774267', 'NL-X-637742670000', 2, '2020-02-20 10:41:10'),
(13, '68609515', 'NL-X-686095150000', 2, '2020-03-04 11:35:20');

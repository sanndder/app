
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_last_visited`
--

CREATE TABLE `werknemers_last_visited` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `werknemers_last_visited`
--

INSERT INTO `werknemers_last_visited` (`id`, `user_id`, `werknemer_id`, `timestamp`) VALUES
(1, 2, 0, '2020-01-06 10:51:22'),
(2, 47, 0, '2020-01-06 11:09:49'),
(4, 48, 20004, '2020-02-12 12:40:16'),
(6, 48, 20001, '2020-02-18 10:50:33'),
(8, 49, 20004, '2020-02-18 19:29:45'),
(10, 49, 20003, '2020-02-18 19:30:18');

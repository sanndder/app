
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings_cola_bedragen`
--

CREATE TABLE `settings_cola_bedragen` (
  `id` int(11) NOT NULL,
  `land` varchar(100) NOT NULL,
  `bedrag` decimal(7,2) NOT NULL,
  `land_code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `settings_cola_bedragen`
--

INSERT INTO `settings_cola_bedragen` (`id`, `land`, `bedrag`, `land_code`) VALUES
(1, 'Bulgarije', '26.98', 0),
(2, 'Estland', '8.11', 0),
(4, 'Hongarije', '18.59', 0),
(5, 'Kroatië', '9.58', 0),
(6, 'Letland', '11.65', 0),
(7, 'Lithouwen', '19.56', 0),
(8, 'Polen', '28.77', 0),
(9, 'Portugal', '1.60', 0),
(10, 'Roemenië', '31.18', 0),
(11, 'Slovenië', '9.83', 0),
(12, 'Slowakije', '12.52', 0),
(13, 'Spanje', '7.75', 0),
(14, 'Tsjechië', '19.50', 0);

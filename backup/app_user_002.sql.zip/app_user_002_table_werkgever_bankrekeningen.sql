
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkgever_bankrekeningen`
--

CREATE TABLE `werkgever_bankrekeningen` (
  `id` int(11) UNSIGNED NOT NULL,
  `entiteit_id` int(11) DEFAULT NULL,
  `omschrijving` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iban` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

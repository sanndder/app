
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemers_reserveringen`
--

CREATE TABLE `werknemers_reserveringen` (
  `id` int(11) UNSIGNED NOT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `vakantiegeld` decimal(8,2) DEFAULT '0.00',
  `vakantieuren` decimal(8,2) DEFAULT '0.00',
  `vakantieuren_F12` decimal(8,2) DEFAULT '0.00',
  `kort_verzuim` decimal(8,2) DEFAULT '0.00',
  `feestdagen` decimal(8,2) DEFAULT '0.00',
  `atv_uren` decimal(8,2) DEFAULT '0.00',
  `seniorendagen` decimal(8,2) DEFAULT '0.00',
  `tijdvoortijd` decimal(8,2) NOT NULL DEFAULT '0.00',
  `user_id` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

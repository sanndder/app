
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_idbewijs`
--

CREATE TABLE `zzp_idbewijs` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `vervaldatum` date DEFAULT NULL,
  `twee_op_een` tinyint(1) NOT NULL DEFAULT '0',
  `file_1` mediumblob,
  `file_1_size` int(11) UNSIGNED DEFAULT NULL,
  `file_2` mediumblob,
  `file_2_size` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

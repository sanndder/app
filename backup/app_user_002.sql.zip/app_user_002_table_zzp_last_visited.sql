
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_last_visited`
--

CREATE TABLE `zzp_last_visited` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_last_visited`
--

INSERT INTO `zzp_last_visited` (`id`, `user_id`, `zzp_id`, `timestamp`) VALUES
(5, 48, 0, '2020-02-18 10:56:44'),
(32, 48, 1, '2020-02-19 13:12:18'),
(36, 49, 0, '2020-02-19 13:15:52'),
(87, 49, 1, '2020-03-04 10:22:00'),
(90, 2, 0, '2020-03-04 12:39:30'),
(103, 49, 8003, '2020-03-04 13:03:47'),
(106, 2, 2, '2020-03-06 10:37:58'),
(107, 2, 1, '2020-03-06 10:37:59'),
(110, 2, 8003, '2020-03-12 14:36:42');

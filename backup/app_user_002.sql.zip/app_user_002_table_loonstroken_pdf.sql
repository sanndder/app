
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `loonstroken_pdf`
--

CREATE TABLE `loonstroken_pdf` (
  `loonstrook_id` int(11) UNSIGNED NOT NULL,
  `count_pages` tinyint(2) DEFAULT NULL,
  `werknemer_id` int(11) UNSIGNED DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `tijdvak` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jaar` int(4) DEFAULT NULL,
  `periode` int(2) DEFAULT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

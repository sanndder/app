
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `zzp_kvk_inschrijving`
--

CREATE TABLE `zzp_kvk_inschrijving` (
  `id` int(11) UNSIGNED NOT NULL,
  `zzp_id` int(11) UNSIGNED DEFAULT NULL,
  `file_dir` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) UNSIGNED DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `zzp_kvk_inschrijving`
--

INSERT INTO `zzp_kvk_inschrijving` (`id`, `zzp_id`, `file_dir`, `file_name`, `file_size`, `user_id`, `timestamp`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(1, 2, 'zzp/uittrekselkvk', 'kvk_0530737001582184459_Vz6QREMW.jpg', 221955, 2, '2020-02-20 07:40:59', 0, NULL, NULL);

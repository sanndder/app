
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inleners_kredietaanvragen`
--

CREATE TABLE `inleners_kredietaanvragen` (
  `id` int(11) UNSIGNED NOT NULL,
  `uitzender_id` int(11) UNSIGNED DEFAULT NULL,
  `inlener_id` int(11) UNSIGNED DEFAULT NULL,
  `krediet_afgewezen` tinyint(1) DEFAULT NULL,
  `kredietlimiet_gewenst` int(6) DEFAULT NULL,
  `kredietlimiet_toegekend` int(6) DEFAULT NULL,
  `bedrijfsnaam` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kvknr` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `btwnr` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefoon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `straat` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `huisnummer` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plaats` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) UNSIGNED DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) UNSIGNED DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `inleners_kredietaanvragen`
--

INSERT INTO `inleners_kredietaanvragen` (`id`, `uitzender_id`, `inlener_id`, `krediet_afgewezen`, `kredietlimiet_gewenst`, `kredietlimiet_toegekend`, `bedrijfsnaam`, `kvknr`, `btwnr`, `telefoon`, `email`, `straat`, `huisnummer`, `postcode`, `plaats`, `user_id`, `timestamp`, `updated_by`, `updated_on`, `deleted`, `deleted_by`, `deleted_on`) VALUES
(2, 103, 3000, 0, 30000, 30000, 'Coatacoustic B.V.', '18066055', 'NL810536262B01', '0418587030', 'info@coatacoustic.nl', 'Schimminck', '16', '5301KR', 'ZALTBOMMEL', 48, '2020-01-08 14:27:39', 2020, NULL, 0, NULL, NULL),
(3, 104, 3006, 0, 45000, 50000, 'Installatiebedrijf G. van Dam B.V.', '06060664', 'NL007725759B01', '+31 (0) 548 51 44 11', 'HBrinks@vandamgroep.com', 'Fahrenheitstraat', '4', '7461JA', 'RIJSSEN', 61, '2020-02-04 11:30:54', 2020, NULL, 0, NULL, NULL);
